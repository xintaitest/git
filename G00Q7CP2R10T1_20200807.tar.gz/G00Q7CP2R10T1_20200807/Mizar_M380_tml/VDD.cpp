#include "testmethod.hpp"

//for test method API interfaces
#include "mapi.hpp"
#include "Public.h"
using namespace std;
using namespace V93kLimits;


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class VDD_Active_VDD_Test: public testmethod::TestMethod {
protected:
	string  PowerPinList;
	double wait_time;
	int isMultiLimit;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("Test_PowerPin",
				 "PinString",
				 &PowerPinList,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
				 "double",
				 &wait_time,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("isMultiLimit",
				 "int",
				 &isMultiLimit,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	DPS_TASK meas_VDD;
	static STRING_VECTOR  pinList;
	static string suitName,testName;
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;
	double LowLimit, HighLimit;
	double UnitRatio;
	unsigned int i;

	ON_FIRST_INVOCATION_BEGIN();
//		FUNCTIONAL_TEST();
//		FW_TASK("rlyc idle,off,(rlyc idle)\n");
		CONNECT();
		pinList=PinUtility.getDpsPinNamesFromPinList(PowerPinList,TRUE);
		meas_VDD.pin(PowerPinList)
				.measurementMode(TM::MEASURE_VOLTAGE)
				.min(1.5 V)
				.max(1.9 V);
//		meas_VDD.pin(PowerPinList).min(-50 mA).max(50 mA);
		meas_VDD.wait(wait_time ms).execMode("PVAL").samples(128);
		meas_VDD.execute();
//		flex_relay_control("ALL_PINS","AC","X");
		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(i=0;i<pinList.size();i++)
		{

			testName = pinList[i];

			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],meas_VDD.getValue(pinList[i]));
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	for(i=0;i<pinList.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],pinList[i],tmLimits,meas_VDD.getValue(pinList[i])*1e3);
	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("VDD.Active_VDD_Test", VDD_Active_VDD_Test);



/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class VDD_SPMU_PIN_TASK: public testmethod::TestMethod {
protected:
	string  PowerPinList;
	double 	wait_time;
	int isMultiBin;
	int PAT_soft_bin;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("Test_PowerPin",
				 "PinString",
				 &PowerPinList,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
				 "double",
				 &wait_time,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("isMultiBin",
				 "int",
				 &isMultiBin,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("PAT_soft_bin",
				 "int",
				 &PAT_soft_bin,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	//DPS_TASK meas_VDD;
	//PMU_IFVM pmuIfvm();
	SPMU_TASK pmuIfvm;
	static STRING_VECTOR  pinList;
	static string suitName,testName;
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;
	double LowLimit, HighLimit;
	double UnitRatio;
	unsigned int i;

	ON_FIRST_INVOCATION_BEGIN();
//		LOZ Imped = Low,HIZ Imped = High,HIZ_R
//		FW_TASK("PSLV PRM,0.0,0.5,0.5,LOZ_HIZ,2,(VDD18_D)"); //FOR DC Scale DPS
//		FW_TASK("PSST OFF,(VDD18_D)");
//
//		FW_TASK("PSLV PRM,0.0,0.5,0.5,LOZ_HIZ,2,(VDD33_LDO0)"); //FOR DC Scale DPS
//		FW_TASK("PSST OFF,(VDD33_LDO0)");

		CONNECT();
		pinList = PinUtility.getDigitalPinNamesFromPinList(PowerPinList,TM::ALL_DIGITAL,true,true);

		pmuIfvm.pin(PowerPinList).mode("IFVM")
                        		 .iForce(-50 mA)
                				 .iForceRange(100 mA)
								 .clamp(1000 mV)
                				 .min(0 mV)
                				 .max(2000 mV)
                				 .compare("I")
                				 .settling(wait_time ms)
                				 .relay("NT");
		pmuIfvm.execMode("PVAL").execute();

//		pmuIfvm.pin(PowerPinList).mode("VM_HIZ").settling(1 ms).samples(128);
//		pmuIfvm.pin(PowerPinList).relay("NT").min(0 V).max(3.3 V);
//		pmuIfvm.preAction("NONE").execMode("PVAL").execute();

//		flex_relay_control("ALL_PINS","AC","X");

//		LOZ Imped = Low,HIZ Imped = High,HIZ_R
//		FW_TASK("PSLV PRM,0.0,0.5,0.5,LOZ,2,(VDD18_D)"); //FOR DC Scale DPS
//		FW_TASK("PSST ON,(VDD18_D)");
//
//		FW_TASK("PSLV PRM,0.0,0.5,0.5,LOZ,2,(VDD18_D)"); //FOR DC Scale DPS
//		FW_TASK("PSST ON,(VDD33_LDO0)");

		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		//pinList=PinUtility.getDpsPinNamesFromPinList(PowerPinList,TRUE);
		pinList = PinUtility.getDigitalPinNamesFromPinList(PowerPinList,TM::ALL_DIGITAL,true,true);
		for(i=0;i<pinList.size();i++)
		{

			testName = pinList[i];

			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],pmuIfvm.getValue(pinList[i]));
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	for(i=0;i<pinList.size();i++)
	{
		testName = pinList[i];
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],pinList[i],tmLimits,pmuIfvm.getValue(pinList[i])*1e3);
		if(PAT_compare) PAT_Limit_compare(suitName, testName, pinList[i], pmuIfvm.getValue(pinList[i])*1e3, isMultiBin, PAT_soft_bin);
	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("VDD.SPMU_PIN_TASK", VDD_SPMU_PIN_TASK);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class VDD_SPMU_PIN_TASK_LDO_A: public testmethod::TestMethod {
protected:
	string  PowerPinList;
	double 	wait_time;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("Test_PowerPin",
				 "PinString",
				 &PowerPinList,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
				 "double",
				 &wait_time,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	  //Add your test code here.
	  //DPS_TASK meas_VDD;
	  //PMU_IFVM pmuIfvm();
	  SPMU_TASK pmuIfvm;
	  static STRING_VECTOR  pinList;
	  static string suitName,testName;
	  TMLimits::LimitInfo mLimitInfo;
	  string mUnits, mLslTyp, mUslTyp;
	  double LowLimit, HighLimit;
	  double UnitRatio;
	  unsigned int i;

	  ON_FIRST_INVOCATION_BEGIN();
//	  	  LOZ Imped = Low,HIZ Imped = High,HIZ_R
//	  	  FW_TASK("PSLV PRM,0.0,0.5,0.5,LOZ_HIZ,2,(VDD18_A)"); //FOR DC Scale DPS
//	  	  FW_TASK("PSST OFF,(VDD18_A)");
//	  	  CONNECT();
	  	  pinList = PinUtility.getDigitalPinNamesFromPinList(PowerPinList,TM::ALL_DIGITAL,true,true);

	  	  pmuIfvm.pin(PowerPinList).mode("IFVM")
	                       		   .iForce(-10 mA)
	                			   .iForceRange(20 mA)
	                			   .clamp(1500 mV)
	                			   .min(0 mV)
	                			   .max(3300 mV)
	                			   .compare("I")
	                			   .settling(wait_time ms)
	                			   .samples(128)
	                			   .relay("NT");
	  	  pmuIfvm.execMode("PVAL").execute();

//	  	  pmuIfvm.pin(PowerPinList).mode("VM_HIZ").settling(1 ms).samples(128);
//	  	  pmuIfvm.pin(PowerPinList).relay("NT").min(0 V).max(3.3 V);
//	  	  pmuIfvm.preAction("NONE").execMode("PVAL").execute();
//
//	  	  LOZ Imped = Low,HIZ Imped = High,HIZ_R
//	  	  FW_TASK("PSLV PRM,0.0,0.5,0.5,LOZ,2,(VDD18_A)"); //FOR DC Scale DPS
//	  	  FW_TASK("PSST ON,(VDD18_A)");

	  	  GET_TESTSUITE_NAME(suitName);
		ON_FIRST_INVOCATION_END();

		//get test table information
		testName = suitName;

		if(debug)
		{
			cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
			//pinList=PinUtility.getDpsPinNamesFromPinList(PowerPinList,TRUE);
			pinList = PinUtility.getDigitalPinNamesFromPinList(PowerPinList,TM::ALL_DIGITAL,true,true);
			for(i=0;i<pinList.size();i++)
			{

				testName = pinList[i];

				getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
				print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],pmuIfvm.getValue(pinList[i]));
			}
			cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
		}

		for(i=0;i<pinList.size();i++)
		{
			testName = pinList[i];
			TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],pinList[i],tmLimits,pmuIfvm.getValue(pinList[i])*1e3);
			if(PAT_compare) PAT_Limit_compare(suitName, testName, pinList[i], pmuIfvm.getValue(pinList[i])*1e3);
		}

		return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("VDD.SPMU_PIN_TASK_LDO_A", VDD_SPMU_PIN_TASK_LDO_A);

