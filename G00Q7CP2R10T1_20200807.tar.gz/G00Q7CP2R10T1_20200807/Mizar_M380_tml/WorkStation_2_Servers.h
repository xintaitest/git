/*
 * WorkStation_2_Servers.h
 *
 *  Created on: Feb 11, 2019
 *      Author: zzhao
 */

#ifndef WORKSTATION_2_SERVERS_H_
#define WORKSTATION_2_SERVERS_H_

typedef unsigned int uint32_t;
extern int debug;

#ifdef __cplusplus
extern "C"
{
#endif

bool client_servers(int &clifd);
int write_feedback_data(int &clifd, unsigned char *write_data);
int device_key_request(int &clifd, unsigned char *rev_data);


#ifdef __cplusplus
}
#endif


#endif /* WORKSTATION_2_SERVERS_H_ */
