/*
 * Public.h
 *
 *  Created on: Mar 13, 2018
 *      Author: zzhao
 */

#ifndef PUBLIC_H_
#define PUBLIC_H_
#define use_d2s

using namespace V93kLimits;

#define limit_account 300
#define restore_buffer 256
#define ByteSector 1024
#define SectorNum 128
#define write_flash_line 1382
#define write_flash_op 12
#define trim_site 8
#define FT_site 8
#define CP_site 16
#define Flash_Block 1
#define error_code_byte 1
#define chip_ID_byte 16
#define extened_ID_byte 8
#define OTP_byte 144
#define OTP1_byte 104
#define OTP2_byte 4
#define OTP3_byte 32
#define OTP4_byte 4
#define ID_OTP_byte 176
#define version_flag_byte 8
#define OTP_ECC_byte 198
#define Flash_byte 6144
#define Flash_ECC_byte 6912
#define buffer_byte 8192

#define flash_0xff_min 0
#define flash_0xff_typ 1
#define flash_0xff_max 2
#define flash_ckbd_min 3
#define flash_i_ckbd_max 4
#define flash_0x00_typ 5
#define flash_0xff_retest 6
#define flash_final_result 15
#define flash_main_sector_num 512


struct test_point_element
{
	string group_name;
	string LAM_Num;
	string item_name;
	string full_item_name;
	bool isMultiLAM;
	int address;
	int default_data;
	int vtsgroup_data;
	int vtsgroup_high_bit;
	int vtsgroup_low_bit;
	int item_index;
};

struct dynamic_PAT_limit
{
	string suit_name;
	string test_name;
	string pin_name;
	double LCL;
	double UCL;
	double limit_mid;
	double data_restore[restore_buffer];
	int tested_unit;
	int initial_population;
	int restore_ptr;
	int is_limit_calculated;
	int limit_index;
};

struct dynamic_PAT_index
{
	string suit_name;
	string test_name;
	string pin_name;
	int limit_index;
};

struct write_flash_data_index
{
	int data_start;
	int data_end;
};

struct NVR_redundancy_info
{
	int sector_recorded;
	int redundancy_sector;
	int redundancy_valid;
};


extern int debug;
extern int PAT_compare;
extern int print_reg;
extern int isNVR;
extern int restore_account;
extern int Flash_key_byte;
extern int OTP_data_byte;
extern TMLimits::LimitInfo Public_LimitInfo;
extern int d2sFrameworkMode;
extern int limit_initialed;
extern int redundancy_secotr_used;
extern int temp_low_trim[];
extern int temp_high_trim[];
extern int VDD18_low_trim[];
extern int VDD18_high_trim[];
extern int VDD33_low_trim[];
extern int VDD33_high_trim[];
extern int OSC_trim[];
extern int OSC_CP2_trim[CP_site];
extern int OSC_CP3_trim[CP_site];

//EngineeringMode = 0, LearningMode = 1, ProductionMode = 2, DefaultMode = 3
extern test_point_element mTestPointArray[];
extern dynamic_PAT_limit mDynamic_PAT_limit[];
extern dynamic_PAT_index mDynamic_PAT_index[];
extern unsigned char error_code_hex[FT_site][error_code_byte];
extern unsigned char CHIP_ID_hex[FT_site][chip_ID_byte];
extern unsigned char OTP_hex[FT_site][ID_OTP_byte];
extern unsigned char XOR_OTP_hex[FT_site][ID_OTP_byte];
extern unsigned char OTP_ecc_hex[FT_site][OTP_ECC_byte];
extern unsigned char Flash_hex[FT_site][Flash_byte];
extern unsigned char Flash_ecc_hex[FT_site][Flash_ECC_byte];
extern unsigned char versin_flag[FT_site][version_flag_byte];
extern unsigned char versin_ecc_flag[FT_site][version_flag_byte+1];
extern unsigned int Trim_bit[CP_site][Flash_Block];
extern unsigned int redundancy_info_L[CP_site][8];
extern unsigned int redundancy_info_H[CP_site][8];
extern int valid_redundancy_info[CP_site][8];
extern NVR_redundancy_info mNVR_redundancy_info[CP_site][8];

extern bool flash_sector_test_result[CP_site][16][flash_main_sector_num];

uint8_t genecc(uint32_t data0, uint32_t data1);
int serial_flash_write(int flash_num, int ce_oe_we, int control_bit, int addr, int *data);
int serial_flash_read(int flash_num, int ce_oe_we, int contrl, int addr, int *data);
int serial_OTP_read(int ce_oe_we, int contrl, int addr, unsigned int data);
int write_flash(int flash_num, int addr, int *data, int NVR);
int read_flash(int flash_num, int addr, int *data, int NVR);
int write_OTP(int addr, unsigned int data);
int read_OTP(int addr, unsigned int data);
int flash_chip_erase(int flash_num);
int flash_sector_erase(int flash_num, int addr, int NVR);
int OTP_sector_erase(int addr, int NVR);
int OTP_chip_erase();
int serial_OTP_write(int ce_oe_we, int control_bit, int addr, unsigned int data);
int Flash_write_encrypt_key(unsigned char *data, string vector_name);
int Nvr1_write_version_flag(unsigned char *data, string vector_name);

int Flash_read_encrypt_key(unsigned char *data, string vector_name);
int OTP_write(unsigned char *data, string vector_name);
int OTP_read(unsigned char *data, string vector_name);
int Flash_Chip_Erase_Upload(string vector_name, bool isErase);
int XOR_FF(unsigned char *input, int input_length, unsigned char *output);
int insert_ecc_to_data(unsigned char *input, int input_length, unsigned char *output, int &output_length);
int save_encrypt_key_data_to_local_file(string device_type, unsigned char *CHIP_ID_hex,unsigned char *OTP_hex,unsigned char *Flash_hex);
int Set_trim_bit_and_capture_trim_result();
bool compare_all_bit(int OrgData,int WriteData,int StartBit, int EndBit,int FinalRead);
int myItoa(int data, char* p, int num);
int power(int x, int y);
void flex_relay_control(string pin_name ,string ac_status, string dc_status);
int getLimitInfo(string suitName,string testName, double& LowLimit, double& HighLimit, string& Units, double& UnitRatio, string& LslTyp, string& UslTyp);
int getLimitInfo(string suitName,string testName, double& LowLimit, double& HighLimit, string& Units, double& UnitRatio, string& LslTyp, string& UslTyp, int& soft_bin);
int print_datalog_ui_report(string suitName,string testName, double LowLimit, double HighLimit, string Units, double UnitRatio, string LslTyp, string UslTyp, string pinName, double Result);
void initial_dynamic_PAT_limit();
void reset_dynamic_PAT_limit();
int search_limit_index(string suit_name, string test_name, string pin_name);
void calc_limit_PAT(int limit_index);
void restore_limit_data(int limit_index, double restore_data);
void flex_relay_control(string pin_name ,string ac_status, string dc_status);
int pattern_edit_IDD(string label_name, string pin_name, string set_stage);
int NVR2_capture(unsigned int *my_data_L, unsigned int *my_data_H);
int Flash_reload_trim_bit(string vector_name, int FLASH0_Trim_Bit, int FLASH1_Trim_Bit);
int Flash_write_NVR2_redundancy(unsigned char *data, string vector_name);
void clear_mNVR_redundancy_info(int site_Num);
void convert_NVR_data_to_char(unsigned char *NVR_char);
int Read_Bin_File(unsigned char *data,string BinFile);
int Flash_redundancy_data_update(unsigned char *data);
int Flash_redundancy_data_update_sector(unsigned char *data, int sector_mapping);
void OSC_trimming_reg_update(string label_name,int target_osc_code);
void OSC_PLL_out_trimming_reg_update(string label_name,int target_osc_code);
int is_one_hot_code(int input, int bits);
void TS_trimming_reg_update(string label_name);
void VDD_trimming_reg_update(string label_name);
int Flash_write_single_address_pattern_update(unsigned char *data, string vector_name);
int Flash_update_trimming_bits(int site_index, string label_name);
void misc_reg_set(string label_name,unsigned int addr, unsigned int data);
void UART_Protocols(string pattern_name, string cap_vari);
int calculate_clock_freq(string clock_cap_vari, string pin_name, double& clock_freq, double except_freq, int X_mode);
int PAT_Limit_compare(string suitName, string testName, string pinName, double result);
int PAT_Limit_compare(string suitName, string testName, string pinName, double result, int isMultiBin, int PAT_soft_bin);
int PAT_Limit_compare_TestLimit(string suitName, string testName, string pinName, double result, LIMIT testLimit, string mUnits);
int PAT_Limit_compare_TestLimit(string suitName, string testName, string pinName, double result, int isMultiBin, int PAT_soft_bin, LIMIT testLimit, string mUnits);

#endif /* PUBLIC_H_ */
