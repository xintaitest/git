#include <iostream>
#include <assert.h>

#include "TransactionPort.h"
#include "PatternManager.h"
#include "FW.h"
#include "TestMethod.h"

using namespace std;

TransactionPort::sitePortIdPassFailType TransactionPort::globalPassFail;

TransactionPort::TransactionPort(std::string pName)
{
  mCurrentFrameworkMode = d2sFrameWorkModeType::DefaultMode;
  mPortName = pName;
  mCheckPassFail = false;
  mInD2sBlock = false;
  mCycleOffset = 0;
}

TransactionPort::~TransactionPort()
{
}

void TransactionPort::setD2sBlockBegin()
{
  if (mInD2sBlock) {
    cerr << "Error: TransactionPort on port " << mPortName
        << " - No nesting d2s-blocks allowed." << endl;
    assert(!mInD2sBlock);
  }
  mInD2sBlock = true;
}

void TransactionPort::setD2sBlockEnd()
{
  mInD2sBlock = false;
}

const std::string& TransactionPort::getPortName()
{
  return mPortName;
}

string TransactionPort::getPatternStoragePath()
{
  return "";
}


void TransactionPort::preExec(std::string labelName)
{
  //clearing the passFail cache only if testsuite name changed
  static string lastTestSuiteName = "";
  string testSuiteName;
  GET_TESTSUITE_NAME(testSuiteName);
  if (lastTestSuiteName != testSuiteName) {
    lastTestSuiteName = testSuiteName;
    globalPassFail.clear();
  }

  if (mCurrentFrameworkMode == d2sFrameWorkModeType::LearningMode) {
    if (mBurstLabels.size() != 0) {
      PatternManager::createBurst(labelName, mBurstLabels, mPortName, true,
          getPatternStoragePath());
      cerr << "Warning: Don't forget to save the new label." << endl;
    }
    else {
      //noting to create
      //delete Burst if it was available before
      if (PatternManager::isPatternAvailable(labelName, "MAIN", mPortName))
        PatternManager::deleteLabel(labelName, mPortName);
    }
  }
}

void TransactionPort::setFrameworkMode(const d2sFrameWorkModeType::Enum mode)
{
  mCurrentFrameworkMode = mode;
}

void TransactionPort::postExec(std::string executedId,
    bool executionWasSuccessful)
{
  if (mCheckPassFail) {
    //store query focus
    string prevSite;
    fwout << "PQFC?" << endl;
    prevSite = fwresult[0][0];

    //query pass/fail for port and store information
    FOR_EACH_SITE_BEGIN();
    int site = CURRENT_SITE_NUMBER();
    bool passFail = false;
    if(executionWasSuccessful) {
      fwout << "PQFC " << site << endl;
      fwout << "PASS? (" << mPortName << ")" << endl; //would checking global pass/fail (for all ports) first be faster? [PRLT?]
      passFail = (fwresult[0][0]=="P")?true:false;
    }
    else {
      passFail = false;
    }
    pair<map<string, bool>::iterator,bool> ret = globalPassFail[site][mPortName].insert(pair<string, bool> (executedId, passFail));
    if(ret.second == false) {
      //replacing existing value from last execution. Maybe should change stl-map to stl-set?
      globalPassFail[site][mPortName].erase(executedId);
      globalPassFail[site][mPortName].insert(pair<string, bool> (executedId, passFail));
    }
    //cerr << "site " << site << ": result of " << executedId << " for port " << portName << " was " << passFail << endl;
    FOR_EACH_SITE_END();
    //restore query focus
    fwout << "PQFC " << prevSite << endl;
  }

  mCheckPassFail = false;
  mBurstLabels.clear();
  mCycleOffset = 0;
}

void TransactionPort::execLabel(std::string labelName,
    unsigned long long cycles)
{
  if (!mInD2sBlock) {
    cerr << "execLabel can only be used when inside a d2s_LABEL_BEGIN/END-block"
        << endl;
    assert(mInD2sBlock);
  }
  if (mCurrentFrameworkMode != d2sFrameWorkModeType::ProductionMode) {
    //do error checks only in Learning Mode
    if (!PatternManager::isPatternAvailable(labelName, "MAIN", mPortName)) {
      cerr << "Error - execLabel: specificed label \"" << labelName
          << "\" does NOT exist for port \"" << mPortName << "\"!" << endl;
      cerr << "Skipping label from burst" << endl;
      return;
    }
    //check if specified cycles do match the cycles
    unsigned long long smarTestCalculatedCycles =
        PatternManager::getCyclesFromLabel(labelName, mPortName);
    if (smarTestCalculatedCycles != cycles) {
      cerr
          << "Error - execLabel: specificed cycles don't match the label! Subsequent reads will not work correctly!"
          << endl;
      cerr << "SmarTest calculated " << smarTestCalculatedCycles
          << " cycles for label \"" << labelName << "\"";
    }
  }

  mCycleOffset += cycles;
  switch (mCurrentFrameworkMode) {
  case d2sFrameWorkModeType::LearningMode:
    mBurstLabels.push_back(labelName);
    break;
  case d2sFrameWorkModeType::ProductionMode:
    //will run the label later
    break;
  default:
    cerr << "Error! cannot execLabel: wrong state" << endl;
    break;
  }
}

void TransactionPort::wait(double timeInS)
{
  //TODO: Implement wait using wait-sequencer command!
  cerr
      << "wait using sequencer commands not yet implemented for TransactionPort. Cannot be used! Please use DeviceRegisterTransactionPort for the time being."
      << endl;
  assert(false);
}

void TransactionPort::enablePassFailCheckForNextExecution()
{
  mCheckPassFail = true;
}

bool TransactionPort::hasPassed(std::string id)
{
  int site = CURRENT_SITE_NUMBER();
  std::map<std::string, bool>::const_iterator iter(
      globalPassFail[site][mPortName].find(id));
  if (iter != globalPassFail[site][mPortName].end())
    return iter->second;
  else {
    cout << "ERROR: " << mPortName << ": hasPassed() of ID \"" << id
        << "\" not possible! Please switch on passFail-check using >>enablePassFailCheckForNextExecution()<< "
        << endl;
    return false;
  }
}

unsigned long long TransactionPort::getCurrentCycleOffset()
{
  return mCycleOffset;
}

double TransactionPort::getTimingPeriod()
{
  FLUSH();
  fwout << "PCLK? PRM, PRM, (" << getTimingPort() << "), EXACT" << endl;
  if (fwresult.size() != 1) {
    cerr << "ERROR couldn't evaluate timing period for timing-port: "
        << getTimingPort() << endl;
    return 0;
  }
  else {
    return fwresult[0].getDoubleParam(2);
  }
}

double TransactionPort::getCurrentTimeStamp()
{
  return getTimingPeriod() * getCurrentCycleOffset();
}

string TransactionPort::getTimingPort()
{
  return mPortName;
}
