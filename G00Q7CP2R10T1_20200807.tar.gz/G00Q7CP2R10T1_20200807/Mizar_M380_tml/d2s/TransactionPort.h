#ifndef TRANSACTIONPORT_H_
#define TRANSACTIONPORT_H_

#include <string>
#include <vector>
#include <map>
#include "d2sModes.h"

class d2sFramework;

class TransactionPort
{
public:
    TransactionPort(std::string portName);
    virtual ~TransactionPort();
    const std::string& getPortName();
    virtual std::string getPatternStoragePath();
    
    virtual void setFrameworkMode(const d2sFrameWorkModeType::Enum mode);
    virtual void preExec(std::string burstName);
    virtual void postExec(std::string executedId, bool executionWasSuccessful);
    
    virtual void execLabel(std::string labelName, unsigned long long cycles=0);
    virtual void enablePassFailCheckForNextExecution();
    virtual bool hasPassed(std::string id);
    virtual void setD2sBlockBegin();
    virtual void setD2sBlockEnd();
    virtual unsigned long long getCurrentCycleOffset();
    virtual double getCurrentTimeStamp();
    virtual std::string getTimingPort();
    virtual double getTimingPeriod();
    virtual void wait(double timeInS);
    
protected:
    d2sFrameWorkModeType::Enum mCurrentFrameworkMode;
    std::vector<std::string> mBurstLabels;    
    unsigned long long mCycleOffset;
    std::string mPortName;
    bool mInD2sBlock;
    
    bool mCheckPassFail;
    typedef std::map<int, std::map<std::string, std::map<std::string, bool> > > sitePortIdPassFailType;
    static sitePortIdPassFailType globalPassFail;        
            
};

#endif /*TRANSACTIONPORT_H_*/
