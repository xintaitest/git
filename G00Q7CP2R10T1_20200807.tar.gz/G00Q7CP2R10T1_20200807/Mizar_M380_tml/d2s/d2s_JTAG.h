/*
 * d2s_JTAG.h
 *
 *  Created on: Feb 14, 2019
 *      Author: zzhao
 */

#ifndef D2S_JTAG_H_
#define D2S_JTAG_H_

#include "d2s_Serial.h"

class d2s_JTAG : public d2s_Serial{
private:
    d2s_JTAG(std::string pName):d2s_Serial(pName){};
    d2s_JTAG(const d2s_JTAG&);
    d2s_JTAG& operator= (const d2s_JTAG&);

public:
    //singleton
    static d2s_JTAG& Instance(){
        static d2s_JTAG instance("@");
        d2s_JTAG& ref = instance;
        return ref;
    }

    /*general parameters*/
    std::string getPatternStoragePath() { return "d2s_JTAG";}
    int getAddressBits(){ return 16;}
    int getDataBits(){ return 16;}
    int getHighWaveformIndex(){ return 1;}
    int getLowWaveformIndex(){ return 0;}
    int getHighStrobeWaveformIndex(){ return 3;}
    int getLowStrobeWaveformIndex(){ return 2;}
    int getMaskStrobeWaveformIndex(){ return 9;}
    std::string getInterfaceName(){ return "JTAG"; }

    /*write parameters*/
    std::string getWriteTemplatePatternName(){ return "JTAG_write";}
    std::string getWritePinName() { return "JTAG";}
    int getWriteAddressVectorNumberLSB(){ return 71;}
    int getWriteAddressVectorNumberMSB(){ return 56;}
    int getWriteDataVectorNumberLSB(){ return 142;}
    int getWriteDataVectorNumberMSB(){ return 127;}

    /*read parameters*/
    std::string getReadTemplatePatternName(){ return "JTAG_read";}
    std::string getReadAddressPinName() { return "JTAG";}
    std::string getReadPinName() { return "JTAG";}
    int getReadAddressVectorNumberLSB(){ return 71;}
    int getReadAddressVectorNumberMSB(){ return 56;}
    int getReadDataCycleNumberLSB(){ return 142;}
    int getReadDataCycleNumberMSB(){ return 127;}
    int getReadDataVectorNumberLSB(){ return 142;}
    int getReadDataVectorNumberMSB(){ return 127;}

    /*wait parameters*/
    std::string getTimingPort(){ return "@";}
    std::string getWaitTemplatePatternName(){ return "JTAG_wait";}
};


#endif /* D2S_JTAG_H_ */
