#ifndef D2S_GENERIC_H_
#define D2S_GENERIC_H_
#include "DeviceRegisterTransactionPort.h"

 
class d2s_Generic : public DeviceRegisterTransactionPort
{
protected:
    typedef std::pair<std::string, long long> PinVector;
    typedef PinVector PinCycle;
    typedef std::pair<long long, PinVector > BitvaluePinVector;
    typedef BitvaluePinVector BitvaluePinCycle;

    typedef std::multimap<unsigned long long, PinVector > bitvaluePinVector;
    typedef std::map<int, bitvaluePinVector > formatBitvaluePinVectorMapType;
    formatBitvaluePinVectorMapType mWriteAddressValueVectorMap;
    formatBitvaluePinVectorMapType mWriteDataValueVectorMap;
    formatBitvaluePinVectorMapType mReadAndExpectAddressValueVectorMap;
    formatBitvaluePinVectorMapType mReadAndExpectDataValueVectorMap;
    formatBitvaluePinVectorMapType mReadDataValueCycleMap;

    bool mWriteMapInitialized;
    bool mReadAndExpectValueMapInitialized;
    bool mReadCycleMapInitialized;
    int mCurrentFormat;
    std::map<int, unsigned int> mWriteCycles;
    std::map<int, unsigned int> mReadCycles;
	
    d2s_Generic(std::string pName);
    virtual ~d2s_Generic();
    void prepareDynamicWriteLabel(long long address, long long data, const std::string& templatePatternName);
    void prepareDynamicReadOrExpectValueLabel(long long address, const std::string& labelName, long long value=0LL, long long mask=0LL);
    virtual long long readFromErrorMap(int cycleOffset);
    

    /*general parameters*/

    /**
     * @brief getPatternStoragePath specifies the pattern storage path for the transaction port
     *        relative to the "<device>/vectors/" folder.
     *        If the method will not be overwritten, the default vectors folder will be used.
     *
     * This method will return the pattern storage path relative to the "<device>/vectors/" folder
     */
    virtual std::string getPatternStoragePath();

    /**
     * @brief getAddressBits specifies how many bits are used to code the register address
     * 
     * This method has to return the number of address bits
     */        
    virtual int getAddressBits();

    /**
     * @brief getDataBits specifies how many data bits your device register has
     * 
     * This method has to return the number of data bits
     */            
    virtual int getDataBits();

    /**
     * @brief getPadding specifies how many padding vectors are specified in your templates
     * 
     * Default padding is 1.
     * 
     * This method has to return the number of padding vectors
     */      
    virtual int getPadding();

    /**
     * @brief getHighWaveformIndex specifies the waveform index of your wavetable that is used for driving a 1
     */         
    virtual int getHighWaveformIndex();

    /**
     * @brief getLowWaveformIndex specifies the waveform index of your wavetable that is used for driving a 0
     */         
    virtual int getLowWaveformIndex();        

    /**
     * @brief getHighWaveformIndex specifies the waveform index of your wavetable that is used for comparing for a 1
     */         
    virtual int getHighStrobeWaveformIndex();

    /**
     * @brief getLowWaveformIndex specifies the waveform index of your wavetable that is used for comparing for a 0
     */         
    virtual int getLowStrobeWaveformIndex();  
    
    /**
     * @brief getLowWaveformIndex specifies the waveform index of your wavetable that is used for comparing for a X
     */         
    virtual int getMaskStrobeWaveformIndex(); 
    

    /*write parameters*/
    
    virtual void initWriteValueVectorMaps();
    virtual int getWriteCycles();


    /*read parameters*/    

    virtual void initReadAndExpectValueVectorMaps();
    
    
    virtual void initReadValueCycleMaps();
    virtual int getReadCycles();
    
public:
    virtual void setFormat(int format);

};

#endif 
