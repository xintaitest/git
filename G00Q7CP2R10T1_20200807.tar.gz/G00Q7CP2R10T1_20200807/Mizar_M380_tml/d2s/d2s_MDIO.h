#ifndef d2s_MDIO_H_
#define d2s_MDIO_H_
#include "d2s_Serial.h"

class d2s_MDIO : public d2s_Serial{
private:
    d2s_MDIO(std::string pName):d2s_Serial(pName){};
    d2s_MDIO(const d2s_MDIO&);
    d2s_MDIO& operator= (const d2s_MDIO&);

public:    
    //singleton
    static d2s_MDIO& Instance(){
        static d2s_MDIO instance("@");
        d2s_MDIO& ref = instance;
        return ref;
    }
    
    /*general parameters*/
    std::string getPatternStoragePath() { return "d2s_MDIO";}
    int getAddressBits(){ return 16;}
    int getDataBits(){ return 16;}
    int getHighWaveformIndex(){ return 1;}
    int getLowWaveformIndex(){ return 0;}
    int getHighStrobeWaveformIndex(){ return 3;}
    int getLowStrobeWaveformIndex(){ return 2;}
    int getMaskStrobeWaveformIndex(){ return 9;}
    std::string getInterfaceName(){ return "MDIO"; }

    /*write parameters*/
    std::string getWriteTemplatePatternName(){ return "MDIO_write";}
    std::string getWritePinName() { return "MDIO";}
    int getWriteAddressVectorNumberLSB(){ return 71;}
    int getWriteAddressVectorNumberMSB(){ return 56;}
    int getWriteDataVectorNumberLSB(){ return 142;}
    int getWriteDataVectorNumberMSB(){ return 127;}

    /*read parameters*/
    std::string getReadTemplatePatternName(){ return "MDIO_read";}
    std::string getReadAddressPinName() { return "MDIO";}
    std::string getReadPinName() { return "MDIO";}
    int getReadAddressVectorNumberLSB(){ return 71;}
    int getReadAddressVectorNumberMSB(){ return 56;}
    int getReadDataCycleNumberLSB(){ return 142;}
    int getReadDataCycleNumberMSB(){ return 127;}
    int getReadDataVectorNumberLSB(){ return 142;}
    int getReadDataVectorNumberMSB(){ return 127;}
    
    /*wait parameters*/
    std::string getTimingPort(){ return "@";}
    std::string getWaitTemplatePatternName(){ return "MDIO_wait";}
};

#endif
