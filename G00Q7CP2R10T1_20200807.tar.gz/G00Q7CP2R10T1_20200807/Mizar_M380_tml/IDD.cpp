#include "testmethod.hpp"

//for test method API interfaces
#include "mapi.hpp"
#include "Public.h"
using namespace std;
using namespace V93kLimits;


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class IDD_Sleep_IDD_Test: public testmethod::TestMethod {
protected:
	string  PowerPinList;
	double wait_time;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("Test_PowerPin",
				 "PinString",
				 &PowerPinList,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
				 "double",
				 &wait_time,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	DPS_TASK meas_IDD;
	static STRING_VECTOR  pinList;
	static string suitName, testName;
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;
	double LowLimit, HighLimit;
	double UnitRatio;
	double IDD_Sleep;
	unsigned int i;

	ON_FIRST_INVOCATION_BEGIN();
//		FUNCTIONAL_TEST();
//		FW_TASK("rlyc idle,off,(ALL_PINS)\n");
		CONNECT();
		pinList=PinUtility.getDpsPinNamesFromPinList(PowerPinList,TRUE);
		meas_IDD.pin(PowerPinList).measurementMode(TM::MEASURE_CURRENT).min(-10 mA).max(10 mA);
		meas_IDD.wait(wait_time ms).execMode("PVAL").samples(512);
		meas_IDD.execute();

//		flex_relay_control("ALL_PINS","AC","X");
		GET_TESTSUITE_NAME(suitName);

//		FW_TASK("PSLV PRM,0.0,0.5,0.5,LOZ,2,(VDD18_D)"); //FOR DC Scale DPS
//		FW_TASK("PSST ON,(VDD18_D)");
//		FW_TASK("PSLV PRM,0.0,0.5,0.5,LOZ,2,(VDD18_A)"); //FOR DC Scale DPS
//		FW_TASK("PSST ON,(VDD18_A)");

	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(i=0;i<pinList.size();i++)
		{
//			testName = pinList[i];
			getLimitInfo(suitName, pinList[i], LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, pinList[i], LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],meas_IDD.getValue(pinList[i]));
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	IDD_Sleep = 0;
	for(i=0;i<pinList.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],pinList[i],tmLimits,meas_IDD.getValue(pinList[i])*1e3);
		if(PAT_compare) PAT_Limit_compare(suitName, pinList[i], pinList[i], meas_IDD.getValue(pinList[i])*1e3);
//		IDD_Sleep += meas_IDD.getValue(pinList[i])*1e3;
	}

//	TESTSET().cont(true).judgeAndLog_ParametricTest("IDD_Deep_Sleep","IDD_Deep_Sleep",tmLimits,IDD_Sleep);
//	if(PAT_compare) PAT_Limit_compare(suitName, "IDD_Deep_Sleep", "IDD_Deep_Sleep", IDD_Sleep, isMultiBin, PAT_soft_bin);

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("IDD.Sleep_IDD_Test", IDD_Sleep_IDD_Test);

/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class IDD_Active_IDD_Test: public testmethod::TestMethod {
protected:
	string  PowerPinList;
	double wait_time;
	int isMultiBin;
	int PAT_soft_bin;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("Test_PowerPin",
				 "PinString",
				 &PowerPinList,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
				 "double",
				 &wait_time,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("isMultiBin",
				 "int",
				 &isMultiBin,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("soft_bin",
				 "int",
				 &PAT_soft_bin,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	DPS_TASK meas_IDD;
	static STRING_VECTOR  pinList;
	static string suitName, testName;
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;
	double LowLimit, HighLimit;
	double UnitRatio;
	unsigned int i;

	ON_FIRST_INVOCATION_BEGIN();
//		FUNCTIONAL_TEST();
//		FW_TASK("rlyc idle,off,(ALL_PINS)\n");
//		CONNECT();

		pinList=PinUtility.getDpsPinNamesFromPinList(PowerPinList,TRUE);
		meas_IDD.pin(PowerPinList).measurementMode(TM::MEASURE_CURRENT).min(-200 mA).max(200 mA);
		meas_IDD.wait(wait_time ms).execMode("PVAL").samples(128);
		meas_IDD.execute();
		flex_relay_control("ALL_PINS","AC","X");
		GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(i=0;i<pinList.size();i++)
		{
			testName = pinList[i];
			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],meas_IDD.getValue(pinList[i]));
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	for(i=0;i<pinList.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],pinList[i],tmLimits,meas_IDD.getValue(pinList[i])*1e3);
		PAT_Limit_compare(suitName, pinList[i], pinList[i], meas_IDD.getValue(pinList[i])*1e3, isMultiBin, PAT_soft_bin);
	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("IDD.Active_IDD_Test", IDD_Active_IDD_Test);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class IDD_Active_Function_IDD_Test: public testmethod::TestMethod {
protected:
	string  PowerPinList;
	double wait_time;
	int isMultiBin;
	int PAT_soft_bin;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("Test_PowerPin",
				 "PinString",
				 &PowerPinList,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
				 "double",
				 &wait_time,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("isMultiBin",
				 "int",
				 &isMultiBin,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("soft_bin",
				 "int",
				 &PAT_soft_bin,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	DPS_TASK meas_IDD;
	static STRING_VECTOR  pinList;
	static string suitName, testName, testName_PAT;
	static string PAT = "_PAT";
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;
	double LowLimit, HighLimit;
	double UnitRatio;
	unsigned int i;

	ON_FIRST_INVOCATION_BEGIN();
//		FUNCTIONAL_TEST();
//		FW_TASK("rlyc idle,off,(rlyc idle)\n");
//		CONNECT();
//		if(!isMultiLimit)
//		{
//			//LOZ Imped = Low,HIZ Imped = High,HIZ_R
////		FW_TASK("PSLV 101001,0.0,0.2,0.1,LOZ_HIZ_R,5,(VDD18)"); //FOR DC Scale DPS
//			FW_TASK("PSLV 101001,0.0,0.2,LOZ_HIZ_R,2,(VDD18)"); //FOR MS-DPS
//			FW_TASK("PSST OFF,(VDD18)");
//		}

		pinList=PinUtility.getDpsPinNamesFromPinList(PowerPinList,TRUE);
		meas_IDD.preAction("FTST");
		meas_IDD.pin(PowerPinList).measurementMode(TM::MEASURE_CURRENT).min(-200 mA).max(200 mA);
		meas_IDD.execMode("PVAL").samples(16);
		meas_IDD.trigMode(TM::INTERNAL);
		Primary.label("Functional_BIST_IDD");
		FUNCTIONAL_TEST();
		//WAIT_TIME(wait_time ms);

		meas_IDD.execute();

//		flex_relay_control("ALL_PINS","AC","X");
		GET_TESTSUITE_NAME(suitName);

//		if(!isMultiLimit)
//		{
//			FW_TASK("PSLV 101001,1.8,0.2,LOZ_HIZ_R,2,(VDD18)"); //FOR MS-DPS
//			FW_TASK("PSST ON,(VDD18)");
//		}
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(i=0;i<pinList.size();i++)
		{

			testName = pinList[i];

			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],meas_IDD.getValue(pinList[i]));
		}
	}

	for(i=0;i<pinList.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],pinList[i],tmLimits,meas_IDD.getValue(pinList[i])*1e3);
		if(PAT_compare) PAT_Limit_compare(suitName, pinList[i], pinList[i], meas_IDD.getValue(pinList[i])*1e3, isMultiBin, PAT_soft_bin);
	}

//	for(i=0;i<pinList.size();i++)
//	{
//		testName = suitName;
//		limit_index = search_limit_index(suitName, pinList[i], pinList[i]);
//		getLimitInfo(suitName, pinList[i], LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
//
//		if(meas_IDD.getValue(pinList[i])*1e3 >= LowLimit && meas_IDD.getValue(pinList[i])*1e3 <= HighLimit)
//		{
//			restore_limit_data(limit_index, meas_IDD.getValue(pinList[i])*1e3);
//		}
//	}
//
//	if(mDynamic_PAT_limit[limit_index].initial_population == 0)
//	{
//		if(debug) cout<<"initial_population is 0"<<endl;
//		calc_limit_PAT(limit_index);
//		mDynamic_PAT_limit[limit_index].initial_population = restore_account;
//	}
//
//	LIMIT lmt_obj;
//
//	for(i=0;i<pinList.size();i++)
//	{
//		testName = suitName;
//
//		memset(temp,0,128);
//		testName.copy(temp,testName.length(),0);
//		PAT.copy(temp+testName.length(), PAT.length(), 0);
//		testName_PAT = temp;
//
//		limit_index = search_limit_index(suitName, pinList[i], pinList[i]);
//		if(debug) cout<<"is_limit_calculated "<<mDynamic_PAT_limit[limit_index].is_limit_calculated<<endl;
//		if(mDynamic_PAT_limit[limit_index].is_limit_calculated)
//		{
//			if(debug) cout<<"limit low:"<< mDynamic_PAT_limit[limit_index].LCL<<endl;
//			if(debug) cout<<"limit high:"<< mDynamic_PAT_limit[limit_index].UCL<<endl;
//			lmt_obj.low(TM::GE, mDynamic_PAT_limit[limit_index].LCL);
//			lmt_obj.high(TM::LE, mDynamic_PAT_limit[limit_index].UCL);
//			lmt_obj.unit("mA");
//			if(!TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],testName_PAT,lmt_obj,meas_IDD.getValue(pinList[i])*1e3))
//			{
//				SET_MULTIBIN(PAT_soft_bin);
//			}
//		}
//	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("IDD.Active_Function_IDD_Test", IDD_Active_Function_IDD_Test);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class IDD_Active_IDD_Sleep_Debug: public testmethod::TestMethod {
protected:
	string  PowerPinList;
	string  DigitalPinList;
	string  set_stage;
	double wait_time;
	int isMultiLimit;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("Test_PowerPin",
				 "PinString",
				 &PowerPinList,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("DigitalPinList",
				 "PinString",
				 &DigitalPinList,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("set_stage",
				 "string",
				 &set_stage,
				 testmethod::TM_PARAMETER_INPUT)
				 .setOptions("high:low:highZ:Pulse")
				 .setDefault("high");
	addParameter("wait_time",
				 "double",
				 &wait_time,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("isMultiLimit",
				 "int",
				 &isMultiLimit,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	DPS_TASK meas_IDD;
	static STRING_VECTOR  pinList, pinListDig;
	static string suitName,testName;
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;
	double LowLimit, HighLimit;
	double UnitRatio;
	unsigned int i;
	unsigned int Loop_pin;

	pinListDig=PinUtility.getDigitalPinNamesFromPinList(DigitalPinList,TM::ALL_DIGITAL,true,true);

	for(Loop_pin = 0; Loop_pin<pinListDig.size(); Loop_pin++)
	{
		ON_FIRST_INVOCATION_BEGIN();
	//		FUNCTIONAL_TEST();
	//		FW_TASK("rlyc idle,off,(rlyc idle)\n");
			CONNECT();
			if(!isMultiLimit)
			{
				//LOZ Imped = Low,HIZ Imped = High,HIZ_R
//				FW_TASK("PSLV 101001,0.0,0.2,0.1,LOZ_HIZ_R,2,(VDD18)");
				FW_TASK("PSLV 101001,0.0,0.2,LOZ_HIZ_R,2,(VDD18)");
				FW_TASK("PSST OFF,(VDD18)");
			}

			pinList=PinUtility.getDpsPinNamesFromPinList(PowerPinList,TRUE);
			meas_IDD.preAction("FTST");
			meas_IDD.pin(PowerPinList).measurementMode(TM::MEASURE_CURRENT).min(-200 mA).max(200 mA);
			meas_IDD.execMode("PVAL").samples(128);
			meas_IDD.trigMode(TM::INTERNAL);
			pattern_edit_IDD("IDD_sleep", pinListDig[Loop_pin], set_stage);
			FUNCTIONAL_TEST();
			WAIT_TIME(2 ms);
			meas_IDD.execute();

	//		flex_relay_control("ALL_PINS","AC","X");
			GET_TESTSUITE_NAME(suitName);

			if(!isMultiLimit)
			{
//				FW_TASK("PSLV 101001,1.8,0.2,0.1,LOZ_HIZ_R,2,(VDD18)");
				FW_TASK("PSLV 101001,1.8,0.2,LOZ_HIZ_R,2,(VDD18)");
				FW_TASK("PSST ON,(VDD18)");
			}

			pattern_edit_IDD("IDD_sleep", pinListDig[Loop_pin], "highZ");
		ON_FIRST_INVOCATION_END();

		//get test table information
		testName = suitName;

		if(debug)
		{
			//cout<<"Testsuit:"<<suitName<<", test digital pin name "<<pinListDig[Loop_pin]<<" test result:"<<endl;
			for(i=0;i<pinList.size();i++)
			{

				testName = pinList[i];

				getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
				cout<<"digital pin "<<std::left<<std::setw(20)<<pinListDig[Loop_pin];
				print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],meas_IDD.getValue(pinList[i]));
			}
			//cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
		}

		for(i=0;i<pinList.size();i++)
		{
			TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],pinList[i],tmLimits,meas_IDD.getValue(pinList[i])*1e3);
		}
	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("IDD.Active_IDD_Sleep_Debug", IDD_Active_IDD_Sleep_Debug);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class IDD_Power_Short: public testmethod::TestMethod {
protected:
	string  PowerPinList;
	double wait_time;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("Test_PowerPin",
				 "PinString",
				 &PowerPinList,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
				 "double",
				 &wait_time,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	DPS_TASK meas_IDD;
	static STRING_VECTOR  pinList;
	static string suitName,testName;
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;
	double LowLimit, HighLimit;
	double UnitRatio;
	unsigned int i;

	ON_FIRST_INVOCATION_BEGIN();
//		FUNCTIONAL_TEST();
		FW_TASK("rlyc idle,off,(ALL_PINS)\n");
		CONNECT();
		DPS_POWER_STATUS().pin("VDD33_IO,VDD18_D,VDD33_FLASH").on();
		pinList=PinUtility.getDpsPinNamesFromPinList(PowerPinList,TRUE);
		meas_IDD.pin(PowerPinList).measurementMode(TM::MEASURE_CURRENT).min(-100 mA).max(100 mA);
		meas_IDD.wait(wait_time ms).execMode("PVAL").samples(128);
		meas_IDD.execute();
		flex_relay_control("ALL_PINS","AC","X");
		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(i=0;i<pinList.size();i++)
		{
			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],meas_IDD.getValue(pinList[i]));
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	for(i=0;i<pinList.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],testName,tmLimits,meas_IDD.getValue(pinList[i])*1e3);
		if(PAT_compare) PAT_Limit_compare(suitName, testName, pinList[i], meas_IDD.getValue(pinList[i])*1e3);
	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("IDD.Power_Short", IDD_Power_Short);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class IDD_DC_PROFILING: public testmethod::TestMethod {
protected:
	string  PowerPinList;
	double wait_time;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("Test_PowerPin",
				 "PinString",
				 &PowerPinList,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
				 "double",
				 &wait_time,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	DPS_TASK meas_IDD;
	static STRING_VECTOR  pinList;
	static string suitName,testName;
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;
//	double LowLimit, HighLimit;
//	double UnitRatio;
	unsigned int i, j;
	unsigned int samples = 4700;
//	unsigned int samples = 44000;
	unsigned int start_sample = 16;
//	int time_interval = 1;
	double average_VDD[samples];
	double sum_VDD[samples];
	double max_VDD;
	int max_i;

	ON_FIRST_INVOCATION_BEGIN();
		FUNCTIONAL_TEST();
//		FW_TASK("rlyc idle,off,(rlyc idle)\n");
		CONNECT();
		pinList=PinUtility.getDpsPinNamesFromPinList(PowerPinList,TRUE);
		DC_PROFILING_ON(PowerPinList, TM::CURRENT,1 A, 50 us, 1, TM::RESTORE_RANGE);
		FUNCTIONAL_TEST();
		DC_PROFILING_OFF(PowerPinList);
//		flex_relay_control("ALL_PINS","AC","X");
		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;


//	VDD18_D,VDD33_IO,VDD33_FLASH
//	DC_RESULT_ACCESSOR DC_result_VDD33_IO;
//	ARRAY_D currentProfile_VDD33_IO;
//	DC_result_VDD33_IO.uploadResult(pinList[0], TM::RESULT_INDEX);
//	currentProfile_VDD33_IO = DC_result_VDD33_IO.getValues(pinList[0]);

	DC_RESULT_ACCESSOR DC_result;
	ARRAY_D currentProfile;
	//VDD18_D,VDD33_IO,VDD33_FLASH
	for(i=0; i<pinList.size(); i++)
	{
		max_VDD = 0;
		max_i = 0;

		DC_result.uploadResult(pinList[i],TM::RESULT_INDEX);
		currentProfile = DC_result.getValues(pinList[i]);

		sum_VDD[i] = 0;
		for(j=start_sample; j<samples; j++)
		{
			sum_VDD[i] += currentProfile[j];
			dec(cout);
//			cout << "Current profiling values on "<<pinList[i]<<" current["<<j<<"]: "<<setw(10)<<currentProfile[j]<<" mA"<<endl;
			if(currentProfile[j]>max_VDD)
			{
				max_VDD = currentProfile[j];
				max_i = j;
			}
		}
		average_VDD[i] = sum_VDD[i]/(samples-start_sample);

		cout<<"average "<<pinList[i]<<": "<<average_VDD[i]*1e3<<" mA"<<endl;
		cout<<"max "<<pinList[i]<<": "<<max_VDD*1e3<<" mA"<<endl;
		cout<<"max_i: "<<max_i<<endl;
	}

//	if(debug)
//	{
//		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
//		for(i=0;i<pinList.size();i++)
//		{
//
//			testName = pinList[i];
//
//			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
//			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],average_VDD[i]);
//		}
//		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
//	}
//	for(i=0;i<pinList.size();i++)
//	{
//		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],pinList[i],tmLimits,average_VDD[i]*1e3);
//		if(PAT_compare) PAT_Limit_compare(suitName, pinList[i], pinList[i], meas_IDD.getValue(pinList[i])*1e3, 0, 621);
//	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("IDD.DC_PROFILING", IDD_DC_PROFILING);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class IDD_DC_PROFILING_Measure: public testmethod::TestMethod {
protected:
	string  PowerPinList;
	double wait_time;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("Test_PowerPin",
				 "PinString",
				 &PowerPinList,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
				 "double",
				 &wait_time,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	DPS_TASK meas_IDD;
	static STRING_VECTOR  pinList;
	static string suitName,testName;
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;
	double LowLimit, HighLimit;
	double UnitRatio;
	unsigned int i, j;
	unsigned int samples = 800;
	unsigned int start_sample = 16;
	int time_interval = 20;
	double average_VDD[samples];
	double sum_VDD[samples];
	double max_VDD[16];
	int max_i;

	ON_FIRST_INVOCATION_BEGIN();
		FUNCTIONAL_TEST();
//		FW_TASK("rlyc idle,off,(rlyc idle)\n");
		CONNECT();
		pinList=PinUtility.getDpsPinNamesFromPinList(PowerPinList,TRUE);
		DC_PROFILING_ON(pinList[0], TM::CURRENT,1 A, time_interval us, 1, TM::RESTORE_RANGE);
		DC_PROFILING_ON(pinList[1], TM::CURRENT,0.2 A, time_interval us, 1, TM::RESTORE_RANGE);
		DC_PROFILING_ON(pinList[2], TM::CURRENT,0.2 A, time_interval us, 1, TM::RESTORE_RANGE);
		FUNCTIONAL_TEST();

		DC_PROFILING_OFF(PowerPinList);
//		flex_relay_control("ALL_PINS","AC","X");
		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;

	DC_RESULT_ACCESSOR DC_result;
	ARRAY_D currentProfile;
	//VDD18_D,VDD33_IO,VDD33_FLASH
	for(i=0; i<pinList.size(); i++)
	{
		max_VDD[i] = 0;
		max_i = 0;

		DC_result.uploadResult(pinList[i],TM::RESULT_INDEX);
		currentProfile = DC_result.getValues(pinList[i]);

		sum_VDD[i] = 0;
		for(j=start_sample; j<samples; j++)
		{
			sum_VDD[i] += currentProfile[j];
			if(debug)	cout << "Current profiling values on "<<pinList[i]<<" current["<<j<<"]: "<<setw(10)<<currentProfile[j]<<" mA"<<endl;
			if(currentProfile[j]>max_VDD[i])
			{
				max_VDD[i] = currentProfile[j];
				max_i = j;
			}
		}
		average_VDD[i] = sum_VDD[i]/(samples-start_sample);

		if(debug)
		{
			cout<<"average_VDD: "<<average_VDD[i]<<endl;
			cout<<"max_VDD: "<<max_VDD[i]<<endl;
			cout<<"max_i: "<<max_i<<endl;
		}
	}

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(i=0;i<pinList.size();i++)
		{
			testName = pinList[i];
			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],max_VDD[i]);
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	for(i=0;i<pinList.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],pinList[i],tmLimits,max_VDD[i]*1e3);
		if(PAT_compare) PAT_Limit_compare(suitName, pinList[i], pinList[i], max_VDD[i]*1e3);
	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("IDD.DC_PROFILING_Measure", IDD_DC_PROFILING_Measure);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class IDD_Set_DPS_Off: public testmethod::TestMethod {
protected:
	string  PowerPinOn;
	string  PowerPinOff;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("PowerPinOn",
				 "PinString",
				 &PowerPinOn,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("PowerPinOff",
				 "PinString",
				 &PowerPinOff,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		DPS_POWER_STATUS().pin(PowerPinOn).on();
		if(PowerPinOff != "")
		{
			DPS_POWER_STATUS().pin(PowerPinOff).off();
		}
	ON_FIRST_INVOCATION_END();

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("IDD.Set_DPS_Off", IDD_Set_DPS_Off);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class IDD_Set_DPS_Fun: public testmethod::TestMethod {
protected:
	double wait_time;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("wait_time",
				 "double",
				 &wait_time,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();

//		FW_TASK("PSLV PRM,3.3,0.2,HIZ,2,(VDD33_FLASH)");
//		FW_TASK("PSST OFF,(VDD33_FLASH)");

		//power on VDD18_A
		FW_TASK("PSLV PRM,1.8, 0.2, HIZ,0,(VDD18_A)");
		FW_TASK("PSST ON,(VDD18_A)");

//		//power off VDD18_A
//		FW_TASK("PSLV PRM,0.0,0.2,HIZ,0,(VDD18_A)");
//		FW_TASK("PSST OFF,(VDD18_A)");

//		//power on VDD18_D
//		FW_TASK("PSLV PRM,2.1,1,HIZ,0,(VDD18_D)");
//		FW_TASK("PSST ON,(VDD18_D)");

//		if(stage_VDD33_0 == "on")
//		{
//			//power on VDD33_LDO0
//			FW_TASK("PSLV PRM,3.3,0.2,HIZ,0,(VDD33_FLASH)");
//			FW_TASK("PSST ON,(VDD33_FLASH)");
//		}
//		else
//		{
//			//power off VDD33_LDO0
//			FW_TASK("PSLV PRM,0.0,0.2,HIZ,0,(VDD33_FLASH)");
//			FW_TASK("PSST OFF,(VDD33_FLASH)");
//		}
//
//		if(stage_VDD33_1 == "on")
//		{
//			//power on VDD33_LDO1
//			FW_TASK("PSLV PRM,3.3,0.2,HIZ,0,(VDD33_LDO1)");
//			FW_TASK("PSST ON,(VDD33_LDO1)");
//		}
//		else
//		{
//			//power off VDD33_LDO1
//			FW_TASK("PSLV PRM,0.0,0.2,HIZ,0,(VDD33_LDO1)");
//			FW_TASK("PSST OFF,(VDD33_LDO1)");
//		}


	ON_FIRST_INVOCATION_END();

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("IDD.Set_DPS_Fun", IDD_Set_DPS_Fun);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class IDD_Set_DPS_PS: public testmethod::TestMethod {
protected:

  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	  CONNECT();
	  DISCONNECT();
//	ON_FIRST_INVOCATION_BEGIN();
		//power off VDD18_A
		FW_TASK("PSLV PRM,0.0,0.2,HIZ,0,(VDD18_A)");
		FW_TASK("PSST OFF,(VDD18_A)");

		//power on VDD33_IO
		FW_TASK("PSLV PRM,0.3,0.2,HIZ,0,(VDD33_IO)");
		FW_TASK("PSST ON,(VDD33_IO)");

		//power on VDD33_FLASH
		FW_TASK("PSLV PRM,0.3,0.2,HIZ,0,(VDD33_FLASH)");
		FW_TASK("PSST ON,(VDD33_FLASH)");

		//power on VDD18_D
		FW_TASK("PSLV PRM,0.2,0.2,HIZ,0,(VDD18_D)");
		FW_TASK("PSST ON,(VDD18_D)");
//	ON_FIRST_INVOCATION_END();

//	//power off VDD18_D
//	FW_TASK("PSLV PRM,0.0,0.2,HIZ,0,(VDD18_D)");
//	FW_TASK("PSST OFF,(VDD18_D)");

//	//power off VDD33_LDO0
//	FW_TASK("PSLV PRM,0.3,0.2,HIZ,0,(VDD33_LDO0)");
//	FW_TASK("PSST ON,(VDD33_LDO1)");
//	return;
//
//	//power off VDD33_LDO1
//	FW_TASK("PSLV PRM,0.3,0.2,HIZ,0,(VDD33_LDO1)");
//	FW_TASK("PSST ON,(VDD33_LDO1)");
	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("IDD.Set_DPS_PS", IDD_Set_DPS_PS);



/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class IDD_Set_DPS_OS: public testmethod::TestMethod {
protected:

  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {

	ON_FIRST_INVOCATION_BEGIN();
		//power off VDD18_A
		FW_TASK("PSLV PRM,0.0,0.2,HIZ,0,(VDD18_A)");
		FW_TASK("PSST OFF,(VDD18_A)");

		//power on VDD33_IO
		FW_TASK("PSLV PRM,0.0,0.2,HIZ,0,(VDD33_IO)");
		FW_TASK("PSST ON,(VDD33_IO)");

		//power on VDD33_FLASH
		FW_TASK("PSLV PRM,0.0,0.2,HIZ,0,(VDD33_FLASH)");
		FW_TASK("PSST ON,(VDD33_FLASH)");

		//power on VDD18_D
		FW_TASK("PSLV PRM,0.0,0.2,HIZ,0,(VDD18_D)");
		FW_TASK("PSST ON,(VDD18_D)");
	ON_FIRST_INVOCATION_END();

//	//power off VDD18_D
//	FW_TASK("PSLV PRM,0.0,0.2,HIZ,0,(VDD18_D)");
//	FW_TASK("PSST OFF,(VDD18_D)");

//	//power off VDD33_LDO0
//	FW_TASK("PSLV PRM,0.3,0.2,HIZ,0,(VDD33_LDO0)");
//	FW_TASK("PSST ON,(VDD33_LDO1)");
//	return;
//
//	//power off VDD33_LDO1
//	FW_TASK("PSLV PRM,0.3,0.2,HIZ,0,(VDD33_LDO1)");
//	FW_TASK("PSST ON,(VDD33_LDO1)");
	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("IDD.Set_DPS_OS", IDD_Set_DPS_OS);

