/*
 * Public.cpp
 *
 *  Created on: Mar 14, 2018
 *      Author: root
 */

#include "testmethod.hpp"
#include "mapi.hpp"
#include "tml_def.h"
#include "Public.h"
#include "math.h"
#include <stack>
#include "/opt/hp93000/soc/pws/lib/tpi_c.h"
#include "/opt/hp93000/soc/prod_com/include/libcicpi.h"


#if __GNUC__ >= 3
using namespace std;
#endif

int debug = 0;
int PAT_compare = 0;
int print_reg = 1;
int isNVR = 0;
int d2sFrameworkMode = 1;
int limit_initialed = 0;
int Flash_key_byte = Flash_byte;
int OTP_data_byte = OTP_byte;
int temp_low_trim[CP_site];
int temp_high_trim[CP_site];
int VDD18_low_trim[CP_site];
int VDD18_high_trim[CP_site];
int VDD33_low_trim[CP_site];
int VDD33_high_trim[CP_site];
int restore_account = 103;
int first_limit_index = 0;
int last_limit_index = 282;
int redundancy_secotr_used = 0;
int valid_redundancy_info[CP_site][8];
int OSC_CP2_trim[CP_site];
int OSC_CP3_trim[CP_site];
int OSC_trim[CP_site];
unsigned int redundancy_info_L[CP_site][8];
unsigned int redundancy_info_H[CP_site][8];
unsigned int Trim_bit[CP_site][Flash_Block];
unsigned char error_code_hex[FT_site][error_code_byte];
unsigned char CHIP_ID_hex[FT_site][chip_ID_byte];
unsigned char OTP_hex[FT_site][ID_OTP_byte];
unsigned char XOR_OTP_hex[FT_site][ID_OTP_byte];
unsigned char versin_flag[FT_site][version_flag_byte];
unsigned char versin_ecc_flag[FT_site][version_flag_byte+1];
unsigned char OTP_ecc_hex[FT_site][OTP_ECC_byte];
unsigned char Flash_hex[FT_site][Flash_byte];
unsigned char Flash_ecc_hex[FT_site][Flash_ECC_byte];

bool flash_sector_test_result[CP_site][16][flash_main_sector_num];

//EngineeringMode = 0, LearningMode = 1, ProductionMode = 2, DefaultMode = 3
TMLimits::LimitInfo Public_LimitInfo;

int default_RX_PLL = 0x4080;
int default_TX_PLL = 0x408;
int default_RX_NRZ = 0x101;
int default_TX_NRZ = 0x14;
test_point_element mTestPointArray[33];
write_flash_data_index mData_index[write_flash_op] = {
	{30,101},
	{146,217},
	{262,333},
	{378,449},
	{495,566},
	{611,682},
	{727,798},
	{843,914},
	{959,1030},
	{1075,1146},
	{1192,1263},
	{1308,1379}
};
write_flash_data_index mLow_High_index[3] = {
	{14,29},
	{130,145},
	{247,262}
};
write_flash_data_index mNVR2_index[write_flash_op] = {
	{842,913},
	{958,1029},
	{1074,1145},
	{1190,1261},
	{1306,1377},
	{1422,1493},
	{1538,1609},
	{1654,1725},
	{1770,1841},
	{1886,1957},
	{2002,2073},
	{2118,2189}
};

int mOTP_index[5] = {27,100,173,246,320};

NVR_redundancy_info mNVR_redundancy_info[CP_site][8];

dynamic_PAT_index mDynamic_PAT_index[limit_account] = {
	{"Power_Short", "Power_Short", "VDD18_D", 0},
	{"Power_Short", "Power_Short", "VDD33_FLASH", 1},
	{"Power_Short", "Power_Short", "VDD33_IO", 2},
	{"reserver", "reserver", "reserver", 3},
	{"reserver", "reserver", "reserver", 4},
	{"reserver", "reserver", "reserver", 5},
	{"reserver", "reserver", "reserver", 6},
	{"reserver", "reserver", "reserver", 7},
	{"reserver", "reserver", "reserver", 8},
	{"reserver", "reserver", "reserver", 9},
	{"reserver", "reserver", "reserver", 10},
	{"reserver", "reserver", "reserver", 11},
	{"reserver", "reserver", "reserver", 12},
	{"reserver", "reserver", "reserver", 13},
	{"reserver", "reserver", "reserver", 14},
	{"reserver", "reserver", "reserver", 15},
	{"reserver", "reserver", "reserver", 16},
	{"reserver", "reserver", "reserver", 17},
	{"reserver", "reserver", "reserver", 18},
	{"reserver", "reserver", "reserver", 19},
	{"reserver", "reserver", "reserver", 20},
	{"reserver", "reserver", "reserver", 21},
	{"reserver", "reserver", "reserver", 22},
	{"reserver", "reserver", "reserver", 23},
	{"reserver", "reserver", "reserver", 24},
	{"reserver", "reserver", "reserver", 25},
	{"reserver", "reserver", "reserver", 26},
	{"reserver", "reserver", "reserver", 27},
	{"reserver", "reserver", "reserver", 28},
	{"reserver", "reserver", "reserver", 29},
	{"IO_Leakage_High", "IO_Leakage_High", "UART1_RX", 30},
	{"IO_Leakage_High", "IO_Leakage_High", "UART0_RX", 31},
	{"IO_Leakage_High", "IO_Leakage_High", "I2C0_SCL", 32},
	{"IO_Leakage_High", "IO_Leakage_High", "I2C1_SCL", 33},
	{"IO_Leakage_High", "IO_Leakage_High", "GPIO0", 34},
	{"IO_Leakage_High", "IO_Leakage_High", "GPIO1", 35},
	{"IO_Leakage_High", "IO_Leakage_High", "GPIO2", 36},
	{"IO_Leakage_High", "IO_Leakage_High", "GPIO3", 37},
	{"IO_Leakage_High", "IO_Leakage_High", "GPIO4", 38},
	{"IO_Leakage_High", "IO_Leakage_High", "GPIO5", 39},
	{"IO_Leakage_High", "IO_Leakage_High", "SPI0_SCLK", 40},
	{"IO_Leakage_High", "IO_Leakage_High", "SPI0_SI", 41},
	{"IO_Leakage_High", "IO_Leakage_High", "SPI0_SCS", 42},
	{"IO_Leakage_High", "IO_Leakage_High", "SPI1_SCLK", 43},
	{"IO_Leakage_High", "IO_Leakage_High", "SPI1_SI", 44},
	{"IO_Leakage_High", "IO_Leakage_High", "SPI1_SCS", 45},
	{"IO_Leakage_High", "IO_Leakage_High", "SPI2_SCLK", 46},
	{"IO_Leakage_High", "IO_Leakage_High", "SPI2_SI", 47},
	{"IO_Leakage_High", "IO_Leakage_High", "SPI2_SCS", 48},
	{"IO_Leakage_High", "IO_Leakage_High", "SPI3_SCLK", 49},
	{"IO_Leakage_High", "IO_Leakage_High", "SPI3_SI", 50},
	{"IO_Leakage_High", "IO_Leakage_High", "SPI3_SCS", 51},
	{"IO_Leakage_High", "IO_Leakage_High", "reserver", 52},
	{"IO_Leakage_High", "IO_Leakage_High", "reserver", 53},
	{"IO_Leakage_High", "IO_Leakage_High", "reserver", 54},
	{"IO_Leakage_High", "IO_Leakage_High", "reserver", 55},
	{"IO_Leakage_High", "IO_Leakage_High", "reserver", 56},
	{"IO_Leakage_High", "IO_Leakage_High", "reserver", 57},
	{"IO_Leakage_High", "IO_Leakage_High", "reserver", 58},
	{"IO_Leakage_High", "IO_Leakage_High", "reserver", 59},
	{"IO_Leakage_Low", "IO_Leakage_Low", "UART0_RX", 60},
	{"IO_Leakage_Low", "IO_Leakage_Low", "UART1_RX", 61},
	{"IO_Leakage_Low", "IO_Leakage_Low", "I2C0_SCL", 62},
	{"IO_Leakage_Low", "IO_Leakage_Low", "I2C1_SCL", 63},
	{"IO_Leakage_Low", "IO_Leakage_Low", "GPIO0", 64},
	{"IO_Leakage_Low", "IO_Leakage_Low", "GPIO1", 65},
	{"IO_Leakage_Low", "IO_Leakage_Low", "GPIO2", 66},
	{"IO_Leakage_Low", "IO_Leakage_Low", "GPIO3", 67},
	{"IO_Leakage_Low", "IO_Leakage_Low", "GPIO4", 68},
	{"IO_Leakage_Low", "IO_Leakage_Low", "GPIO5", 69},
	{"IO_Leakage_Low", "IO_Leakage_Low", "SPI0_SCLK", 70},
	{"IO_Leakage_Low", "IO_Leakage_Low", "SPI0_SI", 71},
	{"IO_Leakage_Low", "IO_Leakage_Low", "SPI0_SCS", 72},
	{"IO_Leakage_Low", "IO_Leakage_Low", "SPI1_SCLK", 73},
	{"IO_Leakage_Low", "IO_Leakage_Low", "SPI1_SI", 74},
	{"IO_Leakage_Low", "IO_Leakage_Low", "SPI1_SCS", 75},
	{"IO_Leakage_Low", "IO_Leakage_Low", "SPI2_SCLK", 76},
	{"IO_Leakage_Low", "IO_Leakage_Low", "SPI2_SI", 77},
	{"IO_Leakage_Low", "IO_Leakage_Low", "SPI2_SCS", 78},
	{"IO_Leakage_Low", "IO_Leakage_Low", "SPI3_SCLK", 79},
	{"IO_Leakage_Low", "IO_Leakage_Low", "SPI3_SI", 80},
	{"IO_Leakage_Low", "IO_Leakage_Low", "SPI3_SCS", 81},
	{"IO_Leakage_Low", "IO_Leakage_Low", "reserver", 82},
	{"IO_Leakage_Low", "IO_Leakage_Low", "reserver", 83},
	{"IO_Leakage_Low", "IO_Leakage_Low", "reserver", 84},
	{"IO_Leakage_Low", "IO_Leakage_Low", "reserver", 85},
	{"IO_Leakage_Low", "IO_Leakage_Low", "reserver", 86},
	{"IO_Leakage_Low", "IO_Leakage_Low", "reserver", 87},
	{"IO_Leakage_Low", "IO_Leakage_Low", "reserver", 88},
	{"IO_Leakage_Low", "IO_Leakage_Low", "reserver", 89},
	{"Pullup_Resistor", "Pullup_Resistor", "GPIO0", 90},
	{"Pullup_Resistor", "Pullup_Resistor", "GPIO1", 91},
	{"Pullup_Resistor", "Pullup_Resistor", "GPIO2", 92},
	{"Pullup_Resistor", "Pullup_Resistor", "GPIO3", 93},
	{"Pullup_Resistor", "Pullup_Resistor", "GPIO4", 94},
	{"Pullup_Resistor", "Pullup_Resistor", "GPIO5", 95},
	{"Pullup_Resistor", "Pullup_Resistor", "I2C0_SCL", 96},
	{"Pullup_Resistor", "Pullup_Resistor", "I2C0_SDA", 97},
	{"Pullup_Resistor", "Pullup_Resistor", "I2C1_SCL", 98},
	{"Pullup_Resistor", "Pullup_Resistor", "I2C1_SDA", 99},
	{"Pullup_Resistor", "Pullup_Resistor", "SPI0_SCS", 100},
	{"Pullup_Resistor", "Pullup_Resistor", "SPI1_SCS", 101},
	{"Pullup_Resistor", "Pullup_Resistor", "SPI2_SCS", 102},
	{"Pullup_Resistor", "Pullup_Resistor", "SPI3_SCS", 103},
	{"Pullup_Resistor", "Pullup_Resistor", "SPI0_SCLK", 104},
	{"Pullup_Resistor", "Pullup_Resistor", "SPI1_SCLK", 105},
	{"Pullup_Resistor", "Pullup_Resistor", "SPI2_SCLK", 106},
	{"Pullup_Resistor", "Pullup_Resistor", "SPI3_SCLK", 107},
	{"Pullup_Resistor", "Pullup_Resistor", "SPI0_SI", 108},
	{"Pullup_Resistor", "Pullup_Resistor", "SPI1_SI", 109},
	{"Pullup_Resistor", "Pullup_Resistor", "SPI2_SI", 110},
	{"Pullup_Resistor", "Pullup_Resistor", "SPI3_SI", 111},
	{"Pullup_Resistor", "Pullup_Resistor", "TDI", 112},
	{"Pullup_Resistor", "Pullup_Resistor", "TMS", 113},
	{"Pullup_Resistor", "Pullup_Resistor", "TRST", 114},
	{"Pullup_Resistor", "Pullup_Resistor", "UART0_RX", 115},
	{"Pullup_Resistor", "Pullup_Resistor", "UART1_RX", 116},
	{"Pullup_Resistor", "Pullup_Resistor", "CLK_SEL", 117},
	{"Pullup_Resistor", "Pullup_Resistor", "reserver", 118},
	{"Pullup_Resistor", "Pullup_Resistor", "reserver", 119},
	{"Pulldown_Resistor", "Pulldown_Resistor", "GPIO0", 120},  //,,,,,
	{"Pulldown_Resistor", "Pulldown_Resistor", "GPIO1", 121},
	{"Pulldown_Resistor", "Pulldown_Resistor", "GPIO2", 122},
	{"Pulldown_Resistor", "Pulldown_Resistor", "GPIO3", 123},
	{"Pulldown_Resistor", "Pulldown_Resistor", "GPIO4", 124},
	{"Pulldown_Resistor", "Pulldown_Resistor", "GPIO5", 125},
	{"Pulldown_Resistor", "Pulldown_Resistor", "I2C0_SCL", 126},
	{"Pulldown_Resistor", "Pulldown_Resistor", "I2C0_SDA", 127},
	{"Pulldown_Resistor", "Pulldown_Resistor", "I2C1_SCL", 128},
	{"Pulldown_Resistor", "Pulldown_Resistor", "I2C1_SDA", 129},
	{"Pulldown_Resistor", "Pulldown_Resistor", "SPI0_SCLK", 130},
	{"Pulldown_Resistor", "Pulldown_Resistor", "SPI1_SCLK", 131},
	{"Pulldown_Resistor", "Pulldown_Resistor", "SPI2_SCLK", 132},
	{"Pulldown_Resistor", "Pulldown_Resistor", "SPI3_SCLK", 133},
	{"Pulldown_Resistor", "Pulldown_Resistor", "SPI0_SCS", 134},
	{"Pulldown_Resistor", "Pulldown_Resistor", "SPI1_SCS", 135},
	{"Pulldown_Resistor", "Pulldown_Resistor", "SPI2_SCS", 136},
	{"Pulldown_Resistor", "Pulldown_Resistor", "SPI3_SCS", 137},
	{"Pulldown_Resistor", "Pulldown_Resistor", "SPI0_SI", 138},
	{"Pulldown_Resistor", "Pulldown_Resistor", "SPI1_SI", 139},
	{"Pulldown_Resistor", "Pulldown_Resistor", "SPI2_SI", 140},
	{"Pulldown_Resistor", "Pulldown_Resistor", "SPI3_SI", 141},
	{"Pulldown_Resistor", "Pulldown_Resistor", "UART0_RX", 142},
	{"Pulldown_Resistor", "Pulldown_Resistor", "UART1_RX", 143},
	{"Pulldown_Resistor", "Pulldown_Resistor", "TCK", 144},
	{"Pulldown_Resistor", "Pulldown_Resistor", "reserver", 145},
	{"Pulldown_Resistor", "Pulldown_Resistor", "reserver", 146},
	{"Pulldown_Resistor", "Pulldown_Resistor", "reserver", 147},
	{"Pulldown_Resistor", "Pulldown_Resistor", "reserver", 148},
	{"Pulldown_Resistor", "Pulldown_Resistor", "reserver", 149},
	{"VOH_G1", "VOH_G1", "GPIO0", 150},
	{"VOH_G1", "VOH_G1", "GPIO1", 151},
	{"VOH_G1", "VOH_G1", "GPIO2", 152},
	{"VOH_G1", "VOH_G1", "GPIO3", 153},
	{"VOH_G1", "VOH_G1", "GPIO4", 154},
	{"VOH_G1", "VOH_G1", "GPIO5", 155},
	{"VOH_G1", "VOH_G1", "GPIO6", 156},
	{"VOH_G1", "VOH_G1", "GPIO7", 157},
	{"VOH_G1", "VOH_G1", "I2C0_SCL", 158},
	{"VOH_G1", "VOH_G1", "I2C0_SDA", 159},
	{"VOH_G1", "VOH_G1", "I2C1_SCL", 160},
	{"VOH_G1", "VOH_G1", "I2C1_SDA", 161},
	{"VOH_G1", "VOH_G1", "POR_N", 162},
	{"VOH_G1", "VOH_G1", "UART0_RX", 163},
	{"VOH_G1", "VOH_G1", "UART0_TX", 164},
	{"VOH_G1", "VOH_G1", "UART1_RX", 165},
	{"VOH_G1", "VOH_G1", "UART1_TX", 166},
	{"VOH_G2", "VOH_G2", "SPI0_SCLK", 167},
	{"VOH_G2", "VOH_G2", "SPI0_SCS", 168},
	{"VOH_G2", "VOH_G2", "SPI0_SI", 169},
	{"VOH_G2", "VOH_G2", "SPI0_SO", 170},
	{"VOH_G2", "VOH_G2", "SPI1_SCLK", 171},
	{"VOH_G2", "VOH_G2", "SPI1_SCS", 172},
	{"VOH_G2", "VOH_G2", "SPI1_SI", 173},
	{"VOH_G2", "VOH_G2", "SPI1_SO", 174},
	{"VOH_G2", "VOH_G2", "SPI2_SCLK", 175},
	{"VOH_G2", "VOH_G2", "SPI2_SCS", 176},
	{"VOH_G2", "VOH_G2", "SPI2_SI", 177},
	{"VOH_G2", "VOH_G2", "SPI2_SO", 178},
	{"VOH_G2", "VOH_G2", "SPI3_SCLK", 179},
	{"VOH_G2", "VOH_G2", "SPI3_SCS", 180},
	{"VOH_G2", "VOH_G2", "SPI3_SI", 181},
	{"VOH_G2", "VOH_G2", "SPI3_SO", 182},
	{"VOH", "VOH", "UART1_RX", 183},
	{"VOH", "VOH", "UART1_TX", 184},
	{"VOH", "VOH", "I2C1_SCL", 185},
	{"VOH", "VOH", "GPIO1", 186},
	{"VOH", "VOH", "GPIO2", 187},
	{"VOH", "VOH", "GPIO6", 188},
	{"VOH", "VOH", "GPIO7", 189},
	{"VOH", "VOH", "SPI0_SCLK", 190},
	{"VOH", "VOH", "SPI0_SI", 191},
	{"VOH", "VOH", "SPI0_SO", 192},
	{"VOH", "VOH", "SPI0_SCS", 193},
	{"VOH", "VOH", "SPI1_SCLK", 194},
	{"VOH", "VOH", "SPI1_SI", 195},
	{"VOH", "VOH", "SPI1_SO", 196},
	{"VOH", "VOH", "SPI1_SCS", 197},
	{"VOH", "VOH", "reserver", 198},
	{"VOH", "VOH", "reserver", 199},
	{"VOH", "VOH", "reserver", 200},
	{"VOH", "VOH", "reserver", 201},
	{"VOH", "VOH", "reserver", 202},
	{"VOH", "VOH", "reserver", 203},
	{"VOH", "VOH", "reserver", 204},
	{"VOH", "VOH", "reserver", 205},
	{"VOH", "VOH", "reserver", 206},
	{"VOH", "VOH", "reserver", 207},
	{"VOH", "VOH", "reserver", 208},
	{"VOH", "VOH", "reserver", 209},
	{"VOH", "VOH", "reserver", 210},
	{"VOH", "VOH", "reserver", 211},
	{"VOH", "VOH", "reserver", 212},
	{"VOH", "VOH", "reserver", 213},
	{"VOH", "VOH", "reserver", 214},
	{"VOH", "VOH", "reserver", 215},
	{"VOH", "VOH", "reserver", 216},
	{"VOH", "VOH", "reserver", 217},
	{"VOH", "VOH", "reserver", 218},
	{"VOH", "VOH", "reserver", 219},
	{"VOL", "VOL", "GPIO2", 220},
	{"VOL", "VOL", "GPIO3", 221},
	{"VOL", "VOL", "GPIO4", 222},
	{"VOL", "VOL", "GPIO5", 223},
	{"VOL", "VOL", "GPIO6", 224},
	{"VOL", "VOL", "GPIO7", 225},
	{"VOL", "VOL", "I2C0_SCL", 226},
	{"VOL", "VOL", "I2C0_SDA", 227},
	{"VOL", "VOL", "I2C1_SCL", 228},
	{"VOL", "VOL", "I2C1_SDA", 229},
	{"VOL", "VOL", "POR_N", 230},
	{"VOL", "VOL", "SPI0_SCLK", 231},
	{"VOL", "VOL", "SPI0_SCS", 232},
	{"VOL", "VOL", "SPI0_SI", 233},
	{"VOL", "VOL", "SPI0_SO", 234},
	{"VOL", "VOL", "SPI1_SCLK", 235},
	{"VOL", "VOL", "SPI1_SCS", 236},
	{"VOL", "VOL", "SPI1_SI", 237},
	{"VOL", "VOL", "SPI1_SO", 238},
	{"VOL", "VOL", "SPI2_SCLK", 239},
	{"VOL", "VOL", "SPI2_SCS", 240},
	{"VOL", "VOL", "SPI2_SI", 241},
	{"VOL", "VOL", "SPI2_SO", 242},
	{"VOL", "VOL", "SPI3_SCLK", 243},
	{"VOL", "VOL", "SPI3_SCS", 244},
	{"VOL", "VOL", "SPI3_SI", 245},
	{"VOL", "VOL", "SPI3_SO", 246},
	{"VOL", "VOL", "UART0_RX", 247},
	{"VOL", "VOL", "UART0_TX", 248},
	{"VOL", "VOL", "UART1_RX", 249},
	{"VOL", "VOL", "UART1_TX", 250},
	{"VOL", "VOL", "GPIO1", 251},
	{"reserver", "reserver", "reserver", 252},
	{"reserver", "reserver", "reserver", 253},
	{"reserver", "reserver", "reserver", 254},
	{"reserver", "reserver", "reserver", 255},
	{"reserver", "reserver", "reserver", 256},
	{"reserver", "reserver", "reserver", 257},
	{"reserver", "reserver", "reserver", 258},
	{"reserver", "reserver", "reserver", 259},
	{"IDD_Deep_Sleep", "VDD18_D", "VDD18_D", 260},
	{"IDD_Deep_Sleep", "VDD33_FLASH", "VDD33_FLASH", 261},
	{"IDD_Deep_Sleep", "VDD33_IO", "VDD33_IO", 262},
	{"reserver", "reserver", "reserver", 263},
	{"reserver", "reserver", "reserver", 265},
	{"reserver", "reserver", "reserver", 266},
	{"reserver", "reserver", "reserver", 267},
	{"reserver", "reserver", "reserver", 268},
	{"reserver", "reserver", "reserver", 269},
	{"IDD_Active", "VDD33_FLASH", "VDD33_FLASH", 270},
	{"IDD_Active", "VDD33_IO", "VDD33_IO", 271},
	{"IDD_Active", "VDD18_D", "VDD18_D", 272},
	{"reserver", "reserver", "reserver", 273},
	{"reserver", "reserver", "reserver", 274},
	{"reserver", "reserver", "reserver", 275},
	{"reserver", "reserver", "reserver", 276},
	{"reserver", "reserver", "reserver", 277},
	{"reserver", "reserver", "reserver", 278},
	{"reserver", "reserver", "reserver", 279},
	{"LDO_D0_Test", "VDD18_D_SIG", "VDD18_D_SIG", 280},
	{"LDO_D1_Test", "VDD18_D_SIG", "VDD18_D_SIG", 281},
	{"LDO_A_Test", "VDD18_A_SIG", "VDD18_A_SIG", 282},
	{"reserver", "reserver", "reserver", 283},
	{"reserver", "reserver", "reserver", 284},
	{"reserver", "reserver", "reserver", 285},
	{"reserver", "reserver", "reserver", 286},
	{"reserver", "reserver", "reserver", 287},
	{"reserver", "reserver", "reserver", 288},
	{"reserver", "reserver", "reserver", 289},
	{"reserver", "reserver", "reserver", 290},
	{"reserver", "reserver", "reserver", 291},
	{"reserver", "reserver", "reserver", 292},
	{"reserver", "reserver", "reserver", 293},
	{"reserver", "reserver", "reserver", 294},
	{"reserver", "reserver", "reserver", 295},
	{"reserver", "reserver", "reserver", 296},
	{"reserver", "reserver", "reserver", 297},
	{"reserver", "reserver", "reserver", 298},
	{"reserver", "reserver", "reserver", 299}
};


dynamic_PAT_limit mDynamic_PAT_limit[limit_account];

void initial_dynamic_PAT_limit()
{
	for(int i = 0; i<limit_account; i++)
	{
		mDynamic_PAT_limit[i].suit_name = mDynamic_PAT_index[i].suit_name;
		mDynamic_PAT_limit[i].test_name = mDynamic_PAT_index[i].test_name;
		mDynamic_PAT_limit[i].pin_name = mDynamic_PAT_index[i].pin_name;
		mDynamic_PAT_limit[i].limit_index = mDynamic_PAT_index[i].limit_index;
		mDynamic_PAT_limit[i].LCL = 0;
		mDynamic_PAT_limit[i].UCL = 0;
		mDynamic_PAT_limit[i].limit_mid = 0;
		mDynamic_PAT_limit[i].tested_unit = 0;
		mDynamic_PAT_limit[i].initial_population = restore_account;
		mDynamic_PAT_limit[i].restore_ptr = 0;
		mDynamic_PAT_limit[i].is_limit_calculated = 0;

		for(int j=0; j<restore_buffer; j++)
		{
			mDynamic_PAT_limit[i].data_restore[j] = 0;
		}
	}
	cout<<"Limit initialed for test program first run."<<endl;
}

void reset_dynamic_PAT_limit()
{
	for(int i = 0; i<limit_account; i++)
	{
		mDynamic_PAT_limit[i].tested_unit = 0;

		for(int j=0; j<restore_buffer; j++)
		{
			mDynamic_PAT_limit[i].data_restore[j] = 0;
		}
	}
}

int search_limit_index(string suit_name, string test_name, string pin_name)
{
	int limit_index = 9999;
	for(int i=0; i<limit_account; i++)
	{
		if((mDynamic_PAT_index[i].suit_name == suit_name) && (mDynamic_PAT_index[i].test_name == test_name) && (mDynamic_PAT_index[i].pin_name == pin_name))
		{
			limit_index = mDynamic_PAT_index[i].limit_index;
			break;
		}
	}
	if(debug)
	{
		dec(cout);
		cout<<"limit_index = "<<limit_index<<endl;
		cout<<"suit_name : "<<suit_name<<endl;
		cout<<"test_name : "<<test_name<<endl;
		cout<<"pin_name : "<<pin_name<<endl;
	}
	if(limit_index == 9999)
	{
		cout<<"error, limit index not found!"<<endl;
	}
	return limit_index;
}

void restore_limit_data(int limit_index, double restore_data)
{
	if(mDynamic_PAT_limit[limit_index].initial_population != 0)
	{
		mDynamic_PAT_limit[limit_index].data_restore[mDynamic_PAT_limit[limit_index].restore_ptr] = restore_data;
		mDynamic_PAT_limit[limit_index].restore_ptr++;
		mDynamic_PAT_limit[limit_index].initial_population--;
	}

	if(debug) cout<<"restore_data = "<<restore_data<<endl;
	if(debug) cout<<"restore_ptr = "<<mDynamic_PAT_limit[limit_index].restore_ptr<<endl;
	if(debug) cout<<"initial_population = "<<mDynamic_PAT_limit[limit_index].initial_population<<endl;
}

void calc_limit_PAT(int limit_index)
{
	double robust_mean, robust_Q1, robust_Q3, robust_sigma;
	double robust_factor = 1.35;
	double temp;

	for(int i=0; i<restore_account; i++)
	{
		for(int j=0; j<restore_account-i-1;j++)
		{
			if(mDynamic_PAT_limit[limit_index].data_restore[j]>mDynamic_PAT_limit[limit_index].data_restore[j+1])
			{
				temp = mDynamic_PAT_limit[limit_index].data_restore[j];
				mDynamic_PAT_limit[limit_index].data_restore[j] = mDynamic_PAT_limit[limit_index].data_restore[j+1];
				mDynamic_PAT_limit[limit_index].data_restore[j+1] = temp;
			}
		}
	}

	if(restore_account%2==0)
	{
		robust_mean = (mDynamic_PAT_limit[limit_index].data_restore[restore_account/2-1]+mDynamic_PAT_limit[limit_index].data_restore[restore_account/2])/2;
	}
	else
	{
		robust_mean = mDynamic_PAT_limit[limit_index].data_restore[(restore_account-1)/2];
	}

	robust_Q1 = mDynamic_PAT_limit[limit_index].data_restore[(restore_account+1)/4-1];
	robust_Q3 = mDynamic_PAT_limit[limit_index].data_restore[(restore_account+1)*3/4-1];

	robust_sigma = abs((robust_Q3-robust_Q1))/robust_factor;

	if(robust_sigma == 0)
	{
		robust_sigma = 0.0005;
	}

	mDynamic_PAT_limit[limit_index].LCL = robust_mean-6*robust_sigma;
	mDynamic_PAT_limit[limit_index].UCL = robust_mean+6*robust_sigma;
	mDynamic_PAT_limit[limit_index].limit_mid = robust_mean;
	mDynamic_PAT_limit[limit_index].is_limit_calculated = 1;
	mDynamic_PAT_limit[limit_index].restore_ptr = 0;

	if(debug) cout<<"robust_mean = "<<robust_mean<<endl;
	if(debug) cout<<"robust_sigma = "<<robust_sigma<<endl;
}

uint8_t genecc(uint32_t data0, uint32_t data1)
{
  uint32_t C0x     = 0xCB4B34E9;
  uint32_t C01     = 0xAAAAAAD5;
  uint32_t C02     = 0x999999B3;
  uint32_t C04     = 0x8787878F;
  uint32_t C08     = 0x7F807F80;
  uint32_t C016    = 0x007FFF80;
  uint32_t C032    = 0xFFFFFF80;
  uint32_t C064    = 0x0000007F;
  uint32_t C1x     = 0xED3A65B4;
  uint32_t C11     = 0xDAB5556A;
  uint32_t C12     = 0xB66CCCD9;
  uint32_t C14     = 0x71E3C3C7;
  uint32_t C18     = 0x0FE03FC0;
  uint32_t C116    = 0x001FFFC0;
  uint32_t C132    = 0x0000003F;
  uint32_t C164    = 0x00000000;
  uint8_t  ecc;

  uint32_t eccout00, eccout01, eccout02, eccout03, eccout04, eccout05, eccout06, eccout07;
  uint32_t eccout10, eccout11, eccout12, eccout13, eccout14, eccout15, eccout16, eccout17;
  uint32_t tmp, i;

  eccout00 = data0 & C0x;
  eccout01 = data0 & C01;
  eccout02 = data0 & C02;
  eccout03 = data0 & C04;
  eccout04 = data0 & C08;
  eccout05 = data0 & C016;
  eccout06 = data0 & C032;
  eccout07 = data0 & C064;

  eccout10 = data1 & C1x;
  eccout11 = data1 & C11;
  eccout12 = data1 & C12;
  eccout13 = data1 & C14;
  eccout14 = data1 & C18;
  eccout15 = data1 & C116;
  eccout16 = data1 & C132;
  eccout17 = data1 & C164;

  for (i = 1, tmp = (eccout00 >> 1); i < 32; i++, tmp >>= 1) {
    eccout00 ^= tmp;
  }
  for (i = 0, tmp = (eccout10); i < 32; i++, tmp >>= 1) {
    eccout00 ^= tmp;
  }

  for (i = 1, tmp = (eccout01 >> 1); i < 32; i++, tmp >>= 1) {
    eccout01 ^= tmp;
  }
  for (i = 0, tmp = (eccout11); i < 32; i++, tmp >>= 1) {
    eccout01 ^= tmp;
  }

  for (i = 1, tmp = (eccout02 >> 1); i < 32; i++, tmp >>= 1) {
    eccout02 ^= tmp;
  }
  for (i = 0, tmp = (eccout12); i < 32; i++, tmp >>= 1) {
    eccout02 ^= tmp;
  }

  for (i = 1, tmp = (eccout03 >> 1); i < 32; i++, tmp >>= 1) {
    eccout03 ^= tmp;
  }
  for (i = 0, tmp = (eccout13); i < 32; i++, tmp >>= 1) {
    eccout03 ^= tmp;
  }

  for (i = 1, tmp = (eccout04 >> 1); i < 32; i++, tmp >>= 1) {
    eccout04 ^= tmp;
  }
  for (i = 0, tmp = (eccout14); i < 32; i++, tmp >>= 1) {
    eccout04 ^= tmp;
  }

  for (i = 1, tmp = (eccout05 >> 1); i < 32; i++, tmp >>= 1) {
    eccout05 ^= tmp;
  }
  for (i = 0, tmp = (eccout15); i < 32; i++, tmp >>= 1) {
    eccout05 ^= tmp;
  }

  for (i = 1, tmp = (eccout06 >> 1); i < 32; i++, tmp >>= 1) {
    eccout06 ^= tmp;
  }
  for (i = 0, tmp = (eccout16); i < 32; i++, tmp >>= 1) {
    eccout06 ^= tmp;
  }

  for (i = 1, tmp = (eccout07 >> 1); i < 32; i++, tmp >>= 1) {
    eccout07 ^= tmp;
  }
  for (i = 0, tmp = (eccout17); i < 32; i++, tmp >>= 1) {
    eccout07 ^= tmp;
  }

  ecc = (eccout00 & 0x1) | ((eccout01 & 0x1) << 1) | ((eccout02 & 0x1) << 2) | ((eccout03 & 0x1) << 3) |
        ((eccout04 & 0x1) << 4) | ((eccout05 & 0x1) << 5) | ((eccout06 & 0x1) << 6) | ((eccout07 & 0x1) << 7);

  return ecc;
}

int calc_11bit_to_dec(int prog, int prog2, int erase, int chip, int NVR, int TMEN, int DPSTB, int BYTE0, int BYTE1, int BYTE2,int BYTE3)
{
	int calc_contrl;
	calc_contrl = prog + prog2<<1 + erase<<2 + chip<<3 + NVR <<4 + TMEN<<5 + DPSTB<<6 + BYTE0<<7 + BYTE1<<8 + BYTE2<<9 + BYTE3<<10;
	return calc_contrl;
}

int power(int x, int y)
{
    if (y == 0) return 1;
    else
    {
         while(--y)
        {
            x= x*2;
            //cout<<"x = "<<dec<<x<<endl;
        }
    }
    return x;
}

int myItoa(int data, char* p, int num)
{
    if (p == NULL)
    {
        return -1;
    }
    if (data < 0)
    {
        *p++ = '-';
        data = 0 - data;
    }
    int temp = 0;
    int flag = 0;
    if (num == 10)
    {//dec
        for (int i = 0; i < 10; i++)
        {
            temp = static_cast<int>(data / pow(10.0, 9-i));// pow(i,j),
            if (temp != 0)
            {
                flag = 1;
            }
            if (flag != 0)
            {
            	p[9 - i] = temp + '0';
                data = data % static_cast<int>(pow(10.0, 9-i));
            }
        }
    }

    else if (num == 2)
    {//binal
    	//cout<<"enter binary flow"<<endl;
    	for (int i = 0; i < 32; i++)
        {
            temp = static_cast<int>(data / pow(2.0, 31 - i)); //int
            if (temp != 0)
            {
                flag = 1;
            }
            if (flag != 0)
            {
                p[31 - i] = temp + '0';
                data = data % static_cast<int>(pow(2.0, 31 - i));
            }
        }
    }
    else if (num == 16)
    {//hex
        for (int i = 0; i < 8; i++)
        {
            temp = static_cast<int>(data / pow(16.0, 7-i));
            if (temp != 0)
            {
                flag = 1;
            }
            if (flag != 0)
            {
                if (temp >= 0 && temp <= 9)
                {
                    p[7-i] = temp + '0';
                }
                else if (temp >= 10 && temp <= 15)
                {
                	p[7-i] = temp - 10 + 'A';
                }
                data = data % static_cast<int>(pow(16.0, 7 - i));
            }
        }
    }
    else if (num == 8)
    {//
        for (int i = 0; i < 16; i++)
        {
            temp = static_cast<int>(data / pow(8.0, 15-i));
            if (temp != 0)
            {
                flag = 1;
            }
            if (flag != 0)
            {
            	p[16 - i] = temp + '0';
                data = data % static_cast<int>(pow(8.0, 15-i));
            }
        }
    }
    return 0;
}

bool compare_all_bit(int OrgData,int WriteData,int LowBit, int HighBit, int reg_bit,int FinalRead)
{
	int i=0;
	bool fail_flag = 0;
	char OrgBin[reg_bit],FinalBin[reg_bit],WriteBin[reg_bit];

	memset(OrgBin,'0',reg_bit);
	memset(FinalBin,'0',reg_bit);
	memset(WriteBin,'0',reg_bit);

	myItoa(OrgData,OrgBin,2);
	myItoa(FinalRead,FinalBin,2);
	myItoa(WriteData,WriteBin,2);

	for (i=0;i<reg_bit;i++)
	{
		if ((i < LowBit) || (i > HighBit))
		{
			if (OrgBin[i] != FinalBin[i])
			{
				fail_flag = 1;
			}
		}
		else
		{
			if (FinalBin[i] != WriteBin[i-LowBit])
			{
                if (print_reg)
                {
				    cout<<"not equal Final bit["<<i<<"] = "<<FinalBin[i]<<endl;
                }
                fail_flag = 1;
			}
		}
	}
	if (fail_flag) return 0;
	else return 1;
}

void convert_NVR_data_to_char(unsigned char *NVR_char)
{
	for(int i=0; i<8; i++)
	{
		if(debug)
		{
			hex(cout);
			cout<<"Redundancy redundancy info H["<<i<<"] = 0x"<<redundancy_info_H[CURRENT_SITE_NUMBER()-1][i]
		        <<"; Redundancy redundancy info L["<<i<<"] = 0x"<<redundancy_info_L[CURRENT_SITE_NUMBER()-1][i]<<endl;
		}

		*(NVR_char+i*8+0) = redundancy_info_L[CURRENT_SITE_NUMBER()-1][i]&0xff;
		*(NVR_char+i*8+1) = (redundancy_info_L[CURRENT_SITE_NUMBER()-1][i]&0xff00)>>8;
		*(NVR_char+i*8+2) = (redundancy_info_L[CURRENT_SITE_NUMBER()-1][i]&0xff0000)>>16;
		*(NVR_char+i*8+3) = (redundancy_info_L[CURRENT_SITE_NUMBER()-1][i]&0xff000000)>>24;

		*(NVR_char+i*8+4) = redundancy_info_H[CURRENT_SITE_NUMBER()-1][i]&0xff;
		*(NVR_char+i*8+5) = (redundancy_info_H[CURRENT_SITE_NUMBER()-1][i]&0xff00)>>8;
		*(NVR_char+i*8+6) = (redundancy_info_H[CURRENT_SITE_NUMBER()-1][i]&0xff0000)>>16;
		*(NVR_char+i*8+7) = (redundancy_info_H[CURRENT_SITE_NUMBER()-1][i]&0xff000000)>>24;
	}
}

int insert_ecc_to_data(unsigned char *input, int input_length, unsigned char *output, int &output_length)
{
	unsigned int data0, data1;
	unsigned char char_ecc;
	int i_compl;

	for(int i=0; i<input_length; i=i+8)
	{
		data0 = *(input+i) + (*(input+i+1)<<8) + (*(input+i+2)<<16) + (*(input+i+3)<<24);
		data1 = *(input+i+4) + (*(input+i+5)<<8) + (*(input+i+6)<<16) + (*(input+i+7)<<24);
		char_ecc = genecc(data0, data1);

		i_compl = (int) (i/8);
		*(output+i_compl*9) = *(input+i);
		*(output+i_compl*9+1) = *(input+i+1);
		*(output+i_compl*9+2) = *(input+i+2);
		*(output+i_compl*9+3) = *(input+i+3);
		*(output+i_compl*9+4) = *(input+i+4);
		*(output+i_compl*9+5) = *(input+i+5);
		*(output+i_compl*9+6) = *(input+i+6);
		*(output+i_compl*9+7) = *(input+i+7);
		*(output+i_compl*9+8) = char_ecc;
	}
	output_length = i_compl*9+9;

	return 0;
}

int Set_trim_bit_and_capture_trim_result()
{
//    int HIGH_WFIndex = 1;
//    int LOW_WFIndex = 0;
//    int mask,vecNum;

    return 0;
}

void flex_relay_control(string pin_name ,string ac_status, string dc_status)
{
	FLEX_RELAY  relay;
	TASK_LIST task;
	ARRAY_I sites;
	GET_TEST_FOCUS(sites);
	SET_TEST_FOCUS(sites);
	relay.pin(pin_name).set(ac_status,dc_status);
	task.add(relay).execute();
}

//int Read_Bin_File(unsigned char *data,char *DeviceType,int PageCount)
int Read_Bin_File(unsigned char *data,string FileType)
{
	FILE *fp = NULL;
	char device_path[512]="";
	char file_path[512]="";
	GetDevPath(device_path);
	if (FileType == "Functional_Test")
	{
		sprintf(file_path,"%s%s",device_path,"/testmethod/program_bin_files/FunctionalTestHHGrace_InternalOSC_60MHz.bin");
	}
	else if (FileType == "Initialization")
	{
		sprintf(file_path,"%s%s",device_path,"/testmethod/program_bin_files/release_rev01.bin");
	}
	else
	{
		cout<<"Error, Bin file type "<<FileType<<" not exist!"<<endl;
		return 0;
	}

	if((fp=fopen(file_path,"rb"))==NULL)
	{
		cout<<"======================================================"<<endl;
		cout<<"Error!There is no Sonata_BGA208.bin file!\n"<<endl;
		cout<<"======================================================"<<endl;
		return 0;
	}
	else
	{
		fread(data,1,ByteSector*SectorNum,fp);
		//*data = '0';
		//cout
 	}
	//for(int i = 0; i<BinRow*PageCount; i++)
	//{
		//data[i] = data[i] - '\0';
		//cout<<"data["<<i<<"] = "<<hex<< data[i] - '\0'<<endl;
	//}
	//cout<<"data["<<i<<"] = "<<hex<< data[i] - '\0'<<endl;
	fclose(fp);
	return 1;
}

int getLimitInfo(string suitName,string testName, double& LowLimit, double& HighLimit, string& Units, double& UnitRatio, string& LslTyp, string& UslTyp, int& soft_bin)
{
	//get test table information
	//testName = suitName;
	Public_LimitInfo = tmLimits.getLimit(suitName,testName);
	LowLimit = Public_LimitInfo.Lsl;
	HighLimit = Public_LimitInfo.Usl;
	Units = Public_LimitInfo.Units;
	LslTyp = Public_LimitInfo.LslTyp;
	UslTyp = Public_LimitInfo.UslTyp;
	soft_bin = Public_LimitInfo.BinsNum;

	if(LslTyp == "GE")
	{
		LslTyp = "<=";
	}
	else if(LslTyp == "GT")
	{
		LslTyp = "<";
	}
	else
	{
		LslTyp = "NA";
	}

	if(UslTyp == "LE")
	{
		UslTyp = "<=";
	}
	else if(UslTyp == "LT")
	{
		UslTyp = "<";
	}
	else
	{
		UslTyp = "NA";
	}

	if(Units == "V" || Units == "A" || Units == "v" || Units == "a")
	{
		UnitRatio = 1;
	}
	else if(Units == "mV" || Units == "mA" || Units == "mv" || Units == "ma")
	{
		UnitRatio = 1e3;
	}
	else if(Units == "uV" || Units == "uA" || Units == "uv" || Units == "ua")
	{
		UnitRatio = 1e6;
	}
	else if(Units == "nV" || Units == "nA" || Units == "nv" || Units == "na")
	{
		UnitRatio = 1e9;
	}
	else
	{
		UnitRatio = 1;
	}

	return 0;
}

int getLimitInfo(string suitName,string testName, double& LowLimit, double& HighLimit, string& Units, double& UnitRatio, string& LslTyp, string& UslTyp)
{
	//get test table information
	//testName = suitName;
	Public_LimitInfo = tmLimits.getLimit(suitName,testName);
	LowLimit = Public_LimitInfo.Lsl;
	HighLimit = Public_LimitInfo.Usl;
	Units = Public_LimitInfo.Units;
	LslTyp = Public_LimitInfo.LslTyp;
	UslTyp = Public_LimitInfo.UslTyp;
	if(LslTyp == "GE")
	{
		LslTyp = "<=";
	}
	else if(LslTyp == "GT")
	{
		LslTyp = "<";
	}
	else
	{
		LslTyp = "NA";
	}

	if(UslTyp == "LE")
	{
		UslTyp = "<=";
	}
	else if(UslTyp == "LT")
	{
		UslTyp = "<";
	}
	else
	{
		UslTyp = "NA";
	}

	if(Units == "V" || Units == "A" || Units == "v" || Units == "a")
	{
		UnitRatio = 1;
	}
	else if(Units == "mV" || Units == "mA" || Units == "mv" || Units == "ma")
	{
		UnitRatio = 1e3;
	}
	else if(Units == "uV" || Units == "uA" || Units == "uv" || Units == "ua")
	{
		UnitRatio = 1e6;
	}
	else if(Units == "nV" || Units == "nA" || Units == "nv" || Units == "na")
	{
		UnitRatio = 1e9;
	}
	else
	{
		UnitRatio = 1;
	}

	return 0;
}

int print_datalog_ui_report(string suitName,string testName, double LowLimit, double HighLimit, string Units, double UnitRatio, string LslTyp, string UslTyp, string pinName, double Result)
{
	Public_LimitInfo = tmLimits.getLimit(suitName,testName);
	cout<<std::left<<std::setw(12)<<pinName<<"	min:	"<<std::right<<LowLimit<<" "<<Units<<"	"<<LslTyp<<"	"<<std::left<<std::setw(10)
	<<Result*UnitRatio<<" "<<Units<<" 	"<<UslTyp<<"	max:	"<<std::right<<HighLimit<<" "<<Units<<"	";

	if(Result*UnitRatio >= LowLimit && Result*UnitRatio <= HighLimit )
	{
		cout<<"P"<<endl;
	}
	else
	{
		cout<<"F"<<endl;
	}

	return 0;
}

int flash_chip_erase(int flash_num)
{
	//program high 36bit
	//original
	int addr = 0x00000;
	int data[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};


	int ce_oe_we = 0x7;
	int contrl = 0x318;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//ce prog
	ce_oe_we = 0x6;
	contrl = 0x30c;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//web
	ce_oe_we = 0x2;
	contrl = 0x30c;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	WAIT_TIME(30 ms);

	//prog2
	ce_oe_we = 0x6;
	contrl = 0x30c;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	WAIT_TIME(1 ms);

	//prog2
	ce_oe_we = 0x7;
	contrl = 0x318;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	return 0;
}

int flash_sector_erase(int flash_num, int addr, int NVR)
{
	//program high 36bit
	//original
	int data[9] = {0,0,0,0,0,0,0,0,0};
	isNVR = NVR;

	int ce_oe_we = 0x7;
	int contrl = 0x318;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//ce prog
	ce_oe_we = 0x6;
	contrl = 0x304;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//web
	ce_oe_we = 0x2;
	contrl = 0x304;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	WAIT_TIME(4 ms);

	//prog2
	ce_oe_we = 0x6;
	contrl = 0x304;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	WAIT_TIME(0.1 ms);

	//prog2
	ce_oe_we = 0x7;
	contrl = 0x318;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	return 0;
}


int write_flash(int flash_num, int addr, int *data, int NVR)
{
	//program high 36bit
	//original
	isNVR = NVR;
	int ce_oe_we = 0x7;
	int contrl = 0x300;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//ce prog
	ce_oe_we = 0x6;
	contrl = 0x301;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//web
	ce_oe_we = 0x2;
	contrl = 0x301;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x303;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x303;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x303;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//prog2 to low
	ce_oe_we = 0x2;
	contrl = 0x301;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//we to high
	ce_oe_we = 0x6;
	contrl = 0x301;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//program low 36bit
	//original
	ce_oe_we = 0x7;
	contrl = 0x100;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//ce prog
	ce_oe_we = 0x6;
	contrl = 0x101;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//web
	ce_oe_we = 0x2;
	contrl = 0x101;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x103;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x103;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x103;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//prog2 to low
	ce_oe_we = 0x2;
	contrl = 0x101;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//we to high
	ce_oe_we = 0x6;
	contrl = 0x101;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	return 0;
}

int write_OTP(int addr, unsigned int data)
{
	//original
	int ce_oe_we = 0x7;
	int contrl = 0x080;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//ce prog
	ce_oe_we = 0x6;
	contrl = 0x081;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//address 0x0001
	//web
	ce_oe_we = 0x2;
	contrl = 0x081;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x083;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x083;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//web
	ce_oe_we = 0x2;
	contrl = 0x081;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//address 0x0010
	//web
	ce_oe_we = 0x2;
	contrl = 0x101;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x103;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x103;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//web
	ce_oe_we = 0x2;
	contrl = 0x101;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//address 0x0100
	//web
	ce_oe_we = 0x2;
	contrl = 0x201;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x203;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x203;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//web
	ce_oe_we = 0x2;
	contrl = 0x201;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//address 0x1000
	//web
	ce_oe_we = 0x2;
	contrl = 0x401;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x403;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//prog2
	ce_oe_we = 0x2;
	contrl = 0x403;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//web
	ce_oe_we = 0x2;
	contrl = 0x401;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	//ce prog
	ce_oe_we = 0x6;
	contrl = 0x081;
	serial_OTP_write(ce_oe_we, contrl, addr, data);
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	return 0;
}

int read_flash(int flash_num, int addr, int *data, int NVR)
{
	isNVR = NVR;
	//original
	int ce_oe_we = 0x7;
	int contrl = 0x100;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//read address
	ce_oe_we = 0x4;
	contrl = 0x100;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//read address
	ce_oe_we = 0x4;
	contrl = 0x100;
	serial_flash_write(flash_num, ce_oe_we, contrl, addr, data);

	//read address
	ce_oe_we = 0x4;
	contrl = 0x100;
	serial_flash_read(flash_num, ce_oe_we, contrl, addr, data);

	return 0;
}

int read_OTP(int addr, unsigned int data)
{
	//original
	int ce_oe_we = 0x7;
	int contrl = 0x000;
	serial_OTP_write(ce_oe_we, contrl, addr, data);

	ce_oe_we = 0x4;
	contrl = 0x000;
	serial_OTP_read(ce_oe_we, contrl, addr, data);

	return 0;
}

int OTP_chip_erase()
{
	int prog = 0;
	int prog2 =0;
	int erase = 0;
	int chip = 1;
	int NVR = 0;
	int TMEN = 0;
	int DPSTB =0;
	int BYTE0 = 0;
	int BYTE1 = 0;
	int BYTE2 = 0;
	int BYTE3 = 0;

	//original
	int ce_oe_we = 0x7;
	int contrl = calc_11bit_to_dec(prog, prog2, erase, chip, NVR, TMEN, DPSTB, BYTE0, BYTE1, BYTE2, BYTE3);
	serial_OTP_write(ce_oe_we, contrl, 0x0000, 0x0000);

	//ce erase
	erase = 1;
	ce_oe_we = 0x6;
	contrl = calc_11bit_to_dec(prog, prog2, erase, chip, NVR, TMEN, DPSTB, BYTE0, BYTE1, BYTE2, BYTE3);
	serial_OTP_write(ce_oe_we, contrl, 0x0000, 0x0000);

	//we erase
	ce_oe_we = 0x2;
	contrl = calc_11bit_to_dec(prog, prog2, erase, chip, NVR, TMEN, DPSTB, BYTE0, BYTE1, BYTE2, BYTE3);
	serial_OTP_write(ce_oe_we, contrl, 0x0000, 0x0000);

	WAIT_TIME(20 ms);

	//we
	ce_oe_we = 0x6;
	contrl = calc_11bit_to_dec(prog, prog2, erase, chip, NVR, TMEN, DPSTB, BYTE0, BYTE1, BYTE2, BYTE3);
	serial_OTP_write(ce_oe_we, contrl, 0x0000, 0x0000);

	WAIT_TIME(1 ms);

	//we
	erase = 0;
	chip = 0;
	ce_oe_we = 0x7;
	contrl = calc_11bit_to_dec(prog, prog2, erase, chip, NVR, TMEN, DPSTB, BYTE0, BYTE1, BYTE2, BYTE3);
	serial_OTP_write(ce_oe_we, contrl, 0x0000, 0x0000);


	return 0;
}

int OTP_sector_erase(int addr, int NVR)
{
	int prog = 0;
	int prog2 =0;
	int erase = 0;
	int chip = 1;
	int TMEN = 0;
	int DPSTB =0;
	int BYTE0 = 0;
	int BYTE1 = 0;
	int BYTE2 = 0;
	int BYTE3 = 0;
	NVR = 0;

	//original
	int ce_oe_we = 0x7;
	int contrl = calc_11bit_to_dec(prog, prog2, erase, chip, NVR, TMEN, DPSTB, BYTE0, BYTE1, BYTE2, BYTE3);
	serial_OTP_write(ce_oe_we, contrl, addr, 0x0000);

	//ce erase
	erase = 1;
	chip = 0;
	ce_oe_we = 0x6;
	contrl = calc_11bit_to_dec(prog, prog2, erase, chip, NVR, TMEN, DPSTB, BYTE0, BYTE1, BYTE2, BYTE3);
	serial_OTP_write(ce_oe_we, contrl, addr, 0x0000);

	//we erase
	ce_oe_we = 0x2;
	contrl = calc_11bit_to_dec(prog, prog2, erase, chip, NVR, TMEN, DPSTB, BYTE0, BYTE1, BYTE2, BYTE3);
	serial_OTP_write(ce_oe_we, contrl, addr, 0x0000);

	WAIT_TIME(4 ms);

	//we
	ce_oe_we = 0x6;
	contrl = calc_11bit_to_dec(prog, prog2, erase, chip, NVR, TMEN, DPSTB, BYTE0, BYTE1, BYTE2, BYTE3);
	serial_OTP_write(ce_oe_we, contrl, addr, 0x0000);

	WAIT_TIME(1 ms);

	//we
	erase = 0;
	chip = 1;
	ce_oe_we = 0x7;
	contrl = calc_11bit_to_dec(prog, prog2, erase, chip, NVR, TMEN, DPSTB, BYTE0, BYTE1, BYTE2, BYTE3);
	serial_OTP_write(ce_oe_we, contrl, addr, 0x0000);


	return 0;
}

int serial_flash_write(int flash_num, int ce_oe_we, int contrl, int addr, int *data)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    int mask,vecNum;
    int data_size = 9;
    int edit_size = 101;
    string primary_label;

    if(debug)
    {
        hex(cout);
        if(print_reg) cout<<"Flash"<<flash_num<<" write(0x"<<addr<<", 0x";
        for(int i=data_size-1; i>=0; i--)
        {
        	cout<<*(data+i);
        }
        cout<<")"<<endl;
    }
    if(flash_num == 0)
    {
    	primary_label = "FLASH0_write";
    }
    else if(flash_num == 1)
    {
    	primary_label = "FLASH1_write";
    }
    else
    {
    	cout<<"error, invalid flash num:"<<flash_num<<endl;
    }

    contrl = (isNVR<<6) || contrl;

	Primary.label(primary_label);
    VECTOR_DATA myVectorData[edit_size];

    vecNum = 1;
    for(int i=0; i<edit_size; i++)
    {
    	myVectorData[i].vectorNum = vecNum;
        vecNum++;
    }

    mask = 0x1;
    for(int i=0; i<=2; i++)
    {
        myVectorData[i].phyWvfIndex = (ce_oe_we & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    mask = 0x1;
    for(int i=3; i<=12; i++)
    {
        myVectorData[i].phyWvfIndex = (contrl & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    mask = 0x1;
    for(int i=13; i<29; i++)
    {
        myVectorData[i].phyWvfIndex = (addr & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }


    mask = 0x1;
    for(int i=29; i<37; i++)
    {
    	for(int j=0; j<=8; j++)
    	{
//    		myVectorData[i+j*8].phyWvfIndex = (*(data+8-j) & mask)? HIGH_WFIndex:LOW_WFIndex;
    		myVectorData[i+j*8].phyWvfIndex = (*(data+j) & mask)? HIGH_WFIndex:LOW_WFIndex;
//            dec(cout);
//    		cout<<i+j*8<<endl;
    	}
        mask = mask<<1;
    }

//    dec(cout);
//    for(int i=29; i<(29+72); i++)
//    {
//    	cout<<"myVectorData["<<i<<"] = "<<myVectorData[i].phyWvfIndex<<endl;
//    }

    VEC_LABEL_EDIT myLabel1(primary_label, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);

    FUNCTIONAL_TEST();

	return 0;
}

int serial_flash_read(int flash_num, int ce_oe_we, int contrl, int addr, int *data)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    int HIGH_CMPIndex = 3;
    int LOW_CMPIndex = 2;
    int mask,vecNum;
    int data_size = 9;
    int edit_size = 101;
    int edit_size_cmp = 72;
    string primary_label;

    if(debug)
    {
        hex(cout);
        if(print_reg) cout<<"Flash"<<flash_num<<" read(0x"<<addr<<", 0x";
        for(int i=data_size-1; i>=0; i--)
        {
        	cout<<*(data+i);
        }
        cout<<")"<<endl;
    }
    if(flash_num == 0)
    {
    	primary_label = "FLASH0_write_capture";
    }
    else if(flash_num == 1)
    {
    	primary_label = "FLASH1_write_capture";
    }
    else
    {
    	cout<<"error, invalid flash num:"<<flash_num<<endl;
    }

    contrl = (isNVR<<6) || contrl;

	Primary.label(primary_label);
    VECTOR_DATA myVectorData[edit_size];
    VECTOR_DATA myVectorData_cmp[edit_size_cmp];

    vecNum = 1;
    for(int i=0; i<edit_size; i++)
    {
    	myVectorData[i].vectorNum = vecNum;
        vecNum++;
    }

    vecNum = 112;
    for(int i=0; i<edit_size_cmp; i++)
    {
    	myVectorData_cmp[i].vectorNum = vecNum;
        vecNum++;
    }

    mask = 0x1;
    for(int i=0; i<=2; i++)
    {
        myVectorData[i].phyWvfIndex = (ce_oe_we & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    mask = 0x1;
    for(int i=3; i<=12; i++)
    {
        myVectorData[i].phyWvfIndex = (contrl & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    mask = 0x1;
    for(int i=13; i<29; i++)
    {
        myVectorData[i].phyWvfIndex = (addr & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }


    mask = 0x1;
    for(int i=29; i<37; i++)
    {
    	for(int j=0; j<=8; j++)
    	{
//    		myVectorData[i+j*8].phyWvfIndex = (*(data+8-j) & mask)? HIGH_WFIndex:LOW_WFIndex;
    		myVectorData[i+j*8].phyWvfIndex = (*(data+j) & mask)? HIGH_WFIndex:LOW_WFIndex;
//            dec(cout);
//    		cout<<i+j*8<<endl;
    	}
        mask = mask<<1;
    }

    mask = 0x1;
    for(int i=0; i<8; i++)
    {
    	for(int j=0; j<=8; j++)
    	{
//    		myVectorData[i+j*8].phyWvfIndex = (*(data+8-j) & mask)? HIGH_WFIndex:LOW_WFIndex;
    		myVectorData_cmp[i+j*8].phyWvfIndex = (*(data+j) & mask)? HIGH_CMPIndex:LOW_CMPIndex;
//            dec(cout);
//    		cout<<i+j*8<<endl;
    	}
        mask = mask<<1;
    }


//    dec(cout);
//    for(int i=29; i<(29+72); i++)
//    {
//    	cout<<"myVectorData["<<i<<"] = "<<myVectorData[i].phyWvfIndex<<endl;
//    }

    VEC_LABEL_EDIT myLabel1(primary_label, "TDI");
//    VEC_LABEL_EDIT myLabel2(primary_label, "TDO");
    myLabel1.downloadUserVectors(myVectorData, edit_size);
//    myLabel2.downloadUserVectors(myVectorData_cmp, edit_size_cmp);

    DIGITAL_CAPTURE_TEST();

    ARRAY_I adWave;
    int my_data[9];

    adWave = VECTOR("FLASH0_capture").getVectors();

	hex(cout);
	cout<<"capture flash data :"<<"0x";
	for(int i=0; i<9; i++)
	{
		my_data[i] = 0;
		for(int j=0; j<8; j++)
		{
			my_data[i] += adWave[i*8+j]<<j;
		}
	}
	for(int i=8; i>=0; i--)
	{
		cout<<my_data[i];
	}
	cout<<endl;

	for(int i=0; i<72; i++)
	{
		cout<<"adWave["<<i<<"]="<<adWave[i]<<endl;
	}

	return 0;
}

int serial_OTP_read(int ce_oe_we, int contrl, int addr, unsigned int data)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    int HIGH_CMPIndex = 3;
    int LOW_CMPIndex = 2;
    int mask,vecNum;
    int edit_size = 58;
    int edit_size_cmp = 32;
    string primary_label;

    if(debug)
    {
        hex(cout);
        if(print_reg) cout<<"OTP read(0x"<<addr<<", 0x"<<data<<")"<<endl;
    }

	Primary.label("OTP_write_capture");
    VECTOR_DATA myVectorData[edit_size];
    VECTOR_DATA myVectorData_cmp[edit_size_cmp];

    vecNum = 1;
    for(int i=0; i<edit_size; i++)
    {
    	myVectorData[i].vectorNum = vecNum;
        vecNum++;
    }

    vecNum = 72;
    for(int i=0; i<edit_size_cmp; i++)
    {
    	myVectorData_cmp[i].vectorNum = vecNum;
        vecNum++;
    }

    mask = 0x1;
    for(int i=0; i<=2; i++)
    {
        myVectorData[i].phyWvfIndex = (ce_oe_we & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    mask = 0x1;
    for(int i=3; i<14; i++)
    {
        myVectorData[i].phyWvfIndex = (contrl & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    mask = 0x1;
    for(int i=14; i<26; i++)
    {
        myVectorData[i].phyWvfIndex = (addr & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    hex(cout);
    mask = 0x1;
    for(int i=26; i<58; i++)
    {
        myVectorData[i].phyWvfIndex = (data & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    hex(cout);
    mask = 0x1;
    for(int i=0; i<edit_size_cmp; i++)
    {
    	myVectorData_cmp[i].phyWvfIndex = (data & mask)? HIGH_CMPIndex:LOW_CMPIndex;
        mask = mask<<1;
    }

//    dec(cout);
//    for(int i=29; i<(29+72); i++)
//    {
//    	cout<<"myVectorData["<<i<<"] = "<<myVectorData[i].phyWvfIndex<<endl;
//    }

    VEC_LABEL_EDIT myLabel1("OTP_write_capture", "TDI");
    VEC_LABEL_EDIT myLabel2("OTP_write_capture", "TDO");

    myLabel1.downloadUserVectors(myVectorData, edit_size);
    myLabel2.downloadUserVectors(myVectorData_cmp, edit_size_cmp);

    FUNCTIONAL_TEST();

	return 0;
}

int NVR2_capture(unsigned int *my_data_L, unsigned int *my_data_H)
{
    ARRAY_I adWave;

	Primary.label("flash0_nvr2_read");
    DIGITAL_CAPTURE_TEST();

    adWave = VECTOR("flash0_nvr2_cap").getVectors();

    for(int i=0; i<32; i++)
    {
    	my_data_L[i] = 0;
    	my_data_H[i] = 0;
    	for(int j=0; j<32; j++)
    	{
    		my_data_L[i] += (adWave[i*72+j]<<j);
    		my_data_H[i] += (adWave[i*72+32+j]<<j);
    	}
    	if(debug)
    	{
    		cout<<"capture NVR data["<<i<<"] Lower 32bit = "<<my_data_L[i]<<endl;
    		cout<<"capture NVR data["<<i<<"] Higher 32bit = "<<my_data_L[i]<<endl;
    	}
    }

	return 0;
}

int OTP_write(unsigned char *data, string vector_name)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    int mask;
    int addr_count = 22;
    int single_addr_op = 12;
    int address_byte = 9;
    int bit_per_byte = 8;
    int addr_op_cycle = 1394;
    int address_bit = address_byte*bit_per_byte;
    int data_size = addr_count*address_byte;
    int edit_size = data_size*bit_per_byte*single_addr_op;
    bool databool[data_size*bit_per_byte];

	Primary.label(vector_name);
    VECTOR_DATA myVectorData[edit_size];

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<single_addr_op; j++)
    	{
    		for(int k=0; k<address_bit; k++)
    		{
            	myVectorData[i*single_addr_op*address_bit+j*address_bit+k].vectorNum = i*addr_op_cycle + mData_index[j].data_start + k;
    		}
    	}
    }

    for(int i=0; i<data_size; i++)
    {
    	mask = 1;
    	for(int j=0; j<bit_per_byte; j++)
    	{
        	databool[i*8+j] = *(data+i) & mask;
        	mask = mask<<1;
    	}
    }

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<single_addr_op; j++)
    	{
    		for(int k=0; k<address_bit; k++)
    		{
            	myVectorData[i*single_addr_op*address_bit+j*address_bit+k].phyWvfIndex = databool[i*address_bit+k] ? HIGH_WFIndex:LOW_WFIndex;
    		}
    	}
    }

    VEC_LABEL_EDIT myLabel1(vector_name, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);

	return 0;
}

int OTP_read(unsigned char *data, string vector_name)
{
    int HIGH_WFIndex = 3;
    int LOW_WFIndex = 2;
    int mask;
    int vector_start = 462;
    int addr_count = 22;
    int data_size = addr_count*9;
    int edit_size = data_size*8;
    bool databool[edit_size];

	Primary.label(vector_name);
    VECTOR_DATA myVectorData[edit_size];

    for(int i=0; i<addr_count; i++)
    {

    	for(int j=0; j<72; j++)
    	{
            myVectorData[i*72+j].vectorNum = vector_start + i*536 + j;
    	}
    }

    for(int i=0; i<data_size; i++)
    {
    	mask = 1;
    	for(int j=0; j<8; j++)
    	{
        	databool[i*8+j] = *(data+i) & mask;
        	mask = mask<<1;
    	}
    }

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<72; j++)
    	{
            myVectorData[i*72+j].phyWvfIndex = databool[i*72+j] ? HIGH_WFIndex:LOW_WFIndex;
    	}
    }

    VEC_LABEL_EDIT myLabel1(vector_name, "TDO");
    myLabel1.downloadUserVectors(myVectorData, edit_size);

	return 0;
}



int Nvr1_write_version_flag(unsigned char *data, string vector_name)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    int mask,vecNum;

    int edit_size = 12*72;
    bool databool[9*8];

	Primary.label(vector_name);
    VECTOR_DATA myVectorData[edit_size];

    vecNum = 3046;
    for(int i=0; i<12; i++)
    {
    	for(int j=0; j<72; j++)
    	{
           	myVectorData[i*72+j].vectorNum = vecNum+j+i*116;
    	}
    }

    for(int i=0; i<9; i++)
    {
    	mask = 0x01;
    	for(int j=0; j<8; j++)
    	{
        	databool[i*8+j] = *(data+i) & mask;
        	mask = mask<<1;
    	}
    }

    for(int i=0; i<12; i++)
    {
    	for(int j=0; j<72; j++)
    	{
           	myVectorData[i*72+j].phyWvfIndex = databool[j] ? HIGH_WFIndex:LOW_WFIndex;
           	cout<<"myVectorData["<<j<<"].phyWvfIndex = "<<myVectorData[j+i*72].phyWvfIndex<<endl;
    	}
    }

    VEC_LABEL_EDIT myLabel1(vector_name, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);

	return 0;
}



int Flash_write_encrypt_key(unsigned char *data, string vector_name)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    int mask;
    int addr_count = 768;
    int single_addr_op = 12;
    int address_byte = 9;
    int bit_per_byte = 8;
    int addr_op_cycle = 1394;
    int address_bit = address_byte*bit_per_byte;
    int data_size = addr_count*address_byte;
    int edit_size = data_size*bit_per_byte*single_addr_op;
    bool databool[data_size*bit_per_byte];

	Primary.label(vector_name);
    VECTOR_DATA myVectorData[edit_size];

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<single_addr_op; j++)
    	{
    		for(int k=0; k<address_bit; k++)
    		{
            	myVectorData[i*single_addr_op*address_bit+j*address_bit+k].vectorNum = i*addr_op_cycle + mData_index[j].data_start + k;
    		}
    	}
    }

    for(int i=0; i<data_size; i++)
    {
    	mask = 1;
    	for(int j=0; j<bit_per_byte; j++)
    	{
        	databool[i*8+j] = *(data+i) & mask;
        	mask = mask<<1;
    	}
    }

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<single_addr_op; j++)
    	{
    		for(int k=0; k<address_bit; k++)
    		{
            	myVectorData[i*single_addr_op*address_bit+j*address_bit+k].phyWvfIndex = databool[i*address_bit+k] ? HIGH_WFIndex:LOW_WFIndex;
    		}
    	}
    }

    VEC_LABEL_EDIT myLabel1(vector_name, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);

	return 0;
}


int Flash_write_NVR2_redundancy(unsigned char *data, string vector_name)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    int mask;
    int addr_count = 8;
    int single_addr_op = 12;
    int address_byte = 9;
    int bit_per_byte = 8;
    int addr_op_cycle = 2204;
    int address_bit = address_byte*bit_per_byte;
    int data_size = addr_count*address_byte;
    int edit_size = data_size*bit_per_byte*single_addr_op;
    bool databool[data_size*bit_per_byte];

	Primary.label(vector_name);
    VECTOR_DATA myVectorData[edit_size];

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<single_addr_op; j++)
    	{
    		for(int k=0; k<address_bit; k++)
    		{
            	myVectorData[i*single_addr_op*address_bit+j*address_bit+k].vectorNum = i*addr_op_cycle + mNVR2_index[j].data_start + k;
    		}
    	}
    }

    for(int i=0; i<data_size; i++)
    {
    	if(debug) cout<<"data["<<i<<"] = "<< *(data+i)-0<<endl;
     	mask = 1;
    	for(int j=0; j<bit_per_byte; j++)
    	{
        	databool[i*8+j] = *(data+i) & mask;
        	mask = mask<<1;
    	}
    }

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<single_addr_op; j++)
    	{
    		for(int k=0; k<address_bit; k++)
    		{
            	myVectorData[i*single_addr_op*address_bit+j*address_bit+k].phyWvfIndex = databool[i*address_bit+k] ? HIGH_WFIndex:LOW_WFIndex;
    		}
    	}
    }

    VEC_LABEL_EDIT myLabel1(vector_name, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);

	return 0;
}


int Flash_reload_trim_bit(string vector_name, int FLASH0_Trim_Bit, int FLASH1_Trim_Bit)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    int mask;
    int edit_size = 40;
//    int addr_count = 512;
//    int single_addr_op = 12;
//    int address_byte = 9;
//    int address_data = 8;
//    int bit_per_byte = 8;
//    int addr_op_cycle = 1394;
//    int address_bit = address_byte*bit_per_byte;
//    int data_size = addr_count*address_byte;
//    int edit_size = data_size*address_data*single_addr_op;
//    bool databool[data_size*address_data];

	Primary.label(vector_name);
    VECTOR_DATA myVectorData[edit_size];

    int Num_base = 30;
    for(int i=0; i<8; i++)
    {
    	myVectorData[i].vectorNum = Num_base+i;
    	myVectorData[i+8].vectorNum = Num_base+i+116;
    	myVectorData[i+16].vectorNum = Num_base+i+232;
    	myVectorData[i+24].vectorNum = Num_base+i+348;
    	myVectorData[i+32].vectorNum = Num_base+i+464;

//    	myVectorData[i+40].vectorNum = Num_base+i+580;
//    	myVectorData[i+48].vectorNum = Num_base+i+696;
//    	myVectorData[i+56].vectorNum = Num_base+i+812;
//    	myVectorData[i+64].vectorNum = Num_base+i+928;
//    	myVectorData[i+72].vectorNum = Num_base+i+1044;
    }

    mask = 1;
    for(int i=0; i<8; i++)
    {
    	myVectorData[i].phyWvfIndex =  FLASH0_Trim_Bit&mask ? HIGH_WFIndex:LOW_WFIndex;
    	myVectorData[i+8].phyWvfIndex = FLASH0_Trim_Bit&mask ? HIGH_WFIndex:LOW_WFIndex;
    	myVectorData[i+16].phyWvfIndex = FLASH0_Trim_Bit&mask ? HIGH_WFIndex:LOW_WFIndex;
    	myVectorData[i+24].phyWvfIndex = FLASH0_Trim_Bit&mask ? HIGH_WFIndex:LOW_WFIndex;
    	myVectorData[i+32].phyWvfIndex = FLASH0_Trim_Bit&mask ? HIGH_WFIndex:LOW_WFIndex;

//    	myVectorData[i+40].phyWvfIndex = FLASH1_Trim_Bit&mask ? HIGH_WFIndex:LOW_WFIndex;
//    	myVectorData[i+48].phyWvfIndex = FLASH1_Trim_Bit&mask ? HIGH_WFIndex:LOW_WFIndex;
//    	myVectorData[i+56].phyWvfIndex = FLASH1_Trim_Bit&mask ? HIGH_WFIndex:LOW_WFIndex;
//    	myVectorData[i+64].phyWvfIndex = FLASH1_Trim_Bit&mask ? HIGH_WFIndex:LOW_WFIndex;
//    	myVectorData[i+72].phyWvfIndex = FLASH1_Trim_Bit&mask ? HIGH_WFIndex:LOW_WFIndex;
    	mask = mask<<1;
    }

    VEC_LABEL_EDIT myLabel(vector_name, "TDI");
    myLabel.downloadUserVectors(myVectorData, edit_size);

	return 0;
}

int Flash_Chip_Erase_Upload(string vector_name, bool isErase)
{
    int HIGH_WFIndex = 8;
    int LOW_WFIndex = 0;
    int edit_size = 583;

	Primary.label(vector_name);
    VECTOR_DATA myVectorData1[edit_size];
    VECTOR_DATA myVectorData2[edit_size];
    VECTOR_DATA myVectorData3[edit_size];

    for(int i=0; i<edit_size; i++)
    {
    	myVectorData1[i].vectorNum = i;
    	myVectorData2[i].vectorNum = i;
    	myVectorData3[i].vectorNum = i;
    }

    for(int i=0; i<edit_size; i++)
    {
    	myVectorData1[i].phyWvfIndex =  isErase ? HIGH_WFIndex:LOW_WFIndex;
    	myVectorData2[i].phyWvfIndex =  isErase ? HIGH_WFIndex:LOW_WFIndex;
    	myVectorData3[i].phyWvfIndex =  isErase ? 1 : 0;
    }

    VEC_LABEL_EDIT myLabel1(vector_name, "TCK");
    myLabel1.downloadUserVectors(myVectorData1, edit_size);

    VEC_LABEL_EDIT myLabel2(vector_name, "XTAL_IN");
    myLabel2.downloadUserVectors(myVectorData2, edit_size);

    VEC_LABEL_EDIT myLabel3(vector_name, "DFT_TEST_EN");
    myLabel3.downloadUserVectors(myVectorData3, edit_size);

	return 0;
}

int XOR_FF(unsigned char *input, int input_length, unsigned char *output)
{
	unsigned char all_1 = 0xff;
	for(int i=0; i<input_length; i++)
	{
		*(output+i) = *(input+i) ^ all_1;
	}
//	if(debug)
//	{
//		for (int i = 0; i < ID_OTP_byte; i++)
//		{
//			hex(cout);
//			cout<<*(output+i)-0;
//		}
//		cout<<endl;
//	}
	return 0;
}

int Flash_read_encrypt_key(unsigned char *data, string vector_name)
{
    int HIGH_WFIndex = 3;
    int LOW_WFIndex = 2;
    int mask;
    int vector_start = 462;
    int addr_count = 768;
    int data_size = addr_count*9;
    int edit_size = data_size*8;
    bool databool[edit_size];

	Primary.label(vector_name);
    VECTOR_DATA myVectorData[edit_size];

    for(int i=0; i<addr_count; i++)
    {

    	for(int j=0; j<72; j++)
    	{
            myVectorData[i*72+j].vectorNum = vector_start + i*188 + j;
    	}
    }

    for(int i=0; i<data_size; i++)
    {
    	mask = 1;
    	for(int j=0; j<8; j++)
    	{
        	databool[i*8+j] = *(data+i) & mask;
        	mask = mask<<1;
    	}
    }

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<72; j++)
    	{
            myVectorData[i*72+j].phyWvfIndex = databool[i*72+j] ? HIGH_WFIndex:LOW_WFIndex;
    	}
    }

    VEC_LABEL_EDIT myLabel1(vector_name, "TDO");
    myLabel1.downloadUserVectors(myVectorData, edit_size);

	return 0;
}


int Flash_redundancy_address_mapping(string vector_name, int mapping_sector)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    int mask;
    int addr_count = 128;
    int single_addr_op = 3;
    int address_byte = 2;
    int bit_per_byte = 8;
    int addr_op_cycle = 349;
    int address_bit = address_byte*bit_per_byte;
    int data_byte = addr_count*address_byte;
    int edit_size = data_byte*bit_per_byte*single_addr_op;
    bool databool[data_byte*bit_per_byte];

	Primary.label(vector_name);
    VECTOR_DATA myVectorData[edit_size];

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<single_addr_op; j++)
    	{
    		for(int k=0; k<address_bit; k++)
    		{
            	myVectorData[i*single_addr_op*address_bit+j*address_bit+k].vectorNum = i*addr_op_cycle + mLow_High_index[j].data_start + k;
    		}
    	}
    }

    for(int i=0; i<addr_count; i++)
    {
    	mask = 1;
    	for(int j=0; j<address_bit; j++)
    	{
        	databool[i*address_bit+j] = ((mapping_sector*128+i)&mask);
        	mask = mask<<1;
    	}
    }

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<single_addr_op; j++)
    	{
    		for(int k=0; k<address_bit; k++)
    		{
            	myVectorData[i*single_addr_op*address_bit+j*address_bit+k].phyWvfIndex = databool[i*address_bit+k] ? HIGH_WFIndex:LOW_WFIndex;
    		}
    	}
    }

    VEC_LABEL_EDIT myLabel1(vector_name, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);

	return 0;
}


int Flash_redundancy_data_update_sector(unsigned char *data, int sector_mapping)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    int mask;
    int addr_count = 128;
    int single_addr_op = 12;
    int address_byte = 9;
    int bit_per_byte = 8;
    int addr_op_cycle = 1394;
    int address_bit = address_byte*bit_per_byte;
    int data_size = addr_count*address_byte;
    int edit_size = data_size*bit_per_byte*single_addr_op;
    bool databool[data_size*bit_per_byte];
    char vector_cat[128];
    string vector_name = "flash_program_sector_";
    string string_cat;

    sprintf(vector_cat, "%d", sector_mapping);
    string_cat = vector_cat;
    vector_name = vector_name + string_cat;

    if(debug) cout<<"vector_name is "<<vector_name<<endl;

	Primary.label(vector_name);
    VECTOR_DATA myVectorData[edit_size];

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<single_addr_op; j++)
    	{
    		for(int k=0; k<address_bit; k++)
    		{
            	myVectorData[i*single_addr_op*address_bit+j*address_bit+k].vectorNum = i*addr_op_cycle + mData_index[j].data_start + k;
    		}
    	}
    }

    for(int i=0; i<data_size; i++)
    {
    	mask = 1;
    	for(int j=0; j<bit_per_byte; j++)
    	{
        	databool[i*8+j] = *(data+i) & mask;
        	mask = mask<<1;
    	}
    }

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<single_addr_op; j++)
    	{
    		for(int k=0; k<address_bit; k++)
    		{
            	myVectorData[i*single_addr_op*address_bit+j*address_bit+k].phyWvfIndex = databool[i*address_bit+k] ? HIGH_WFIndex:LOW_WFIndex;
    		}
    	}
    }

    VEC_LABEL_EDIT myLabel1(vector_name, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);

	return 0;
}


int Flash_redundancy_data_update(unsigned char *data)
{
	int site_num = CURRENT_SITE_NUMBER()-1;
	int sector_failed;
	int sector_mapping;

	for(int i=0; i<8; i++)
	{
		if(debug) cout<<"redundancy_info_L["<<site_num<<"]["<<i<<"] = 0x"<<redundancy_info_L[site_num][i]<<endl;
		if((redundancy_info_L[site_num][i]&0xfffffe00) == 0xfffffc00)
		{
			sector_failed = redundancy_info_L[site_num][i]&0x1ff;
			sector_mapping = 504+i;
			Flash_redundancy_data_update_sector(data+sector_failed*1024, sector_mapping);
			redundancy_secotr_used = 1;
			if(debug) cout<<"redundancy sector "<<504+i<<" is in used."<<endl;
		}
	}

	return 0;
}


int pattern_edit_IDD(string label_name, string pin_name, string set_stage)
{
    int HIGH_WFIndex = 0x1;
    int LOW_WFIndex = 0x0;
    int HihgZ_WFIndex = 0xa;
    int Pulse_WFIndex = 0x8;

    Primary.label(label_name);
    VECTOR_DATA myVectorData[10];

    if(set_stage == "high")
    {
    	for(int i=0; i<10; i++)
    	{
    		myVectorData[i].vectorNum = i;
    		myVectorData[i].phyWvfIndex = HIGH_WFIndex;
    	}
    }
    else if(set_stage == "low")
    {
    	for(int i=0; i<10; i++)
    	{
    		myVectorData[i].vectorNum = i;
    		myVectorData[i].phyWvfIndex = LOW_WFIndex;
    	}
    }
    else if(set_stage == "highZ")
    {
    	for(int i=0; i<10; i++)
    	{
    		myVectorData[i].vectorNum = i;
    		myVectorData[i].phyWvfIndex = HihgZ_WFIndex;
    	}
    }
    else if(set_stage == "Pulse")
    {
    	for(int i=0; i<10; i++)
    	{
    		myVectorData[i].vectorNum = i;
    		myVectorData[i].phyWvfIndex = Pulse_WFIndex;
    	}
    }
    else
    {
    	cout<<"error, set stage not exist"<<endl;
    }


    VEC_LABEL_EDIT myLabel(label_name, pin_name);
    myLabel.downloadUserVectors(myVectorData, 10);

    return 0;
}


int serial_OTP_write(int ce_oe_we, int contrl, int addr, unsigned int data)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    unsigned int mask,vecNum;
    int edit_size = 58;

    contrl = contrl || (isNVR<<4);

    if(debug)
    {
        hex(cout);
        if(print_reg) cout<<"OTP write(0x"<<addr<<", 0x"<<data<<")"<<endl;
    }

	Primary.label("OTP_write");
    VECTOR_DATA myVectorData[edit_size];

    vecNum = 1;
    for(int i=0; i<edit_size; i++)
    {
    	myVectorData[i].vectorNum = vecNum;
        vecNum++;
    }

    mask = 0x1;
    for(int i=0; i<=2; i++)
    {
        myVectorData[i].phyWvfIndex = (ce_oe_we & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    mask = 0x1;
    for(int i=3; i<14; i++)
    {
        myVectorData[i].phyWvfIndex = (contrl & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    mask = 0x1;
    for(int i=14; i<26; i++)
    {
        myVectorData[i].phyWvfIndex = (addr & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    hex(cout);
    mask = 0x1;
    for(int i=26; i<58; i++)
    {
        myVectorData[i].phyWvfIndex = (data & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

//    dec(cout);
//    for(int i=29; i<(29+72); i++)
//    {
//    	cout<<"myVectorData["<<i<<"] = "<<myVectorData[i].phyWvfIndex<<endl;
//    }

    VEC_LABEL_EDIT myLabel1("OTP_write", "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);

    FUNCTIONAL_TEST();

	return 0;
}

int GetWaferID()
{
	//Add your test code here.
	long Xcoord,Ycoord,WaferID;
	char wid_char[CI_CPI_MAX_MODL_STRING_LEN+2];

	GetModelfileString("PH_wafer_id",wid_char);
	//strcpy(wid_char,"H6V689-21B2");
	WaferID= (long(wid_char[7])-48)*10+(long(wid_char[8])-48);
	GetDiePosXYOfSite(CURRENT_SITE_NUMBER(),&Xcoord,&Ycoord);
	cout<<"X: "<<Xcoord<<endl;
	cout<<"Y: "<<Ycoord<<endl;
	cout<<"Wafer ID: "<<WaferID<<endl;

	return 1;
}

int PAT_Limit_compare(string suitName, string testName, string pinName, double result)
{
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;
	static string PAT = "_PAT";
	static string testName_PAT;
	double LowLimit, HighLimit;
	double UnitRatio;
	int limit_index;
	int PAT_soft_bin;
	char temp[128];

	memset(temp,0,128);
	testName.copy(temp,testName.length(),0);
	PAT.copy(temp+testName.length(), PAT.length(), 0);
	testName_PAT = temp;

//	getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
	getLimitInfo(suitName, testName_PAT, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp,PAT_soft_bin);
	limit_index = search_limit_index(suitName, testName, pinName);

	if(limit_index!=9999)
	{
		if((mDynamic_PAT_limit[last_limit_index].initial_population==0) && (limit_index==first_limit_index))
		{
			if(debug) cout<<"initial_population is 0"<<endl;
			for(int i=0; i<=last_limit_index; i++)
			{
				calc_limit_PAT(i);
				mDynamic_PAT_limit[i].initial_population = restore_account;
			}
		}

		if(result >= LowLimit && result <= HighLimit)
		{
//			if(debug) cout<<"result in limit"<<endl;
			restore_limit_data(limit_index, result);
		}

		LIMIT lmt_obj;
		if(debug) cout<<"is_limit_calculated "<<mDynamic_PAT_limit[limit_index].is_limit_calculated<<endl;
		if(mDynamic_PAT_limit[limit_index].is_limit_calculated)
		{
			if(debug) cout<<"limit low:"<< mDynamic_PAT_limit[limit_index].LCL<<endl;
			if(debug) cout<<"limit high:"<< mDynamic_PAT_limit[limit_index].UCL<<endl;
			lmt_obj.low(TM::GE, mDynamic_PAT_limit[limit_index].LCL);
			lmt_obj.high(TM::LE, mDynamic_PAT_limit[limit_index].UCL);
			lmt_obj.unit(mUnits);

			if(!TESTSET().cont(true).judgeAndLog_ParametricTest(pinName,testName_PAT,lmt_obj,result))
			{
				if(debug) cout<<"PAT_soft_bin "<<PAT_soft_bin<<endl;
				SET_MULTIBIN(PAT_soft_bin);
			}
		}
	}
	return 0;
}


int PAT_Limit_compare(string suitName, string testName, string pinName, double result, int isMultiBin, int PAT_soft_bin)
{
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;
	static string PAT = "_PAT";
	static string testName_PAT;
	double LowLimit, HighLimit;
	double UnitRatio;
	int limit_index;
	char temp[128];

	getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
	limit_index = search_limit_index(suitName, testName, pinName);

	if(limit_index!=9999)
	{
		if(result >= LowLimit && result <= HighLimit)
		{
			restore_limit_data(limit_index, result);
		}

		LIMIT lmt_obj;
		memset(temp,0,128);

		testName.copy(temp,testName.length(),0);
		PAT.copy(temp+testName.length(), PAT.length(), 0);
		testName_PAT = temp;

		if(debug) cout<<"is_limit_calculated "<<mDynamic_PAT_limit[limit_index].is_limit_calculated<<endl;
		if(mDynamic_PAT_limit[limit_index].is_limit_calculated)
		{
			if(debug) cout<<"limit low:"<< mDynamic_PAT_limit[limit_index].LCL<<endl;
			if(debug) cout<<"limit high:"<< mDynamic_PAT_limit[limit_index].UCL<<endl;
			lmt_obj.low(TM::GE, mDynamic_PAT_limit[limit_index].LCL);
			lmt_obj.high(TM::LE, mDynamic_PAT_limit[limit_index].UCL);
			lmt_obj.unit(mUnits);
			if(isMultiBin)
			{
				if(!TESTSET().cont(true).judgeAndLog_ParametricTest(pinName,testName_PAT,lmt_obj,result))
				{
					SET_MULTIBIN(PAT_soft_bin);
				}
			}
			else
			{
				TESTSET().cont(true).judgeAndLog_ParametricTest(pinName,testName_PAT,lmt_obj,result);
			}
		}

		if(mDynamic_PAT_limit[last_limit_index].initial_population == 0 && (CURRENT_SITE_NUMBER()==4))
		{
			if(debug) cout<<"initial_population is 0"<<endl;
			for(int i=0; i<=last_limit_index; i++)
			{
				calc_limit_PAT(i);
				mDynamic_PAT_limit[i].initial_population = restore_account;
			}
		}
	}

	return 0;
}


int PAT_Limit_compare_TestLimit(string suitName, string testName, string pinName, double result, LIMIT testLimit, string mUnits)
{
	string mLslTyp, mUslTyp;
	static string PAT = "_PAT";
	static string testName_PAT;
//	double UnitRatio;
	int limit_index;
	char temp[128];

    TM::COMPARE lowCmp, highCmp;
    double LowLimit,HighLimit;

    testLimit.get(lowCmp, LowLimit, highCmp, HighLimit);

//    if(debug) cout<<"LowLimit = "<<LowLimit<<endl;
//    if(debug) cout<<"HighLimit = "<<HighLimit<<endl;

	limit_index = search_limit_index(suitName, testName, pinName);

	if(limit_index!=9999)
	{
		if(result >= LowLimit && result <= HighLimit)
		{
			restore_limit_data(limit_index, result);
		}

		if(mDynamic_PAT_limit[last_limit_index].initial_population == 0)
		{
			if(debug) cout<<"initial_population is 0"<<endl;
			for(int i=0; i<=last_limit_index; i++)
			{
				calc_limit_PAT(i);
				mDynamic_PAT_limit[i].initial_population = restore_account;
			}
		}

		LIMIT lmt_obj;
		memset(temp,0,128);

		testName.copy(temp,testName.length(),0);
		PAT.copy(temp+testName.length(), PAT.length(), 0);
		testName_PAT = temp;

		if(debug) cout<<"is_limit_calculated "<<mDynamic_PAT_limit[limit_index].is_limit_calculated<<endl;
		if(mDynamic_PAT_limit[limit_index].is_limit_calculated)
		{
			if(debug) cout<<"limit low:"<< mDynamic_PAT_limit[limit_index].LCL<<endl;
			if(debug) cout<<"limit high:"<< mDynamic_PAT_limit[limit_index].UCL<<endl;
			lmt_obj.low(TM::GE, mDynamic_PAT_limit[limit_index].LCL);
			lmt_obj.high(TM::LE, mDynamic_PAT_limit[limit_index].UCL);
			lmt_obj.unit(mUnits);
//			if(isMultiBin)
//			{
//				if(!TESTSET().cont(true).judgeAndLog_ParametricTest(pinName,testName_PAT,lmt_obj,result))
//				{
//					SET_MULTIBIN(PAT_soft_bin);
//				}
//			}
//			else
//			{
//				TESTSET().cont(true).judgeAndLog_ParametricTest(pinName,testName_PAT,lmt_obj,result);
//			}
		}
	}
	return 0;
}


int PAT_Limit_compare_TestLimit(string suitName, string testName, string pinName, double result, int isMultiBin, int PAT_soft_bin, LIMIT testLimit, string mUnits)
{
	string mLslTyp, mUslTyp;
	static string PAT = "_PAT";
	static string testName_PAT;
//	double UnitRatio;
	int limit_index;
	char temp[128];

    TM::COMPARE lowCmp, highCmp;
    double LowLimit,HighLimit;

    testLimit.get(lowCmp, LowLimit, highCmp, HighLimit);

//    if(debug) cout<<"LowLimit = "<<LowLimit<<endl;
//    if(debug) cout<<"HighLimit = "<<HighLimit<<endl;

	limit_index = search_limit_index(suitName, testName, pinName);

	if(limit_index!=9999)
	{
		if(result >= LowLimit && result <= HighLimit)
		{
			restore_limit_data(limit_index, result);
		}

		if(mDynamic_PAT_limit[last_limit_index].initial_population == 0)
		{
			if(debug) cout<<"initial_population is 0"<<endl;
			for(int i=0; i<=last_limit_index; i++)
			{
				calc_limit_PAT(i);
				mDynamic_PAT_limit[i].initial_population = restore_account;
			}
		}

		LIMIT lmt_obj;
		memset(temp,0,128);

		testName.copy(temp,testName.length(),0);
		PAT.copy(temp+testName.length(), PAT.length(), 0);
		testName_PAT = temp;

		if(debug) cout<<"is_limit_calculated "<<mDynamic_PAT_limit[limit_index].is_limit_calculated<<endl;
		if(mDynamic_PAT_limit[limit_index].is_limit_calculated)
		{
			if(debug) cout<<"limit low:"<< mDynamic_PAT_limit[limit_index].LCL<<endl;
			if(debug) cout<<"limit high:"<< mDynamic_PAT_limit[limit_index].UCL<<endl;
			lmt_obj.low(TM::GE, mDynamic_PAT_limit[limit_index].LCL);
			lmt_obj.high(TM::LE, mDynamic_PAT_limit[limit_index].UCL);
			lmt_obj.unit(mUnits);
			if(isMultiBin)
			{
				if(!TESTSET().cont(true).judgeAndLog_ParametricTest(pinName,testName_PAT,lmt_obj,result))
				{
					SET_MULTIBIN(PAT_soft_bin);
				}
			}
			else
			{
				TESTSET().cont(true).judgeAndLog_ParametricTest(pinName,testName_PAT,lmt_obj,result);
			}
		}
	}
	return 0;
}

void clear_mNVR_redundancy_info(int site_Num)
{
	for(int i=0; i<8; i++)
	{
		mNVR_redundancy_info[site_Num][i].sector_recorded = 0;
		mNVR_redundancy_info[site_Num][i].redundancy_sector = 0;
		mNVR_redundancy_info[site_Num][i].redundancy_valid = 0;
	}
}


void OSC_trimming_reg_update(string label_name,int target_osc_code)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    unsigned int mask,vecNum;
    int edit_size = 20;

    if(debug)
    {
        hex(cout);
        if(print_reg) cout<<"target_osc_code site"<<CURRENT_SITE_NUMBER()<<" = "<<target_osc_code<<endl;
    }

	Primary.label(label_name);
    VECTOR_DATA myVectorData[edit_size];

    vecNum = 2366;
    for(int i=0; i<edit_size; i++)
    {
    	myVectorData[i].vectorNum = vecNum;
        vecNum++;
    }

    mask = 0x1;
    for(int i=0; i<10; i++)
    {
        myVectorData[i*2].phyWvfIndex = (target_osc_code & mask)? HIGH_WFIndex:LOW_WFIndex;
        myVectorData[i*2+1].phyWvfIndex = (target_osc_code & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    VEC_LABEL_EDIT myLabel1(label_name, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);
}

void OSC_PLL_out_trimming_reg_update(string label_name,int target_osc_code)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    unsigned int mask,vecNum;
    int edit_size = 20;

    if(debug)
    {
        hex(cout);
        if(print_reg) cout<<"target_osc_code site"<<CURRENT_SITE_NUMBER()<<" = "<<target_osc_code<<endl;
    }

	Primary.label(label_name);
    VECTOR_DATA myVectorData[edit_size];

    vecNum = 2428;
    for(int i=0; i<edit_size; i++)
    {
    	myVectorData[i].vectorNum = vecNum;
        vecNum++;
    }

    mask = 0x1;
    for(int i=0; i<10; i++)
    {
        myVectorData[i*2].phyWvfIndex = (target_osc_code & mask)? HIGH_WFIndex:LOW_WFIndex;
        myVectorData[i*2+1].phyWvfIndex = (target_osc_code & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    VEC_LABEL_EDIT myLabel1(label_name, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);
}

void TS_trimming_reg_update(string label_name)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    unsigned int mask,vecNum,trim_reg;
    int edit_size = 32*16;
    int i,j;

	Primary.label(label_name);
    VECTOR_DATA myVectorData[edit_size];

    vecNum = 2077;
    for(i=0; i<16; i++)
    {
    	for(j=0; j<32; j++)
    	{
        	myVectorData[i*32+j].vectorNum = vecNum+i*380+j;
//          vecNum++;
    	}
    }

    mask = 0x1;
    trim_reg = 0x1;
    for(i=0; i<16; i++)
    {
        mask = 0x1;
    	for(j=0; j<16; j++)
    	{
            myVectorData[i*32+j*2].phyWvfIndex = (trim_reg & mask)? HIGH_WFIndex:LOW_WFIndex;
            myVectorData[i*32+j*2+1].phyWvfIndex = (trim_reg & mask)? HIGH_WFIndex:LOW_WFIndex;
            mask = mask<<1;
    	}
        trim_reg = trim_reg<<1;
    }

    VEC_LABEL_EDIT myLabel1(label_name, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);
}


void VDD_trimming_reg_update(string label_name)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    unsigned int mask,vecNum,trim_reg;
    int edit_size = 8*16;
    int i,j;

	Primary.label(label_name);
    VECTOR_DATA myVectorData[edit_size];

    vecNum = 2145;
    for(i=0; i<8; i++)
    {
    	for(j=0; j<16; j++)
    	{
        	myVectorData[i*16+j].vectorNum = vecNum+i*380+j;
//          vecNum++;
    	}
    }

    mask = 0x1;
    trim_reg = 0x1;
    for(i=0; i<8; i++)
    {
        mask = 0x1;
    	for(j=0; j<8; j++)
    	{
            myVectorData[i*16+j*2].phyWvfIndex = (trim_reg & mask)? HIGH_WFIndex:LOW_WFIndex;
            myVectorData[i*16+j*2+1].phyWvfIndex = (trim_reg & mask)? HIGH_WFIndex:LOW_WFIndex;
            mask = mask<<1;
    	}
        trim_reg = trim_reg<<1;
    }

    VEC_LABEL_EDIT myLabel1(label_name, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);
}

int Flash_update_trimming_bits(int site_index, string label_name)
{
	unsigned char trimm_data[128];
	unsigned int Trim0, Trim1;
	unsigned int byte0 = 0xff;
	unsigned int byte1 = 0xff00;
	unsigned int byte2 = 0xff0000;
	unsigned int byte3 = 0xff000000;

//	VDD33_high_trim[site_index] = 0x08;	VDD33_low_trim[site_index] = 0x10;	VDD18_high_trim[site_index] = 0x08;	VDD18_low_trim[site_index] = 0x10;

//	temp_high_trim[site_index] = 0xb;temp_low_trim[site_index] = 0x7;OSC_trim[site_index] = 0x21d; //#1
//	temp_high_trim[site_index] = 0xb;temp_low_trim[site_index] = 0x6;OSC_trim[site_index] = 0x220; //#3
//	temp_high_trim[site_index] = 0xb;temp_low_trim[site_index] = 0x7;OSC_trim[site_index] = 0x218; //#5
//	temp_high_trim[site_index] = 0xa;temp_low_trim[site_index] = 0x7;OSC_trim[site_index] = 0x20a; //#7
//	temp_high_trim[site_index] = 0xb;temp_low_trim[site_index] = 0x6;OSC_trim[site_index] = 0x21f; //#8
//	temp_high_trim[site_index] = 0xb;temp_low_trim[site_index] = 0x6;OSC_trim[site_index] = 0x212; //#10
//	temp_high_trim[site_index] = 0xb;temp_low_trim[site_index] = 0x6;OSC_trim[site_index] = 0x235; //#11

	Trim0 = VDD33_high_trim[site_index] + (VDD33_low_trim[site_index]<<8) +
			(VDD18_high_trim[site_index]<<16) + (VDD18_low_trim[site_index]<<24);
//	Trim1 = (0xf0<<24) + (OSC_trim[site_index]<<16) + temp_high_trim[site_index] + (temp_low_trim[site_index]<<4);
	Trim1 = (0x00<<24) + (OSC_trim[site_index]<<16) + temp_high_trim[site_index] + (temp_low_trim[site_index]<<4);

	if(debug)
	{
		hex(cout);
		cout<<"Trim0 = 0x"<<Trim0<<endl;
		cout<<"Trim1 = 0x"<<Trim1<<endl;
	}

	trimm_data[0] = (Trim0&byte0)^0xff;
	trimm_data[1] = ((Trim0&byte1)>>8)^0xff;
	trimm_data[2] = ((Trim0&byte2)>>16)^0xff;
	trimm_data[3] = ((Trim0&byte3)>>24)^0xff;

	trimm_data[4] = (Trim1&byte0)^0xff;
	trimm_data[5] = ((Trim1&byte1)>>8)^0xff;
	trimm_data[6] = ((Trim1&byte2)>>16)^0xff;
	trimm_data[7] = ((Trim1&byte3)>>24)^0xff;
	trimm_data[8] = 0xff;

//	trimm_data[0] = (Trim0&byte0);
//	trimm_data[1] = ((Trim0&byte1)>>8);
//	trimm_data[2] = ((Trim0&byte2)>>16);
//	trimm_data[3] = ((Trim0&byte3)>>24);
//
//	trimm_data[4] = (Trim1&byte0);
//	trimm_data[5] = ((Trim1&byte1)>>8);
//	trimm_data[6] = ((Trim1&byte2)>>16);
//	trimm_data[7] = ((Trim1&byte3)>>24);
//	trimm_data[8] = 0xff;

	Flash_write_single_address_pattern_update(trimm_data, label_name);
	return 0;
}

int Flash_write_single_address_pattern_update(unsigned char *data, string vector_name)
{
    int HIGH_WFIndex = 1;
    int LOW_WFIndex = 0;
    int mask;
    int addr_count = 1;
    int single_addr_op = 12;
    int address_byte = 9;
    int address_data = 8;
    int bit_per_byte = 8;
    int addr_op_cycle = 1394;
    int address_bit = address_byte*bit_per_byte;
    int data_size = addr_count*address_byte;
    int edit_size = data_size*address_data*single_addr_op;
    bool databool[data_size*address_data];

	Primary.label(vector_name);
    VECTOR_DATA myVectorData[edit_size];

//    for(int i=0; i<9; i++)
//    {
//    	cout<<"data["<<i<<"] = "<<*(data+i)-'\0'<<endl;
//    }

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<single_addr_op; j++)
    	{
    		for(int k=0; k<address_bit; k++)
    		{
            	myVectorData[i*single_addr_op*address_bit+j*address_bit+k].vectorNum = i*addr_op_cycle + mData_index[j].data_start + k;
    		}
    	}
    }

    for(int i=0; i<data_size; i++)
    {
    	mask = 1;
    	for(int j=0; j<bit_per_byte; j++)
    	{
        	databool[i*8+j] = *(data+i) & mask;
        	mask = mask<<1;
    	}
    }

    for(int i=0; i<addr_count; i++)
    {
    	for(int j=0; j<single_addr_op; j++)
    	{
    		for(int k=0; k<address_bit; k++)
    		{
            	myVectorData[i*single_addr_op*address_bit+j*address_bit+k].phyWvfIndex = databool[i*address_bit+k] ? HIGH_WFIndex:LOW_WFIndex;
    		}
    	}
    }

    VEC_LABEL_EDIT myLabel1(vector_name, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);

	return 0;
}


int is_one_hot_code(int input, int bits)
{
	int i;
	int mark=1;
	int hot_bits=0;

	for(i=0; i<bits; i++)
	{
		if((input&mark) != 0)
		{
			hot_bits++;
		}
		mark = mark<<1;
//		if(debug) cout<<"mark = "<<mark<<endl;
	}

//	if(debug) cout<<"input = "<<input<<endl;
//	if(debug) cout<<"hot_bits = "<<hot_bits<<endl;

	if(hot_bits==1)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void misc_reg_set(string label_name,unsigned int addr, unsigned int data)
{
    int HIGH_WFIndex = 2;
    int LOW_WFIndex = 0;
    unsigned int mask,vecNum;
    int edit_size = 64;

	Primary.label(label_name);
    VECTOR_DATA myVectorData[edit_size];

    vecNum = 22;
    for(int i=0; i<edit_size/2; i++)
    {
    	myVectorData[i].vectorNum = vecNum;
        vecNum++;
    }

    vecNum = 68;
    for(int i=0; i<edit_size/2; i++)
    {
    	myVectorData[32+i].vectorNum = vecNum;
        vecNum++;
    }

    mask = 0x1;
    for(int i=0; i<edit_size/2; i++)
    {
        myVectorData[i].phyWvfIndex = (addr & mask)? HIGH_WFIndex:LOW_WFIndex;
        myVectorData[32+i].phyWvfIndex = (data & mask)? HIGH_WFIndex:LOW_WFIndex;
        mask = mask<<1;
    }

    VEC_LABEL_EDIT myLabel1(label_name, "TDI");
    myLabel1.downloadUserVectors(myVectorData, edit_size);
}

void UART_Protocols(string pattern_name, string cap_vari)
{
	ARRAY_I adWave;
	string pin_name = "XTAL_IN";
	char TASK[256];
	char temp[256];
	unsigned char one_byte;
	double test_period;
	double Fsmpl;
	double sample_interval;
	double byte_factor = 10;
//	int standard_multi = 140;
//	int tolerance = 40;
	int gap_count;
	int stage_continued;
	int gap_index;
	int cap_size;
	int UART_start_cycle;
	int search_mark;
	int byte_mark;
	int pattern_length;
	int i;
	string FW_ANSWER;

	//get the test period of primary timing set by pclk
	sprintf(TASK,"PCLK? PRM,PRM,(%s),EXACT;",pin_name.c_str());
	FW_TASK(TASK, FW_ANSWER);
	strcpy(temp,FW_ANSWER.c_str());
	strtok(temp,",");strtok(0,",");
	test_period = atof(strtok(0,","));
	Fsmpl = 1000*1/test_period;

	adWave = VECTOR(cap_vari).getVectors();
	sample_interval = 0;
	cap_size = adWave.size();
	pattern_length = cap_size-150000;

	int bit_size = (int)(pattern_length/100);
	int stage_gap[bit_size];

	search_mark= 0;

	for(i=0; i<bit_size; i++)
	{
		stage_gap[i] = 0;
	}

	stage_continued = 1;
	gap_index = 0;
	for(i=0; i<pattern_length; i++)
	{
		if(adWave[i]!=adWave[i+1])
		{
			stage_gap[gap_index]=stage_continued;
			stage_continued=1;
//			dec(cout);
//			cout<<"stage_gap["<<gap_index<<"] = "<<stage_gap[gap_index]<<endl;
			gap_index++;
		}
		else
		{
			stage_continued++;
		}
	}

	gap_count = 0;
	for(i=0; i<bit_size; i++)
	{
		if(stage_gap[i]>100 && stage_gap[i]<150)
		{
			sample_interval = sample_interval + stage_gap[i];
			gap_count++;
		}
		if(stage_gap[i]>200 && stage_gap[i]<300)
		{
			sample_interval = sample_interval + stage_gap[i];
			gap_count=gap_count+2;
		}
		if(stage_gap[i]>300 && stage_gap[i]<450)
		{
			sample_interval = sample_interval + stage_gap[i];
			gap_count=gap_count+3;
		}
		if(stage_gap[i]>500 && stage_gap[i]<600)
		{
			sample_interval = sample_interval + stage_gap[i];
			gap_count=gap_count+4;
		}
		if(stage_gap[i]>600 && stage_gap[i]<750)
		{
			sample_interval = sample_interval + stage_gap[i];
			gap_count=gap_count+5;
		}
		if(stage_gap[i]>800 && stage_gap[i]<900)
		{
			sample_interval = sample_interval + stage_gap[i];
			gap_count=gap_count+6;
		}
	}
	sample_interval = sample_interval/gap_count;
//	cout<<"sample_interval = "<<sample_interval<<endl;

	while(search_mark<pattern_length)
	{
		for(i = search_mark; i<cap_size; i++)
		{
			if(adWave[i] == 0)
			{
				UART_start_cycle = i;
				break;
			}
		}
		search_mark = i;
		if(search_mark>=cap_size)
		{
			UART_start_cycle = search_mark;
		}

		byte_mark = 0;
		for(i = UART_start_cycle+(int)(sample_interval*7/8); i<cap_size;)
		{
			one_byte = adWave[i+(int)sample_interval] + (adWave[i+(int)sample_interval*2]<<1)+
			    (adWave[i+(int)sample_interval*3]<<2) + (adWave[i+(int)sample_interval*4]<<3)+
			    (adWave[i+(int)sample_interval*5]<<4) + (adWave[i+(int)sample_interval*6]<<5)+
			    (adWave[i+(int)sample_interval*7]<<6) + (adWave[i+(int)sample_interval*8]<<7);

			if(one_byte != 255)
			{
				hex(cout);
//				cout<<i+(int)sample_interval<<" ";
//				hex(cout);
//				cout<<one_byte<<" ;";
				cout<<one_byte;
//				cout<<one_byte-0<<" ;";
			}
			else
			{
				cout<<endl;
				break;
			}
			byte_mark++;
//			cout<<"byte_mark "<<byte_mark<<endl;
//			cout<<"UART_start_cycle "<<UART_start_cycle<<endl;
			i = UART_start_cycle+(int)(sample_interval*7/8) + (int)(byte_mark*sample_interval*byte_factor);
		}
		byte_mark++;
		search_mark = search_mark + (int)(byte_mark*sample_interval*byte_factor);
//		cout<<"search mark = "<<search_mark<<endl;
	}
}

int save_encrypt_key_data_to_local_file(string device_type, unsigned char *CHIP_ID_hex,unsigned char *OTP_hex,unsigned char *Flash_hex)
{
	FILE *fp = NULL;
	char file_path[512];
	char device_char[512];
	strcpy(device_char, device_type.c_str());
//	GetDevPath(device_path);
	sprintf(file_path,"%s%s%s","/home/prod/XTI_Engineering/encrypt_key_data/",device_char,"/encrypt_key_data.txt");
	if((fp=fopen(file_path,"a+"))==NULL)
	{
		cout<<"======================================================"<<endl;
		cout<<"Error!There is no encrypt_key_data.txt file!\n"<<endl;
		cout<<"======================================================"<<endl;
		return 0;
	}
	else
	{
		for (int i = 0; i < chip_ID_byte; i++)
		{
			fprintf(fp, "%02X", *(CHIP_ID_hex+i));
		}

		fprintf(fp, " %s", device_char);

		fprintf(fp, "\n");


//		for (int i = 0; i < OTP_byte; i++)
//		{
//			fprintf(fp, "%02X", *(OTP_hex+i));
//		}
//		fprintf(fp, "\n");
//
//		for (int i = 0; i < Flash_byte; i++)
//		{
//			if(i%1024 == 0 && i != 0)
//			{
//				fprintf(fp, "\n");
//			}
//			fprintf(fp, "%02X", *(Flash_hex+i));
//		}
//		fprintf(fp, "\n");
//		fprintf(fp, "\n");

		fclose(fp);
	}

	return 1;
}
