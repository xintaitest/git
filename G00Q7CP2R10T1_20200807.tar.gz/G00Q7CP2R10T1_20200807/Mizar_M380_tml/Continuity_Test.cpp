#include "testmethod.hpp"

//for test method API interfaces
#include "mapi.hpp"
#include "Public.h"
using namespace std;
using namespace V93kLimits;

/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Continuity_Test_neg: public testmethod::TestMethod {

protected:
	string  check_negative;

  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	addParameter("check_negative_pins",
			     "PinString",
			     &check_negative,
			     testmethod::TM_PARAMETER_INPUT);
    //Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    //Add your test code here.
	static STRING_VECTOR pinListNeg;
	static string suitName,testName;
	unsigned int i;
	TMLimits::LimitInfo mLimitInfo;
	double LowLimit, HighLimit, UnitRatio;
	string mUnits, mLslTyp, mUslTyp;
	PPMU_SETTING setting_p ,setting_n;
	PPMU_RELAY relay_p_on ,relay_p_off,relay_n_on,relay_n_off;
	PPMU_MEASURE meas_n;
	PPMU_CLAMP clamp_on_p, clamp_off_p,clamp_on_n, clamp_off_n;
	TASK_LIST task_p;

	ON_FIRST_INVOCATION_BEGIN();
		DISCONNECT();
		FLUSH();
		pinListNeg=PinUtility.getDigitalPinNamesFromPinList(check_negative,TM::ALL_DIGITAL,true,true);

		setting_n.pin(check_negative).iRange(1 mA);
		setting_n.pin(check_negative).iForce(-200 uA).min(-0.9 V).max(-0.2 V);

		clamp_on_n.pin(check_negative).status("CLAMP_ON").low(-2 V).high(0 V);
		clamp_off_n.pin(check_negative).status("CLAMP_OFF");
		clamp_off_n.wait(1 ms);

		relay_n_on.pin(check_negative).status("PPMU_ON");
		relay_n_on.wait(1 ms);
		relay_n_off.pin(check_negative).status("PPMU_OFF");
		relay_n_off.wait(1 ms);
		meas_n.pin(check_negative).execMode(TM::PVAL);
		FLUSH();
		task_p.add(setting_n).add(clamp_on_n).add(relay_n_on).add(clamp_off_n).add(meas_n).add(clamp_on_n).add(relay_n_off).add(clamp_off_n).execute();
		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;

	if(debug)
	{

		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(i=0;i<pinListNeg.size();i++)
		{
			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinListNeg[i],meas_n.getValue(pinListNeg[i]));
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	for(i=0;i<pinListNeg.size();i++)
	{
		getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinListNeg[i],testName,tmLimits,meas_n.getValue(pinListNeg[i])*UnitRatio);
	}

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const 
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Continuity_Test.neg", Continuity_Test_neg);



/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Continuity_Test_pos: public testmethod::TestMethod {

protected:
	string  check_positive;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
	addParameter("check_positive_pins",
				 "PinString",
		    	 &check_positive,
		    	 testmethod::TM_PARAMETER_INPUT);
    //Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    //Add your test code here.
	static STRING_VECTOR  pinListPos;
	static string suitName,testName;
	unsigned int i;
	TMLimits::LimitInfo mLimitInfo;
	double LowLimit, HighLimit, UnitRatio;
	string mUnits, mLslTyp, mUslTyp;
	PPMU_SETTING setting_p ,setting_n;
	PPMU_RELAY relay_p_on ,relay_p_off,relay_n_on,relay_n_off;
	PPMU_MEASURE meas_p,meas_n;
	PPMU_CLAMP clamp_on_p, clamp_off_p,clamp_on_n, clamp_off_n;
	TASK_LIST task_p;
	ON_FIRST_INVOCATION_BEGIN();

		DISCONNECT();
		FLUSH();
//		FW_TASK("rlyc idle,off,(VPP,VDD18,VNN)\n");

		pinListPos=PinUtility.getDigitalPinNamesFromPinList(check_positive,TM::ALL_DIGITAL,true,true);

		setting_p.pin(check_positive).iRange(1 mA);
		setting_p.pin(check_positive).iForce(200 uA).min(0.2 V).max(0.9 V);
		clamp_on_p.pin(check_positive).status("CLAMP_ON").low(0 V).high(2 V);
		clamp_off_p.pin(check_positive).status("CLAMP_OFF");
		clamp_off_p.wait(5 ms);
		relay_p_on.pin(check_positive).status("PPMU_ON");
		relay_p_on.wait(3 ms);
		relay_p_off.pin(check_positive).status("PPMU_OFF");
		relay_p_off.wait(5 ms);
		meas_p.pin(check_positive).execMode(TM::PVAL);

		task_p.add(setting_p).add(clamp_on_p).add(relay_p_on).add(clamp_off_p).add(meas_p).add(clamp_on_p).add(relay_p_off).add(clamp_off_p).execute();

		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(i=0;i<pinListPos.size();i++)
		{
			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinListPos[i],meas_p.getValue(pinListPos[i]));
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	for(i=0;i<pinListPos.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinListPos[i],testName,tmLimits,meas_p.getValue(pinListPos[i])*UnitRatio);
	}
    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Continuity_Test.pos", Continuity_Test_pos);

