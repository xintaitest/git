#include "testmethod.hpp"

//for test method API interfaces
#include "mapi.hpp"
using namespace std;
#include "tpi_c.h"
#include "/opt/hp93000/soc/pws/lib/tpi_c.h"
#include "/opt/hp93000/soc/prod_com/include/libcicpi.h"
#include <malloc.h>
#include <stdio.h>
#include <math.h>

/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class WriteXYWafer: public testmethod::TestMethod {

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    //Add your test code here.
	  long Xcoord,Ycoord,WaferID;
	  static int fuse_length,start_cycle;
	  char wid_char[CI_CPI_MAX_MODL_STRING_LEN+2];

	  fuse_length=32;
	  start_cycle=458;  //origin
	  GetModelfileString("PH_wafer_id",wid_char);
	  //strcpy(wid_char,"H6V689-21B2");
	  WaferID= (long(wid_char[7])-48)*10+(long(wid_char[8])-48);
		 FOR_EACH_SITE_BEGIN();

		 int XYW[2*fuse_length];

		 GetDiePosXYOfSite(CURRENT_SITE_NUMBER(),&Xcoord,&Ycoord);

//for debug use
/*
		 int site;
		 site = CURRENT_SITE_NUMBER();
		 if(site==1){
			 Xcoord=59;
			 Ycoord=5;
		 }else if(site==2){
			 Xcoord=58;
			 Ycoord=6;
		 }else if(site==3){
			 Xcoord=57;
			 Ycoord=7;
		 }else{
			 Xcoord=56;
			 Ycoord=8;
		 }
		 WaferID=7;
*/

//for debug use


		 cout<<"X: "<<Xcoord<<endl;
		 cout<<"Y: "<<Ycoord<<endl;
		 cout<<"Wafer ID: "<<WaferID<<endl;

		 for(int i=0;i<2*fuse_length;i++)
			{
					 XYW[i]=1;
			}

		for(int i=0;i<fuse_length;i++)
			{
                if(i==0 or i==2) //buffer
                {
                         XYW[2*i]=0;
                         XYW[2*i+1]=0;
                }
                else if(i==1 or i==3) //buffer
                {
                         XYW[2*i]=1;
                         XYW[2*i+1]=1;
                }
                else if(i < 12)
				{
					XYW[2*i]=Xcoord%2;
					XYW[2*i+1]=Xcoord%2;
					Xcoord=Xcoord/2;
				}
				else if(i < 20)
				{
					XYW[2*i]=Ycoord%2;
					XYW[2*i+1]=Ycoord%2;
					Ycoord=Ycoord/2;
				}
				else
				{
					XYW[2*i]=WaferID%2;
					XYW[2*i+1]=WaferID%2;
					WaferID=WaferID/2;
				}
			}



		for(int i=8;i<2*fuse_length;i++)
		{
		 cout<<XYW[i];
		}
		 cout<<endl;



		VEC_LABEL_EDIT MyXYW_fuses("PES_full","IOL10D");
		VECTOR_DATA myVector_edit_data0[2*fuse_length+1];
		for(int i=0;i<2*fuse_length;i++)
			{
				myVector_edit_data0[i].phyWvfIndex=XYW[i];
				myVector_edit_data0[i].vectorNum=start_cycle+i;
		 	}
		 myVector_edit_data0[2*fuse_length].phyWvfIndex=-1;
		 myVector_edit_data0[2*fuse_length].vectorNum=-1;

		 MyXYW_fuses.downloadUserVectors("IOL10D",myVector_edit_data0);
		 MyXYW_fuses.storeVectorData(start_cycle,2*fuse_length,"IOL10D");

//		 			   TESTSET().cont(true).judgeAndLog_FunctionalTest();
		 FOR_EACH_SITE_END();
		  //Sequencer.reset();
		 FUNCTIONAL_TEST();
		/* XYWafer[0]=Xcoord+1024*Ycoord+1024*1024*WaferID;
			VECTOR("XYW").format("BIN").bits(32).setVectors(XYWafer);
			FUNCTIONAL_TEST();
		 FOR_EACH_SITE_END();
		 */

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("WriteXYWafer", WriteXYWafer);
