#ifndef INCLUDED_DpsUtil
#define INCLUDED_DpsUtil

#include "TestSet_r.h"
#include "CommonUtil.hpp"


/*
*----------------------------------------------------------------------*
* DpsUtil:
*      This class do DPS measurement based on the DPS_TASK.
*      We use it to implement the operating current and standby current
*----------------------------------------------------------------------*
*/

class DpsUtil
{
public:
  /*These elements are defined for DPS status checking. */
  enum DpsStatus
  {
    CONSTANT_CURRENT  = 0x02,
    UNREGULATED       = 0x04,
    OVER_VOLTAGE      = 0x08,
    OVER_POWER_TEMP   = 0x30,
    PROTECT           = 0x1000
  };

  enum DpsChannelType
  {
    NORNAL,
    UHC4T
  };

  static void currentMeasurement(
                const STRING&           dpsPins,
                const LIMIT&            limit,
                const TM::DCTEST_MODE&  testMode,  
                DPS_TASK&               dpsTask,
                const INT               samples,
                const DOUBLE            waitTime_ms = 0,
                const TM::TrigMode      trigMode = TM::INTERNAL);
  static void currentMeasurement(DPS_TASK&  dpsTask);
  
  static void currentGetResult(
                const STRING_VECTOR&    dpsPins,                              
                const TM::DCTEST_MODE&  mode,
                const DPS_TASK&         dpsTask,
                MeasurementResultContainer& measureResult,
                const STRING&           gangedMode = TURN_OFF);

  static void setDpsTask(
                const STRING&           dpsPins,
                const LIMIT&            limit,
                const INT&              samples,
                const STRING&           gangedMode,
                const TM::DCTEST_MODE&  testMode,
                DPS_TASK&               dpsTask,
                const DOUBLE            waitTime_ms = 0,
                const TM::TrigMode      trigMode = TM::INTERNAL);

  static void switchDpsStateToLOZ(STRING& fwCmd);

  static void restoreDpsStateFromLozToHIZ(STRING& fwCmd);

  static void getGangedLimitOfDPSPins(
                const string&           dpsPinsType,
                const LIMIT&            limit,
                double&                 gangedLimit,
                double&                 gangedLimitforUHC4);

  static void setDpsMeasurementMode(
                const STRING&           dpsPins,
                const LIMIT&            limit,
                DPS_TASK&               dpsTask);

  static void parseDpsPinType(
                const STRING&           dpsPins,
                map<string, string>&    dpsPinTypeMap);

  static void getDpsPinInfo(
                const STRING&           dpsPins,
                map<string, map<bool, INT> >& dpsPinMapInfo);
};

/* 
 *----------------------------------------------------------------------* 
 * Routine: DpsUtil::currentMeasurement
 *
 * Purpose: execute Current Measurement by using DPS_TASK
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 * Note:
 *
 *----------------------------------------------------------------------*
 */

inline void DpsUtil::currentMeasurement(
                const STRING&          dpsPins,
                const LIMIT&           limit,
                const TM::DCTEST_MODE& testMode,  /*"PVAL","PPF" or "GPF"*/
                DPS_TASK&              dpsTask,
                const INT              samples,
                const DOUBLE           waitTime_ms,
                const TM::TrigMode     trigMode        /*default is TM::INTERNAL*/
                )
{
  setDpsMeasurementMode(dpsPins,limit,dpsTask);
  dpsTask.trigMode(trigMode);
  dpsTask.trigMode(trigMode);
  dpsTask.execMode(testMode);
  dpsTask.samples(samples);


  if (trigMode == TM::INTERNAL && waitTime_ms > 0.0)
  {
    dpsTask.wait(waitTime_ms ms);
  }

  dpsTask.execute();
}
 /*
 *----------------------------------------------------------------------*
 * Routine: DpsUtil::currentMeasurement
 *
 * Purpose: execute Current Measurement by using DPS_TASK
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 * Note:
 *
 *----------------------------------------------------------------------*
 */

inline void DpsUtil::currentMeasurement( DPS_TASK& dpsTask)   
{
  dpsTask.execute();
}

/*
 *----------------------------------------------------------------------*
 * Routine: DpsUtil::currentGetResult
 *
 * Purpose: get the result
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 *    can be done with ganged current.
 *----------------------------------------------------------------------*
 */
inline void DpsUtil::currentGetResult(
                const STRING_VECTOR&      dpsPins,                                        
                const TM::DCTEST_MODE&    mode,                                       
                const DPS_TASK&           dpsTask,
                MeasurementResultContainer&   measureResult,
                const STRING&             gangedMode
                )
{
  Boolean isPass;
  STRING_VECTOR::const_iterator it;
  double dVal = 0.0;

  if ( gangedMode == TURN_ON )
  { /* for gang mode case */
    for ( it = dpsPins.begin(); it != dpsPins.end(); ++it )
    {
      measureResult.setPinsValue((*it), dpsTask.getValue( *it ));
    }
  }
  else
  { /*for ungang mode*/
    switch ( mode )
    {
    case TM::PVAL:
      for ( it = dpsPins.begin(); it != dpsPins.end(); ++it )
      {
        dVal = dpsTask.getValue( *it );
        isPass = dpsTask.getPassFail( *it );
        measureResult.setPinsValue((*it), dVal);
        measureResult.setPinPassFail((*it),isPass);

      }
      break;
    case TM::PPF:
      for ( it = dpsPins.begin(); it != dpsPins.end(); ++it )
      {
        isPass = dpsTask.getPassFail( *it );
        measureResult.setPinPassFail((*it),isPass);
      }
      break;
    case TM::GPF:
      isPass = dpsTask.getPassFail();
      measureResult.setGlobalPassFail(isPass);
      break;
    default:
      throw Error("DpsUtil::currentGetResult",
                  "Unknown Test Mode");
    }  /*end of switch*/
  } /*end of if-else*/
}

 /*
 *----------------------------------------------------------------------*
 * Routine: DpsUtil::setDpsTask
 *
 * Purpose: set the DpsTask
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 * Note:
 *
 *----------------------------------------------------------------------*
 */

inline void DpsUtil::setDpsTask(                       
               const STRING&          dpsPins,
               const LIMIT&           limit,
               const INT&             samples,
               const STRING&          gangedMode,
               const TM::DCTEST_MODE& testMode,  /*"PVAL","PPF" or "GPF"*/
               DPS_TASK&              dpsTask,
               const DOUBLE           waitTime_ms,
               const TM::TrigMode     trigMode        /*default is TM::INTERNAL*/
               )
{
  setDpsMeasurementMode(dpsPins,limit,dpsTask);

  dpsTask.trigMode(trigMode);
  dpsTask.samples(samples);

  if (trigMode == TM::INTERNAL && waitTime_ms > 0.0)
  {
    dpsTask.wait(waitTime_ms ms);
  }

  if( gangedMode == TURN_ON )
  { /*In ganged mode, PPF&GPF is retrieved from PVAL too.*/
    dpsTask.execMode(TM::PVAL);
  }
  else
  {
    dpsTask.execMode(testMode);
  }

}

/*
 *----------------------------------------------------------------------*
 * Routine: DpsUtil::switchDpsStateToLOZ
 *
 * Purpose: conditionally change DPS to LOZ state
 *
 *----------------------------------------------------------------------*
 * Description:
 *   (1) check primary setting of ALL DPS pins.
 *   (2) change the states of ALL 'HIZ' dps pins to 'LOZ' state.
 * Note:
 *
 *----------------------------------------------------------------------*
 */
inline void DpsUtil::switchDpsStateToLOZ(STRING& strFwRestoreToHIZ)
{
  /*query DPS states of primary setting*/
  STRING strFwAnswer = "";

  FW_TASK("PSLV? PRM,(@)\n",strFwAnswer);

  STRING::size_type iCmdHeaderPos       = 0; /*the position of "PSLV"*/
  STRING::size_type iStatePos           = 0; /*the position of "HIZ" or "HIZ_R", "LOZ_HIZ", "LOZ_HIZ_R"*/
  STRING::size_type iCommaAfterStatePos = 0; /*the position of the comma after state*/
  STRING::size_type iPos                = 0; /*the other positions*/
  STRING strFwCmdToLOZ    = "";/*FW string to switch DPS to LOZ state*/

  iCmdHeaderPos = strFwAnswer.find("PSLV");
  while (iCmdHeaderPos != string::npos)
  {
    /*to identify "LOZ_HIZ" and "LOZ_HIZ_R"*/
    iStatePos = strFwAnswer.find("LOZ_HIZ",iCmdHeaderPos);
    if (iStatePos == string::npos )
    {
      /*to identify "HIZ" and "HIZ_R"*/
      iStatePos = strFwAnswer.find("HIZ",iCmdHeaderPos);
    }

    iPos   = strFwAnswer.find("(",iCmdHeaderPos);
    /*
     *******************************************************
     * The valid "HIZ" or "HIZ_R" must be before the "(".
     * and identify the special case:
     * "...,LOZ,,(Vcc,HIZ,Vee)\n".
     *******************************************************
     */
    if ( (iStatePos != string::npos) && (iPos > iStatePos) )
    {
      iCommaAfterStatePos = strFwAnswer.find(",",iStatePos);
      iPos=strFwAnswer.find(")",iPos+1);
      if (iPos == string::npos)
        break;
      else
        {
              //iPos = static_cast<string::size_type> (ReturnStringFind);
              ++iPos; /*move to "\n"*/
              /*create FW command string of restoring dps state.*/
              strFwRestoreToHIZ += strFwAnswer.substr(iCmdHeaderPos,
                                                      iPos-iCmdHeaderPos+1);

              /*create FW command string of switching dps to LOZ.*/
              strFwCmdToLOZ += strFwAnswer.substr(iCmdHeaderPos,
                                                  iStatePos-iCmdHeaderPos);
              strFwCmdToLOZ += "LOZ";
              strFwCmdToLOZ += strFwAnswer.substr(iCommaAfterStatePos,
                                                  iPos-iCommaAfterStatePos+1);
          }
      }

    /*try to find the next command line*/
    iCmdHeaderPos = strFwAnswer.find("PSLV",iPos+1);
  }
  /*send command if any*/
  if ( !strFwCmdToLOZ.empty() )
  {
    FW_TASK(strFwCmdToLOZ);
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: DpsUtil::RestoreDpsStateFromLoz
 *
 * Purpose: restore DPS to HIZ state
 *
 *----------------------------------------------------------------------*
 * Description:
 *    Based on the existing command, and append updating setup command
 *   and then send FW command.
 *
 * Note:
 *
 *----------------------------------------------------------------------*
 */
inline void DpsUtil::restoreDpsStateFromLozToHIZ(STRING& fwCmd)
{
  if ( !fwCmd.empty() )
  {
    /*append a string of update the DPS level setup*/
    fwCmd += " UPTD DPS,1\nUPTD LEV,1\n";
    FW_TASK(fwCmd);
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: DpsUtil::getGangedLimitOfDPSPins
 *
 * Purpose: get the limit value
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 *    get the limit value which can control unganged or ganged measurement for different DPS types
 *    below default limit unit is uA
 *----------------------------------------------------------------------*
 */
inline void DpsUtil::getGangedLimitOfDPSPins(
               const string&          dpsPinsType,
               const LIMIT&           limit,
               double&                gangedLimit,
               double&                gangedLimitforUHC4)
{
  if (dpsPinsType.compare("DPS32") == 0)
  {
     gangedLimit        = 1500000;
     gangedLimitforUHC4 = 0;
  }
  else if (dpsPinsType.compare("DPS64") == 0)
  {
     gangedLimit        = 1000000;
     gangedLimitforUHC4 = 0;
  }
  else if (dpsPinsType.compare("DPS128") == 0)
  {
     gangedLimit        = 1000000;
     gangedLimitforUHC4 = 0;
  }
  else if (dpsPinsType.compare("VI32") == 0)
  {
     gangedLimit        = 500000;
     gangedLimitforUHC4 = 0;
  }
  else if (dpsPinsType.compare("UHC4") == 0)
  {
     gangedLimit        = 40000000;
     gangedLimitforUHC4 = 1500000;
  }
  else if (dpsPinsType.compare("UHC4T") == 0)
  {
     gangedLimit        = 40000000;
     gangedLimitforUHC4 = 1500000;
  }
  else
  {
     gangedLimit        = 0;
     gangedLimitforUHC4 = 0;
  }
  /*unit check and conversion*/
  if (!limit.unit().empty() && limit.unit().find(";") == string::npos)
  {
      double factor_LimitUnitToA = SI_Value::getDiffValue(limit.unit(),"A");
      gangedLimit *= factor_LimitUnitToA;
      gangedLimitforUHC4 *= factor_LimitUnitToA;
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: DpsUtil::setDpsMeasurementMode
 *
 * Purpose: set DPS Measurement Mode
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 *    set DPS Measurement Mode for for different DPS types, which is ganged or unganed mode
 *----------------------------------------------------------------------*
 */
inline void DpsUtil::setDpsMeasurementMode(
               const STRING&          dpsPins,
               const LIMIT&           limit,
               DPS_TASK&              dpsTask)
{
  double lowVal;
  double highVal;
  limit.getLow(&lowVal);
  limit.getHigh(&highVal);
  if (!limit.unit().empty() && limit.unit().find(";") == string::npos)
  {
    //LIMIT doesn't convert value if unit() is "uA",
    //need to convert it here.
    double factor_LimitUnitToA = SI_Value::getDiffValue(limit.unit(), "A");
    lowVal *= factor_LimitUnitToA;
    highVal *= factor_LimitUnitToA;
  }
  /*get DPS pin types*/
  map<string, string> dpsTypeMap;
  parseDpsPinType(dpsPins,dpsTypeMap);

  /*get DPS pin channel number and how many pins are ganged*/
  map<string, map <bool, INT> > dpsPinMapInfo;
  map<string, map <bool, INT> >::iterator iterMap;
  map <bool, INT> ::iterator iter;
  getDpsPinInfo(dpsPins,dpsPinMapInfo);

  /*judge measurement mode by classifying DPS pin type */
  for (iterMap = dpsPinMapInfo.begin(); iterMap != dpsPinMapInfo.end();iterMap++)
  {
    for (iter = iterMap->second.begin(); iter != iterMap->second.end();iter++)
    {
      double gangedValueLimit;
      double gangedValueLimitforUHC4;
      /*DPS32*/
      if ((dpsTypeMap[iterMap->first]) == "DPS32")
      {
        getGangedLimitOfDPSPins("DPS32", limit, gangedValueLimit,gangedValueLimitforUHC4);
        if ((iter->first) == true)
        {
          if (highVal <= gangedValueLimit)
          {
            dpsTask.pin(iterMap->first).measurementMode(TM::MEASURE_CURRENT_UNGANGED).min(lowVal).max(highVal);
            cerr<< "Warning:the DPS pins are unganged automatically since high value of Limits is less than 1.5A when using DPS32 measurement!!"<< endl;
          }
          else
          {
            dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
          }
        }
        else
        {
            dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
        }
      }
      /*DPS64*/
      if ((dpsTypeMap[iterMap->first]) == "DPS64")
      {
        getGangedLimitOfDPSPins("DPS64", limit, gangedValueLimit,gangedValueLimitforUHC4);
        if ((iter->first) == true)
        {
          if (highVal <= gangedValueLimit)
          {
            dpsTask.pin(iterMap->first).measurementMode(TM::MEASURE_CURRENT_UNGANGED).min(lowVal).max(highVal);
            cerr<< "Warning:the DPS pins are unganged automatically since high value of Limits is less than 1.0A when using DPS64 measurement!!"<< endl;
          }
          else
          {
            dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
          }
        }
        else
        {
            dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
        }
      }
      /*DPS128*/
      if ((dpsTypeMap[iterMap->first]) == "DPS128")
      {
        getGangedLimitOfDPSPins("DPS128", limit, gangedValueLimit,gangedValueLimitforUHC4);
        if ((iter->first) == true)
        {
          if (highVal <= gangedValueLimit)
          {
            dpsTask.pin(iterMap->first).measurementMode(TM::MEASURE_CURRENT_UNGANGED).min(lowVal).max(highVal);
            cerr<< "Warning:the DPS pins are unganged automatically since high value of Limits is less than 1.0A when using DPS128 measurement!!"<< endl;
          }
          else
          {
            dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
          }
        }
        else
        {
            dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
        }
      }
      /*VI32*/
      else if ((dpsTypeMap[iterMap->first]) == "VI32")
      {
        getGangedLimitOfDPSPins("VI32", limit, gangedValueLimit,gangedValueLimitforUHC4);
        if ((iter->first) == true)
        {
          if (highVal <= gangedValueLimit)
          {
            dpsTask.pin(iterMap->first).measurementMode(TM::MEASURE_CURRENT_UNGANGED).min(lowVal).max(highVal);
            cerr<< "Warning:the DPS pins are unganged automatically since high value of Limits is less than 0.5A when using VI32 measurement!!"<< endl;
          }
          else
          {
            dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
          }
        }
        else
        {
          dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
        }
      }
      /*UHC4*/
      else if ((dpsTypeMap[iterMap->first]) == "UHC4")
      {
        map<string, float> UHC4PinIoutClampRangeMap;
        getGangedLimitOfDPSPins("UHC4", limit, gangedValueLimit,gangedValueLimitforUHC4);
        if ((iter->first) == true)
        {
          if (highVal <= gangedValueLimitforUHC4)
          {
            dpsTask.pin(iterMap->first).measurementMode(TM::MEASURE_CURRENT_UNGANGED).min(lowVal).max(highVal);
            cerr<< "Warning:the DPS pins are unganged automatically since high value of Limits is less than 1.5A when using UHC4 measurement!!"<< endl;
          }
          else if ((highVal > gangedValueLimitforUHC4)&& (highVal <= gangedValueLimit))
          {
            dpsTask.pin(iterMap->first).measurementMode(TM::MEASURE_CURRENT_UNGANGED).min(lowVal).max(highVal);
            cerr<< "Warning:the DPS pins are unganged automatically since high value of Limits is less than 40A when using UHC4 measurement!!"<< endl;
          }
          else
          {
            dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
          }
        }
        else
        {
          dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
        }
      }
      /*UHC4T*/
      else if ((dpsTypeMap[iterMap->first]) == "UHC4T")
      {
        map<string, float> UHC4PinIoutClampRangeMap;
        getGangedLimitOfDPSPins("UHC4T", limit, gangedValueLimit,gangedValueLimitforUHC4);
        if ((iter->first) == true)
        {
          if (highVal <= gangedValueLimitforUHC4)
          {
            dpsTask.pin(iterMap->first).measurementMode(TM::MEASURE_CURRENT_UNGANGED).min(lowVal).max(highVal);
            cerr<< "Warning:the DPS pins are unganged automatically since high value of Limits is less than 1.5A when using UHC4T measurement!!"<< endl;
          }
          else if ((highVal > gangedValueLimitforUHC4)&& (highVal <= gangedValueLimit))
          {
            dpsTask.pin(iterMap->first).measurementMode(TM::MEASURE_CURRENT_UNGANGED).min(lowVal).max(highVal);
            cerr<< "Warning:the DPS pins are unganged automatically since high value of Limits is less than 40A when using UHC4T measurement!!"<< endl;
          }
          else
          {
            dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
          }
        }
        else
        {
          dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
        }
      }
      /*other type of pin*/
      else
      {
        dpsTask.pin(iterMap->first).min(lowVal).max(highVal);
      }
    }
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: DpsUtil::getDpsPinInfo
 *
 * Purpose: get Info of dps pins
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 *    get Info of DPS pins, which includes all pin channel number, whether DPS pin is ganged and how many pins are ganged
 *----------------------------------------------------------------------*
 */
inline void DpsUtil::getDpsPinInfo(
               const STRING&          dpsPins,
               map<string, map<bool, INT> >& dpsPinMapInfo)
{
  string dpsPinsTrimed = CommonUtil::trim(dpsPins);
  vector<string>  expandedDpsPins = PinUtility.getDpsPinNamesFromPinList(dpsPinsTrimed,TRUE);
  bool isGangedPin;

  string::size_type i_begin, i_end, pos = 0;
  for(vector<string>::iterator it = expandedDpsPins.begin();it != expandedDpsPins.end();it++)
  {
    ostringstream executeOs;
    string dpsPinUsed;
    executeOs << "DFPS?" << "(" << (*it) << ")";
    FW_TASK(executeOs.str(), dpsPinUsed);

    INT dpsPinsNum = 1;
    i_begin = dpsPinUsed.find("DFPS", pos);
    i_end = dpsPinUsed.find("POS", pos);
    /*parse all pin channel number*/
    string dpsChNum;
    dpsChNum = dpsPinUsed.substr(i_begin + 5, i_end - i_begin - 6);

    /*judge whether DPS pin is ganged and how many pins are ganged*/
    if ((dpsChNum.find("(")!= string::npos) && (dpsChNum.find(")")!= string::npos))
    {
      isGangedPin = true;
      for (string::size_type i = 0; i < dpsChNum.length(); i++)
      {
        if (dpsChNum[i] == ',')
        {
          dpsPinsNum = dpsPinsNum + 1;
        }
      }
    }
    else
    {
      isGangedPin = false;
    }
    /*save data to map container*/
    map<bool, INT> GangedPinNumMap;
    GangedPinNumMap.insert(make_pair(isGangedPin, dpsPinsNum));
    dpsPinMapInfo[(*it)] = GangedPinNumMap;
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: DpsUtil::parseDpsPinType
 *
 * Purpose: parse pin type of DPS
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 *
 *----------------------------------------------------------------------*
 */
inline void DpsUtil::parseDpsPinType(
               const STRING&          dpsPins,
               map<string, string>&   dpsPinTypeMap)
{
  string dpsPinsTrimed = CommonUtil::trim(dpsPins);
  string::size_type i_begin, i_end, pos = 0;
  vector<string>  expandedDpsPins = PinUtility.getDpsPinNamesFromPinList(dpsPinsTrimed,TRUE);
  vector<string>  expandedDpsChNum;
  map<string, string> dpsPinChannelMap;
  map<string, string>::iterator itMap;

  for(vector<string>::iterator it = expandedDpsPins.begin();it != expandedDpsPins.end();it++)
  {
    ostringstream executeOs;
    string  dpsPinUsed;
    executeOs << "DFPS?"<<"("<<(*it)<<")";
    FW_TASK(executeOs.str(), dpsPinUsed);
   
    i_begin   =  dpsPinUsed.find_first_of("DFPS",pos);
    i_end     =  dpsPinUsed.find_first_of(",",pos);
    /*parse pin channel number according to pin name*/
    string dpsChNum;
    dpsChNum = dpsPinUsed.substr(i_begin + 5, i_end - i_begin - 5);

    if (dpsChNum.find("(")!= string::npos)
    {
      dpsChNum = dpsChNum.substr(1);
    }

    expandedDpsChNum.push_back(dpsChNum);
    dpsPinChannelMap[(*it)] = dpsChNum;

  }
  /*parse pin type according to pin channel number*/
  for( itMap = dpsPinChannelMap.begin();itMap != dpsPinChannelMap.end();itMap++)
  {
    size_t posMap = 0, prePosMap, postPosMap;
    ostringstream executeOsPin;
    string  allPinInfo;
    executeOsPin << "CHIN?"<<itMap->second;
    FW_TASK(executeOsPin.str(), allPinInfo);
  
    if ((posMap = allPinInfo.find(itMap->second)) != string::npos)
    {
      prePosMap = allPinInfo.find(",",posMap);
      postPosMap = allPinInfo.find(",",prePosMap + 1 );
      /*save data to map container*/
      dpsPinTypeMap[itMap->first] = allPinInfo.substr(prePosMap + 1, postPosMap - prePosMap -1);
    }
  }

  return;
}


#endif
