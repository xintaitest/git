#include "testmethod.hpp"

//for test method API interfaces
#include "mapi.hpp"
#include "d2s/d2sFramework.h"
#include "d2s/d2s_MDIO.h"
#include "Public.h"
#include "WorkStation_2_Servers.h"
//#include "/opt/hp93000/soc/pws/lib/tpi_c.h"
//#include "/opt/hp93000/soc/prod_com/include/libcicpi.h"

using namespace std;
using namespace V93kLimits;

int calculate_clock_freq(string clock_cap_vari, string pin_name, double& clock_freq, double except_freq, int X_mode);

double ISOSCELES_ESTIMATION (ARRAY_I& CLK_OUTPUT, string& PIN)
{
    ARRAY_D SPECTRUM_Result;
    int     min_index, max_index;
    int		is_debug_analog;
    double  min_level, max_level;
//    double	b1, b2, m, f;
    double f;

	GET_TESTFLOW_FLAG("debug_analog",&is_debug_analog);

    DSP_SPECTRUM(CLK_OUTPUT, SPECTRUM_Result, PWR, 1.0, HANNING, 0);
    for(int i=0; i<20; i++)
    {
        SPECTRUM_Result[i] = 0;
    }


	if(is_debug_analog)
	{
		PUT_DEBUG(PIN, "array_pll_clock", CLK_OUTPUT);
		PUT_DEBUG(PIN, "spectrum_HANNING", SPECTRUM_Result);
	}

    DSP_MINMAX(SPECTRUM_Result, &min_level, &max_level, &min_index, &max_index);
    //max_index=2000;

	f = max_index;

	if(debug) cout<<"Fmax bin = "<<f<<endl;

//    if (max_index%8191 >0)
//	{
//    	INT x1; DOUBLE y1;
//    	INT x2; DOUBLE y2;
//    	INT x3; DOUBLE y3;
//
//    	if (SPECTRUM_Result[max_index+1] > SPECTRUM_Result[max_index-1])
//    	{
//    		x1 = max_index;
//    		y1 = max_level;
//    		x2 = max_index - 1;
//    		y2 = SPECTRUM_Result[max_index-1];
//    		x3 = max_index + 1;
//    		y3 = SPECTRUM_Result[max_index+1];
//    	}
//    	else
//    	{
//    		x1 = max_index;
//    		y1 = max_level;
//    		x2 = max_index + 1;
//    		y2 = SPECTRUM_Result[max_index+1];
//    		x3 = max_index - 1;
//    		y3 = SPECTRUM_Result[max_index-1];
//    	}
//
//
//    // y =  mx + b1 on where (x1, y1) and (x2, y2) are
//    // y = -mx + b2 on where (x3, y3) is
//    // To solve x for estimating the real fundamental frequency.
//
//    	m  = (y1 - y2) / (x1 - x2);
//    	b1 = y1 - m*x1;
//    	b2 = y3 + m*x3;
//    	f  = (b2 - b1) / (2*m);
//    }
//    else
//    {
//    	f = max_index;
//    }

    return f;
}

int calculate_clock_freq(string clock_cap_vari, string pin_name, double& clock_freq, double except_freq, int X_mode)
{
	char TASK[256];
	char temp[256];
	double test_period;
	double Fsmpl;
	double PLL_bin;
//	double aliasing_factor;
	string FW_ANSWER;
	ARRAY_I array_pll_clock;
	ARRAY_I array_bit;

	//get the test period of primary timing set by pclk
	sprintf(TASK,"PCLK? PRM,PRM,(%s),EXACT;",pin_name.c_str());
	FW_TASK(TASK, FW_ANSWER);
	strcpy(temp,FW_ANSWER.c_str());
	strtok(temp,",");strtok(0,",");
	test_period = atof(strtok(0,","));
	Fsmpl = 1000*1/test_period*1e6;

	array_pll_clock = VECTOR(clock_cap_vari).getVectors();

	array_bit.resize(array_pll_clock.size()*X_mode);

	for(int i=0; i<array_pll_clock.size(); i++)
	{
		for(int j=0; j<X_mode; j++)
		{
			array_bit[i*X_mode + j] = array_pll_clock[i]>>j && 0x1;
		}
	}

	PLL_bin = ISOSCELES_ESTIMATION(array_pll_clock, pin_name);

	clock_freq = PLL_bin/(double)array_pll_clock.size()*Fsmpl*X_mode;

	if(debug) cout<<"clock_freq = "<<clock_freq<<endl;

//	aliasing_factor = (INT) (except_freq / Fsmpl);
//
//    if ((except_freq - aliasing_factor * Fsmpl) > 0.5*Fsmpl)
//    {
//    	clock_freq = (1 - PLL_bin / array_pll_clock.size() + aliasing_factor) * Fsmpl;
//    }
//    else
//    {
//    	clock_freq = (PLL_bin / array_pll_clock.size() + aliasing_factor) * Fsmpl;
//    }

	return 0;
}


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Functional_Test: public testmethod::TestMethod {

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	static string suitName,testName;
	GET_TESTSUITE_NAME(suitName);

//	Primary.label("flash0_rd_array_ff");

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		FUNCTIONAL_TEST();
		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	testName = suitName;
	Boolean result = GET_FUNCTIONAL_RESULT();

	TESTSET().cont(true).judgeAndLog_ParametricTest(testName,testName,tmLimits,result);

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Functional_Test", Functional_Test_Functional_Test);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Functional_Test_Update: public testmethod::TestMethod {

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.

	Primary.label("flash_chip_erase_update");
	ON_FIRST_INVOCATION_BEGIN();
		FOR_EACH_SITE_BEGIN();
			Flash_Chip_Erase_Upload("flash_chip_erase_update", 1);
		FOR_EACH_SITE_END();
		CONNECT();
		FUNCTIONAL_TEST();
		FOR_EACH_SITE_BEGIN();
			Flash_Chip_Erase_Upload("flash_chip_erase_update", 0);
		FOR_EACH_SITE_END();
	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Functional_Test_Update", Functional_Test_Functional_Test_Update);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_MDIO_read: public testmethod::TestMethod {

protected:
	int address;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("address",
	             "int",
	             &address,
	             testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
	GET_TESTSUITE_NAME(suitName);

	d2sFramework fr;
	d2s_MDIO& MDIO = d2s_MDIO::Instance();
	fr.registerTransactionPort(MDIO);

	//Multi site handling and d2s-block
    ON_FIRST_INVOCATION_BEGIN();
    	fr.d2s_LABEL_BEGIN(suitName, (d2sFrameWorkModeType::Enum) d2sFrameworkMode);
		//EngineeringMode = 0, LearningMode = 1, ProductionMode = 2, DefaultMode = 3
		MDIO.read(0x55aa,"0x55aa");
		MDIO.read(0xaa55,"0x55aa");

		fr.d2s_LABEL_END();
	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.MDIO_read", Functional_Test_MDIO_read);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Flash_write: public testmethod::TestMethod {

protected:
	int NVR_true;
	int addr;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	addParameter("NVR_true",
		         "int",
		         &NVR_true,
		         testmethod::TM_PARAMETER_INPUT);
	addParameter("addr",
		         "int",
		         &addr,
		         testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
	int data[256];
	static int flash_num = 0;
	isNVR = NVR_true;

	for(int i=0; i<256; i++)
	{
		data[i] = i;
//		cout<<"data["<<i<<"] = "<<data[i]<<endl;
	}

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		write_flash(flash_num, addr, data, NVR_true);
		WAIT_TIME(0.1 ms);

	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Flash_write", Functional_Test_Flash_write);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Flash_read: public testmethod::TestMethod {

protected:
	int NVR_true;
	int addr;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	addParameter("NVR_true",
		         "int",
		         &NVR_true,
		         testmethod::TM_PARAMETER_INPUT);
	addParameter("addr",
		         "int",
		         &addr,
		         testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
	int data[256];
	static int flash_num = 0;
	isNVR = NVR_true;

//	addr = 0x0000;
	for(int i=0; i<256; i++)
	{
		data[i] = 0;
//		cout<<"data["<<i<<"] = "<<data[i]<<endl;
	}

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		read_flash(flash_num, addr, data, NVR_true);
		WAIT_TIME(0.1 ms);

	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Flash_read", Functional_Test_Flash_read);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Flash_Chip_erase: public testmethod::TestMethod {

protected:
	int NVR_true;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	addParameter("NVR_true",
		         "int",
		         &NVR_true,
		         testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
//	int ce_oe_we;
//	int contrl;
//	int addr;
//	int data[256];
	static int flash_num = 0;
	isNVR = NVR_true;

//	ce_oe_we = 0x3;
//	contrl = 0x155;
//	addr = 0x55aa;
//	for(int i=0; i<256; i++)
//	{
//		data[i] = i;
////		cout<<"data["<<i<<"] = "<<data[i]<<endl;
//	}

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		flash_chip_erase(flash_num);
		WAIT_TIME(0.1 ms);

	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Flash_Chip_erase", Functional_Test_Flash_Chip_erase);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Flash_sector_erase: public testmethod::TestMethod {

protected:
	int NVR_true;
	int addr;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	addParameter("NVR_true",
		         "int",
		         &NVR_true,
		         testmethod::TM_PARAMETER_INPUT);
	addParameter("addr",
		         "int",
		         &addr,
		         testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
//	int ce_oe_we;
//	int contrl;
//	int data[256];
	static int flash_num = 0;
//	isNVR = NVR_true;

//	ce_oe_we = 0x3;
//	contrl = 0x155;
//	for(int i=0; i<256; i++)
//	{
//		data[i] = i;
////		cout<<"data["<<i<<"] = "<<data[i]<<endl;
//	}

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		flash_sector_erase(flash_num, addr, NVR_true);
		WAIT_TIME(0.1 ms);

	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Flash_sector_erase", Functional_Test_Flash_sector_erase);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_OTP_write: public testmethod::TestMethod {

protected:
int NVR_true;
int addr;
int data_low;
int data_high;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	addParameter("NVR_true",
		         "int",
		         &NVR_true,
		         testmethod::TM_PARAMETER_INPUT);
	addParameter("addr",
		         "int",
		         &addr,
		         testmethod::TM_PARAMETER_INPUT);
	addParameter("data_low",
		         "int",
		         &data_low,
		         testmethod::TM_PARAMETER_INPUT);
	addParameter("data_high",
		         "int",
		         &data_high,
		         testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
	unsigned int data;

	data = data_low + (data_high<<16);
	isNVR = NVR_true;

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		write_OTP(addr, data);
		WAIT_TIME(0.1 ms);

	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.OTP_write", Functional_Test_OTP_write);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_OTP_read: public testmethod::TestMethod {

protected:
int NVR_true;
int addr;
int data_low;
int data_high;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	addParameter("NVR_true",
		         "int",
		         &NVR_true,
		         testmethod::TM_PARAMETER_INPUT);
	addParameter("addr",
		         "int",
		         &addr,
		         testmethod::TM_PARAMETER_INPUT);
	addParameter("data_low",
		         "int",
		         &data_low,
		         testmethod::TM_PARAMETER_INPUT);
	addParameter("data_high",
		         "int",
		         &data_high,
		         testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
	unsigned int data;

	data = data_low + (data_high<<16);
	isNVR = NVR_true;

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		read_OTP(addr, data);
		WAIT_TIME(0.1 ms);

	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.OTP_read", Functional_Test_OTP_read);

/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_OTP_sector_erase: public testmethod::TestMethod {

protected:
int NVR_true;
int addr;

  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	addParameter("NVR_true",
		         "int",
		         &NVR_true,
		         testmethod::TM_PARAMETER_INPUT);
	addParameter("addr",
		         "int",
		         &addr,
		         testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;

	isNVR = NVR_true;
	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		OTP_sector_erase(addr, NVR_true);
		WAIT_TIME(0.1 ms);

	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.OTP_sector_erase", Functional_Test_OTP_sector_erase);

/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Get_Encrypt_Key_data: public testmethod::TestMethod {

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName,testName;
	static int clifd;
	static int get_key_error;
	unsigned char Encrypt_Key_data[FT_site][buffer_byte];

	get_key_error = 0;
	GET_TESTSUITE_NAME(suitName);
	for(int i=0; i<FT_site; i++)
	{
		memset(error_code_hex[i],0xff,error_code_byte);
		memset(CHIP_ID_hex[i],0xff,chip_ID_byte);
		memset(OTP_hex[i],0x00,OTP_byte-8);
		memset(Flash_hex[i],0xff,Flash_byte);
		memset(Encrypt_Key_data[i],0,buffer_byte);
	}

	ON_FIRST_INVOCATION_BEGIN();
		if(!client_servers(clifd))
		{
			cout<<"client encrypt key servers failed"<<endl;
			get_key_error = 1;
		}

		FOR_EACH_SITE_BEGIN();
			if(!device_key_request(clifd, Encrypt_Key_data[CURRENT_SITE_NUMBER()-1]))
			{
				cout<<"get encryt key for site:"<<CURRENT_SITE_NUMBER()<<" failed"<<endl;
				get_key_error = 2;
				close(clifd);

//				for(int i=0; i<buffer_byte; i++)
//				{
//					Encrypt_Key_data[CURRENT_SITE_NUMBER()-1][i] = 0xff;
//				}
			}
			else
			{
				memcpy(error_code_hex[CURRENT_SITE_NUMBER()-1],Encrypt_Key_data[CURRENT_SITE_NUMBER()-1],error_code_byte);
				memcpy(CHIP_ID_hex[CURRENT_SITE_NUMBER()-1],Encrypt_Key_data[CURRENT_SITE_NUMBER()-1]+error_code_byte,chip_ID_byte);
				memcpy(OTP_hex[CURRENT_SITE_NUMBER()-1],Encrypt_Key_data[CURRENT_SITE_NUMBER()-1]+error_code_byte+chip_ID_byte,OTP_byte-8);
				memcpy(Flash_hex[CURRENT_SITE_NUMBER()-1],Encrypt_Key_data[CURRENT_SITE_NUMBER()-1]+error_code_byte+chip_ID_byte+OTP_byte-8,Flash_byte);
			}

		FOR_EACH_SITE_END();
		close(clifd);
	ON_FIRST_INVOCATION_END();

	if(error_code_hex[CURRENT_SITE_NUMBER()-1] != '\0')
	{
		get_key_error = 3;
	}

	testName = suitName;
	TESTSET().cont(true).judgeAndLog_ParametricTest(suitName,testName,tmLimits,get_key_error);

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Get_Encrypt_Key_data", Functional_Test_Get_Encrypt_Key_data);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Dynamic_FLASH_write: public testmethod::TestMethod {

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
	static int input_length = 4096;
	static int output_length = 4608;
//	unsigned char data_with_ecc[FT_site][output_length];
//	unsigned char data_char[output_length];

	string vector_name = "flash_key_data_program";
//	for(int i=0; i<input_length; i++)
//	{
//		memset(data_char+i,i%0x100,1);
//	}

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		FOR_EACH_SITE_BEGIN();
			insert_ecc_to_data(Flash_hex[CURRENT_SITE_NUMBER()-1], input_length, Flash_ecc_hex[CURRENT_SITE_NUMBER()-1], output_length);
//			insert_ecc_to_data(data_char, input_length, Flash_ecc_hex[CURRENT_SITE_NUMBER()-1], output_length);
			Flash_write_encrypt_key(Flash_ecc_hex[CURRENT_SITE_NUMBER()-1], vector_name);
		FOR_EACH_SITE_END();
		WAIT_TIME(0.1 ms);
		FUNCTIONAL_TEST();
	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Dynamic_FLASH_write", Functional_Test_Dynamic_FLASH_write);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Dynamic_FLASH_read: public testmethod::TestMethod {

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName, testName;
//	static int input_length = 4096;
//	static int output_length = 4608;

	string vector_name = "flash_key_data_read";
//	for(int i=0; i<input_length; i++)
//	{
//		memset(data_char+i,i%0x100,1);
//	}
	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		FOR_EACH_SITE_BEGIN();
			Flash_read_encrypt_key(Flash_ecc_hex[CURRENT_SITE_NUMBER()-1], vector_name);
		FOR_EACH_SITE_END();
		WAIT_TIME(0.1 ms);
		FUNCTIONAL_TEST();
	ON_FIRST_INVOCATION_END();

	testName = suitName;
	Boolean result = GET_FUNCTIONAL_RESULT();

	TESTSET().cont(true).judgeAndLog_ParametricTest(suitName,testName,tmLimits,result);
//	TESTSET().cont(true).judgeAndLog_FunctionalTest(testName, tmLimits, result);

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Dynamic_FLASH_read", Functional_Test_Dynamic_FLASH_read);



/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Dynamic_OTP_write: public testmethod::TestMethod {

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
//	unsigned char data_char[1024];

	string vector_name = "otp_key_data_program";
//	for(int i=0; i<1024; i++)
//	{
//		memset(data_char+i,i%0x100,1);
//	}

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		FOR_EACH_SITE_BEGIN();
//			OTP_write_1K_data(OTP_hex[CURRENT_SITE_NUMBER()], vector_name);
//			OTP_write_1K_data(data_char, vector_name);
		FOR_EACH_SITE_END();
		WAIT_TIME(0.1 ms);
		FUNCTIONAL_TEST();
	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Dynamic_OTP_write", Functional_Test_Dynamic_OTP_write);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Dynamic_OTP_read: public testmethod::TestMethod {

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	static string suitName, testName;
	string vector_name = "otp_key_data_read";
//	unsigned char data_char[1024];
//	for(int i=0; i<1024; i++)
//	{
//		memset(data_char+i,0x00,1);
//	}

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		FOR_EACH_SITE_BEGIN();
//			OTP_read_1K_data(OTP_hex[CURRENT_SITE_NUMBER()], vector_name);
//			OTP_read_1K_data(data_char, vector_name);
		FOR_EACH_SITE_END();
		WAIT_TIME(0.1 ms);
		FUNCTIONAL_TEST();
	ON_FIRST_INVOCATION_END();

	testName = suitName;
	Boolean result = GET_FUNCTIONAL_RESULT();
	TESTSET().cont(true).judgeAndLog_ParametricTest(suitName,testName,tmLimits,result);

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Dynamic_OTP_read", Functional_Test_Dynamic_OTP_read);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Temp_Sensor_Trim: public testmethod::TestMethod {
protected:
string  trim_high_low;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	addParameter("trim_high_low",
		         "string",
		         &trim_high_low,
		         testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
	string label_name, cap_vari;
	ARRAY_I adWave;
	int TS_cap_low, TS_cap_high;

	GET_TESTSUITE_NAME(suitName);

	label_name = "TS_trimming";
	cap_vari = "TS_trimming_cap";

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		WAIT_TIME(0.1 ms);
		Primary.label(label_name);
		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();

	adWave = VECTOR(cap_vari).getVectors();

	if(trim_high_low == "low")
	{
		TS_cap_low = 0;
		for(int i=0; i<16; i++)
		{
			TS_cap_low += (adWave[i]&0x1);
			if(debug) cout<<"adWave["<<i<<"]="<<adWave[i]<<endl;
		}

		if(TS_cap_low>=1 && TS_cap_low<0xf)
		{
			temp_low_trim[CURRENT_SITE_NUMBER()-1] = TS_cap_low;
//			temp_low_trim[CURRENT_SITE_NUMBER()-1] = 0x6;
		}
		else
		{
			temp_low_trim[CURRENT_SITE_NUMBER()-1] = 0x0;
//			temp_low_trim[CURRENT_SITE_NUMBER()-1] = 0x6;
		}
		TESTSET().cont(true).judgeAndLog_ParametricTest(suitName,suitName,tmLimits,temp_low_trim[CURRENT_SITE_NUMBER()-1]);
	}
	else if(trim_high_low == "high")
	{
		TS_cap_high = 0;
		for(int i=0; i<16; i++)
		{
			TS_cap_high += ((adWave[i]&0x2)>>1);
			if(debug) cout<<"adWave["<<i<<"]="<<adWave[i]<<endl;
		}
		if(TS_cap_high>=1 && TS_cap_high<0xf)
		{
			temp_high_trim[CURRENT_SITE_NUMBER()-1] = 0xf - TS_cap_high;
		}
		else
		{
			temp_high_trim[CURRENT_SITE_NUMBER()-1] = 0x0;
//			temp_high_trim[CURRENT_SITE_NUMBER()-1] = 0xc;
		}
		TESTSET().cont(true).judgeAndLog_ParametricTest(suitName,suitName,tmLimits,temp_high_trim[CURRENT_SITE_NUMBER()-1]);
	}

	if(debug)
	{
		hex(cout);
		cout<<"temp_low_trim["<<CURRENT_SITE_NUMBER()-1<<"] = 0x"<<temp_low_trim[CURRENT_SITE_NUMBER()-1]<<endl;
		cout<<"temp_high_trim["<<CURRENT_SITE_NUMBER()-1<<"] = 0x"<<temp_high_trim[CURRENT_SITE_NUMBER()-1]<<endl;
	}

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Temp_Sensor_Trim", Functional_Test_Temp_Sensor_Trim);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_OSC_Trim: public testmethod::TestMethod {
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	static string suitName, testName;
	string label_name;
	string osc_cap_vari = "osc_cap";
	string osc_pin_name = "UART0_TX";
	ARRAY_I Array_Lock;
	label_name = "osc_pattern_avc";
	static int X_mode = 8;
	int OSC_trim_started;
	double osc_clock_freq;
	static double osc_except_freq = 20.27*1e6;
	static double clk_step = 54*1e3;
	static int osc_code_gap[CP_site] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	static int target_osc_code[CP_site] = {0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220};

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		testName = suitName;
		CONNECT();
		WAIT_TIME(1 ms);
		FOR_EACH_SITE_BEGIN();
			GET_USER_FLAG("OSC_trim_started",&OSC_trim_started);
			if(!OSC_trim_started)
			{
				target_osc_code[CURRENT_SITE_NUMBER()-1] = 0x220;
				SET_USER_FLAG("OSC_trim_started",1);
			}
			OSC_trimming_reg_update(label_name,target_osc_code[CURRENT_SITE_NUMBER()-1]);
		FOR_EACH_SITE_END();

		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();

	calculate_clock_freq(osc_cap_vari, osc_pin_name, osc_clock_freq, osc_except_freq, X_mode);

	osc_code_gap[CURRENT_SITE_NUMBER()-1] = (int)((osc_except_freq - osc_clock_freq)/clk_step);
	target_osc_code[CURRENT_SITE_NUMBER()-1] = target_osc_code[CURRENT_SITE_NUMBER()-1] + osc_code_gap[CURRENT_SITE_NUMBER()-1];

	OSC_trim[CURRENT_SITE_NUMBER()-1] = target_osc_code[CURRENT_SITE_NUMBER()-1];

	dec(cout);
	if(debug) cout<<"freq gap["<<CURRENT_SITE_NUMBER()-1<<"] = "<<osc_except_freq - osc_clock_freq<<endl;
	if(debug) cout<<"osc_code_gap["<<CURRENT_SITE_NUMBER()-1<<"] = "<<osc_code_gap[CURRENT_SITE_NUMBER()-1]<<endl;

	TESTSET().cont(true).judgeAndLog_ParametricTest(suitName,testName,tmLimits,osc_code_gap[CURRENT_SITE_NUMBER()-1]);

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.OSC_Trim", Functional_Test_OSC_Trim);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_OSC_Trim_PLL_out: public testmethod::TestMethod {
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
	string label_name;
	string osc_cap_vari = "PLL_OSC_cap";
	string osc_pin_name = "UART0_RX";
	ARRAY_I Array_Lock;
	label_name = "PLL_OSC_pattern";
	static int X_mode = 8;
	int OSC_trim_started;
	double osc_clock_freq;
	static double osc_except_freq = 20.27*1e6;
	static double clk_step = 54*1e3;
	static int osc_code_gap[CP_site] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	static int target_osc_code[CP_site] = {0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220};

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		WAIT_TIME(1 ms);
		FOR_EACH_SITE_BEGIN();
			GET_USER_FLAG("OSC_trim_started",&OSC_trim_started);
			if(!OSC_trim_started)
			{
				target_osc_code[CURRENT_SITE_NUMBER()-1] = 0x220;
				SET_USER_FLAG("OSC_trim_started",1);
			}
			OSC_PLL_out_trimming_reg_update(label_name,target_osc_code[CURRENT_SITE_NUMBER()-1]);
		FOR_EACH_SITE_END();

		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();

	calculate_clock_freq(osc_cap_vari, osc_pin_name, osc_clock_freq, osc_except_freq, X_mode);

	osc_clock_freq = osc_clock_freq*4/3;

	if(debug) cout<<"osc clock frequency = "<<osc_clock_freq<<endl;

	osc_code_gap[CURRENT_SITE_NUMBER()-1] = (int)((osc_except_freq - osc_clock_freq)/clk_step);
	target_osc_code[CURRENT_SITE_NUMBER()-1] = target_osc_code[CURRENT_SITE_NUMBER()-1] + osc_code_gap[CURRENT_SITE_NUMBER()-1];

	OSC_trim[CURRENT_SITE_NUMBER()-1] = target_osc_code[CURRENT_SITE_NUMBER()-1];

	dec(cout);
	if(debug) cout<<"freq gap["<<CURRENT_SITE_NUMBER()-1<<"] = "<<osc_except_freq - osc_clock_freq<<endl;
	if(debug) cout<<"osc_code_gap["<<CURRENT_SITE_NUMBER()-1<<"] = "<<osc_code_gap[CURRENT_SITE_NUMBER()-1]<<endl;

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.OSC_Trim_PLL_out", Functional_Test_OSC_Trim_PLL_out);

/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_OSC_Trim_FUN_Mode: public testmethod::TestMethod {
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
	string label_name;
	string osc_cap_vari = "osc_fun_cap";
	string osc_pin_name = "I2C0_SDA";
	ARRAY_I Array_Lock;
	label_name = "osc_pattern_fun";
	static int X_mode = 8;
//	int OSC_trim_started;
	double osc_clock_freq;
	static double osc_except_freq = 20.27*1e6;
	static double clk_step = 54*1e3;
	static int osc_code_gap[CP_site] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	static int target_osc_code[CP_site] = {0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220,0x220};

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		WAIT_TIME(1 ms);
//		FOR_EACH_SITE_BEGIN();
//			GET_USER_FLAG("OSC_trim_started",&OSC_trim_started);
//			if(!OSC_trim_started)
//			{
//				target_osc_code[CURRENT_SITE_NUMBER()-1] = 0x220;
//				SET_USER_FLAG("OSC_trim_started",1);
//			}
//			OSC_trimming_reg_update(label_name,target_osc_code[CURRENT_SITE_NUMBER()-1]);
//		FOR_EACH_SITE_END();

		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();

	calculate_clock_freq(osc_cap_vari, osc_pin_name, osc_clock_freq, osc_except_freq, X_mode);

	osc_code_gap[CURRENT_SITE_NUMBER()-1] = (int)((osc_except_freq - osc_clock_freq)/clk_step);
	target_osc_code[CURRENT_SITE_NUMBER()-1] = target_osc_code[CURRENT_SITE_NUMBER()-1] + osc_code_gap[CURRENT_SITE_NUMBER()-1];

	OSC_trim[CURRENT_SITE_NUMBER()-1] = target_osc_code[CURRENT_SITE_NUMBER()-1];

	dec(cout);
	if(debug) cout<<"freq gap["<<CURRENT_SITE_NUMBER()-1<<"] = "<<osc_except_freq - osc_clock_freq<<endl;
	if(debug) cout<<"osc_code_gap["<<CURRENT_SITE_NUMBER()-1<<"] = "<<osc_code_gap[CURRENT_SITE_NUMBER()-1]<<endl;

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.OSC_Trim_FUN_Mode", Functional_Test_OSC_Trim_FUN_Mode);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Voltage_Sensor_Trim: public testmethod::TestMethod {
protected:
string  trim_high_low;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	addParameter("trim_high_low",
		         "string",
		         &trim_high_low,
		         testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
	string label_name, cap_vari;
	ARRAY_I adWave;
	int VDD18_High, VDD18_Low, VDD33_High, VDD33_Low;
	int VDD33_High_trim_code, VDD33_Low_trim_code;
	int VDD18_High_trim_code, VDD18_Low_trim_code;
	int VDD18_low_trim_fail[trim_site];
	int VDD18_high_trim_fail[trim_site];
	int VDD33_low_trim_fail[trim_site];
	int VDD33_high_trim_fail[trim_site];

	GET_TESTSUITE_NAME(suitName);

	label_name = "VDD_trimming";
	cap_vari = "VDD_trimming_cap";

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		WAIT_TIME(0.1 ms);
		Primary.label(label_name);
		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();

	adWave = VECTOR(cap_vari).getVectors();

	VDD18_High=0; VDD18_Low=0; VDD33_High=0; VDD33_Low=0;
	for(int i=0; i<8; i++)
	{
		VDD18_Low += ((adWave[i]&0x1)<<i);
		VDD18_High += ((adWave[i]&0x2)>>1)<<i;
		VDD33_Low += ((adWave[i]&0x4)>>2)<<i;
		VDD33_High += ((adWave[i]&0x8)>>3)<<i;

		if(debug) cout<<"adWave["<<i<<"]="<<adWave[i]<<endl;
	}

	if(debug)
	{
		hex(cout);
		cout<<"VDD18_Low = 0x"<<VDD18_Low<<endl;
		cout<<"VDD18_High = 0x"<<VDD18_High<<endl;
		cout<<"VDD33_Low = 0x"<<VDD33_Low<<endl;
		cout<<"VDD33_High = 0x"<<VDD33_High<<endl;
	}

	if(trim_high_low == "low")
	{
		VDD18_Low_trim_code = VDD18_Low+1;
		VDD33_Low_trim_code = VDD33_Low+1;
		if(VDD18_Low>=0x1 && VDD18_Low<=0x7f && is_one_hot_code(VDD18_Low_trim_code, 8))
		{

			VDD18_low_trim[CURRENT_SITE_NUMBER()-1] = VDD18_Low_trim_code;
			VDD18_low_trim_fail[CURRENT_SITE_NUMBER()-1] = 0;
		}
		else
		{
			VDD18_low_trim[CURRENT_SITE_NUMBER()-1] = 0xff;
			VDD18_low_trim_fail[CURRENT_SITE_NUMBER()-1] = 1;
		}
		if(VDD33_Low>=0x1 && VDD33_Low<=0x7f && is_one_hot_code(VDD33_Low_trim_code, 8))
		{
			VDD33_low_trim[CURRENT_SITE_NUMBER()-1] = VDD33_Low_trim_code;
			VDD33_low_trim_fail[CURRENT_SITE_NUMBER()-1] = 0;
		}
		else
		{
			VDD33_low_trim[CURRENT_SITE_NUMBER()-1] = 0xff;
			VDD33_low_trim_fail[CURRENT_SITE_NUMBER()-1] = 1;
		}

		TESTSET().cont(true).judgeAndLog_ParametricTest("VDD33",suitName,tmLimits,VDD33_low_trim_fail[CURRENT_SITE_NUMBER()-1]);
		TESTSET().cont(true).judgeAndLog_ParametricTest("VDD18",suitName,tmLimits,VDD18_low_trim_fail[CURRENT_SITE_NUMBER()-1]);
	}
	else if(trim_high_low == "high")
	{
		VDD18_High_trim_code = ((VDD18_High^0xff)>>1)+1;
		VDD33_High_trim_code = ((VDD33_High^0xff)>>1)+1;
		cout<<"VDD33_High_trim_code = 0x"<<VDD33_High_trim_code<<endl;
		if(VDD18_High>=0x80 && VDD18_High<=0xfe && is_one_hot_code(VDD18_High_trim_code, 8))
		{
			VDD18_high_trim[CURRENT_SITE_NUMBER()-1] = VDD18_High_trim_code;
			VDD18_high_trim_fail[CURRENT_SITE_NUMBER()-1] = 0;
		}
		else
		{
			VDD18_high_trim[CURRENT_SITE_NUMBER()-1] = 0xff;
			VDD18_high_trim_fail[CURRENT_SITE_NUMBER()-1] = 1;
		}
		if(VDD33_High>=0x80 && VDD33_High<=0xfe && is_one_hot_code(VDD33_High_trim_code, 8))
		{
			VDD33_high_trim[CURRENT_SITE_NUMBER()-1] = VDD33_High_trim_code;
			VDD33_high_trim_fail[CURRENT_SITE_NUMBER()-1] = 0;
		}
		else
		{
			VDD33_high_trim[CURRENT_SITE_NUMBER()-1] = 0xff;
			VDD33_high_trim_fail[CURRENT_SITE_NUMBER()-1] = 1;
		}

		TESTSET().cont(true).judgeAndLog_ParametricTest("VDD33",suitName,tmLimits,VDD33_high_trim_fail[CURRENT_SITE_NUMBER()-1]);
		TESTSET().cont(true).judgeAndLog_ParametricTest("VDD18",suitName,tmLimits,VDD18_high_trim_fail[CURRENT_SITE_NUMBER()-1]);
	}

	if(debug)
	{
		cout<<"VDD18_low_trim["<<CURRENT_SITE_NUMBER()-1<<"] = 0x"<<VDD18_low_trim[CURRENT_SITE_NUMBER()-1]<<endl;
		cout<<"VDD18_high_trim["<<CURRENT_SITE_NUMBER()-1<<"] = 0x"<<VDD18_high_trim[CURRENT_SITE_NUMBER()-1]<<endl;
		cout<<"VDD33_low_trim["<<CURRENT_SITE_NUMBER()-1<<"] = 0x"<<VDD33_low_trim[CURRENT_SITE_NUMBER()-1]<<endl;
		cout<<"VDD33_high_trim["<<CURRENT_SITE_NUMBER()-1<<"] = 0x"<<VDD33_high_trim[CURRENT_SITE_NUMBER()-1]<<endl;
	}

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Voltage_Sensor_Trim", Functional_Test_Voltage_Sensor_Trim);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_PLL_Clock: public testmethod::TestMethod {
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	string suitName;
	string label_name;
	string pll_cap_vari = "PLL_OSC_cap";
	string pll_pin_name = "UART0_RX";
	ARRAY_I Array_Lock;
	label_name = "PLL_OSC_pattern";
	int lock_stage;
	static int X_mode = 8;
	double pll_clock_freq;
	static double pll_except_freq = 6*10e7;

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		WAIT_TIME(5 ms);
		Primary.label(label_name);
		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();

	calculate_clock_freq(pll_cap_vari, pll_pin_name, pll_clock_freq, pll_except_freq, X_mode);

	Array_Lock = VECTOR("pll_lock_stage").getVectors();
	lock_stage = Array_Lock[0];

	TESTSET().cont(true).judgeAndLog_ParametricTest(suitName,"lock_stage",tmLimits,lock_stage);
	TESTSET().cont(true).judgeAndLog_ParametricTest(suitName,"pll_clock_freq",tmLimits,pll_clock_freq/1e6);

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.PLL_Clock", Functional_Test_PLL_Clock);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_POR_rise_time: public testmethod::TestMethod {
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	static string suitName,testName;
	string label_name;
	string cap_var = "POR_cap";
	string pin_name = "POR_N";
	int POR_rise_time = 0;
	ARRAY_I POR_Array;
	label_name = "POR_rise_cap";
	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		DISCONNECT();
		WAIT_TIME(2 ms);
		Primary.label(label_name);
		CONNECT();
//		FW_TASK("PSST OFF, (VDD18);\n");
		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();

	POR_Array = VECTOR(cap_var).getVectors();
//	string ph_wafer_size = PROB_HND_CALL("ph_get_status wafer_size");
	for(int i=0; i<100; i++)
	{
		cout<<"POR_Array["<<i<<"] = "<<POR_Array[i]<<endl;
		if(POR_Array[i] == 1)
		{
			POR_rise_time = (i+1)*50;
			break;
		}
		if(i == 99 && POR_rise_time ==0)
		{
			POR_rise_time = 50000;
			cout<<"POR rise not found, POR function fail."<<endl;
		}
	}

	testName = suitName;
	TESTSET().cont(true).judgeAndLog_ParametricTest(suitName,testName,tmLimits,POR_rise_time);

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.POR_rise_time", Functional_Test_POR_rise_time);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */

class Functional_Test_write_cp2_flag: public testmethod::TestMethod {
protected:
	int version;

protected:
	/**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
	//Add your initialization code here
	//Note: Test Method API should not be used in this method!
	addParameter("version",
				 "int",
				 &version,
				 testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
    int site_index;
    int input_length=8;
    int output_length=9;

    string suitName, testName;
	string label_name = "write_CP2_Flag";

	GET_TESTSUITE_NAME(suitName);
	testName = suitName;

	ON_FIRST_INVOCATION_BEGIN();

	CONNECT();

	FOR_EACH_SITE_BEGIN();

    site_index=CURRENT_SITE_NUMBER()-1;
	versin_flag[site_index][0]=version&0xFF;
	versin_flag[site_index][1]=(version>>8)&0xFF;
	versin_flag[site_index][2]=0xFF;
	versin_flag[site_index][3]=0xFF;
	versin_flag[site_index][4]=0xFF;
	versin_flag[site_index][5]=0xFF;
	versin_flag[site_index][6]=0xFF;
	versin_flag[site_index][7]=0xFF;

    insert_ecc_to_data(versin_flag[site_index],input_length,versin_ecc_flag[site_index],output_length);
    Nvr1_write_version_flag(versin_ecc_flag[site_index],label_name);

	FOR_EACH_SITE_END();

	WAIT_TIME(0.1 ms);
	FUNCTIONAL_TEST();

	ON_FIRST_INVOCATION_END();

	Boolean result = GET_FUNCTIONAL_RESULT();
	TESTSET().cont(true).judgeAndLog_ParametricTest(suitName,testName,tmLimits,result);

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.write_cp2_flag", Functional_Test_write_cp2_flag);




class Functional_Test_FLASH_VNR2_read: public testmethod::TestMethod {
string label_name;
string cap_var;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("label_name",
				 "string",
				 &label_name,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("cap_var",
				 "string",
				 &cap_var,
				 testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
	}

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	static string suitName,testName;
	static int FLASH_BLOCK = 0;
	unsigned int my_data_L[32];
	unsigned int my_data_H[32];
	double result;
	unsigned int comp_4byte = 0xffffffff;
	unsigned int comp_2byte = 0xffff;

//	unsigned long long my_data[32];

	ARRAY_I adWave;
	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		Primary.label(label_name);
		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();

    adWave = VECTOR(cap_var).getVectors();

    for(int i=0; i<32; i++)
    {
    	my_data_L[i] = 0;
    	my_data_H[i] = 0;
    	for(int j=0; j<32; j++)
    	{
    		my_data_L[i] += (adWave[i*72+j]<<j);
    		my_data_H[i] += (adWave[i*72+32+j]<<j);
    	}
//    	my_data[i] = my_data_H[i]<<32 + my_data_L[i];
    	if(debug)
    	{
    		hex(cout);
    		cout<<"capture NVR1 data_L["<<setw(2)<<i<<"] = 0x"<<my_data_L[i]<<"		capture NVR1 data_H["<<setw(2)<<i<<"] = 0x"<<my_data_H[i]<<endl;
    	}
    }

    Trim_bit[CURRENT_SITE_NUMBER()-1][FLASH_BLOCK] = my_data_L[0]&0xff;
    if(debug) cout<<"Trim_bit site"<<CURRENT_SITE_NUMBER()<<" = "<<Trim_bit[CURRENT_SITE_NUMBER()-1][FLASH_BLOCK]<<endl;

    result = (double) (my_data_L[0x00]&comp_2byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"Trim_Bit",LIMIT(TM::Pass),result);

    result = (double) (my_data_L[0x10]&comp_2byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"CP1_Flag",tmLimits,result);

    result = (double) (my_data_L[0x11]&comp_2byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"CP2_Flag",tmLimits,result);

    result = (double) (my_data_L[0x1b]&comp_2byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"CP3_Flag",tmLimits,result);

    result = (double) (my_data_L[0x1e]&comp_2byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"Version_Flag",tmLimits,result);

//    result = (double) (my_data_L[0x1c]&comp_2byte);
//    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"FT1_Flag",tmLimits,result);
//
//    result = (double) (my_data_L[0x1d]&comp_2byte);
//    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"FT2_Flag",tmLimits,result);

    result = (double) (my_data_L[0x12]&comp_4byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"LOT_ID",LIMIT(TM::Pass),result);
    OTP_hex[CURRENT_SITE_NUMBER()-1][292] = my_data_L[0x12]&0xff;
    OTP_hex[CURRENT_SITE_NUMBER()-1][293] = (my_data_L[0x12]&0xff00)>>8;
    OTP_hex[CURRENT_SITE_NUMBER()-1][294] = (my_data_L[0x12]&0xff0000)>>16;
    OTP_hex[CURRENT_SITE_NUMBER()-1][295] = (my_data_L[0x12]&0xff000000)>>24;

    result = (double) (my_data_L[0x13]&0xff);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"WAFER_ID",LIMIT(TM::Pass),result);
    OTP_hex[CURRENT_SITE_NUMBER()-1][296] = my_data_L[0x13] & 0xff;

    result = (double) (my_data_L[0x14]&comp_2byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"X_Coordinate",LIMIT(TM::Pass),result);
    OTP_hex[CURRENT_SITE_NUMBER()-1][297] = my_data_L[0x14] & 0xff;

    result = (double) (my_data_L[0x15]&comp_2byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"Y_Coordinate",LIMIT(TM::Pass),result);
    OTP_hex[CURRENT_SITE_NUMBER()-1][298] = my_data_L[0x15] & 0xff;

    //4bit fab info:01-HG FAB3, 4bit testing assembly info:01 ASESH
    OTP_hex[CURRENT_SITE_NUMBER()-1][299] = 0x11;

    result = (double) (my_data_L[0x16]&comp_4byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"CP1_testtime",LIMIT(TM::Pass),result);

//    result = (double) (my_data[0x17]&comp_2byte);
//    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"Testing_house",LIMIT(TM::Pass),result);
//
//    result = (double) (my_data[0x18]&comp_2byte);
//    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"Tester_mode",LIMIT(TM::Pass),result);


    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.FLASH_VNR2_read", Functional_Test_FLASH_VNR2_read);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_FLASH_Redundancy_Read: public testmethod::TestMethod {
string label_name;
string cap_var;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("label_name",
				 "string",
				 &label_name,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("cap_var",
				 "string",
				 &cap_var,
				 testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
	}

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	static string suitName,testName;

//	double result;
//	unsigned int comp_4byte = 0xffffffff;
//	unsigned int comp_2byte = 0xffff;

//	unsigned long long my_data[32];

	ARRAY_I adWave;
	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		Primary.label(label_name);
		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();

    adWave = VECTOR(cap_var).getVectors();

    for(int i=0; i<8; i++)
    {
    	redundancy_info_L[CURRENT_SITE_NUMBER()-1][i] = 0;
    	redundancy_info_H[CURRENT_SITE_NUMBER()-1][i] = 0;
    	for(int j=0; j<32; j++)
    	{
    		redundancy_info_L[CURRENT_SITE_NUMBER()-1][i] += (adWave[i*72+j]<<j);
    		redundancy_info_H[CURRENT_SITE_NUMBER()-1][i] += (adWave[i*72+32+j]<<j);
    	}
//    	my_data[i] = my_data_H[i]<<32 + my_data_L[i];
    	if(debug)
    	{
    		hex(cout);
    		cout<<"Redundancy redundancy info H["<<CURRENT_SITE_NUMBER()-1<<"]["<<i<<"] = 0x"<<redundancy_info_H[CURRENT_SITE_NUMBER()-1][i]
    		    <<"; Redundancy redundancy info L["<<CURRENT_SITE_NUMBER()-1<<"]["<<i<<"] = 0x"<<redundancy_info_L[CURRENT_SITE_NUMBER()-1][i]<<endl;
    	}
    }

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.FLASH_Redundancy_Read", Functional_Test_FLASH_Redundancy_Read);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_FLASH_Redundancy_Write: public testmethod::TestMethod {
string label_name;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("label_name",
				 "string",
				 &label_name,
				 testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
	}

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	static string suitName,testName;
	static int input_length = 64;
	static int output_length = 72;

	unsigned char NVR_char[CP_site][512];
	unsigned char NVR_ecc_char[CP_site][512];

	ARRAY_I adWave;
	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		Primary.label(label_name);
		FOR_EACH_SITE_BEGIN();
			convert_NVR_data_to_char(NVR_char[CURRENT_SITE_NUMBER()-1]);
			insert_ecc_to_data(NVR_char[CURRENT_SITE_NUMBER()-1], input_length, NVR_ecc_char[CURRENT_SITE_NUMBER()-1], output_length);
			Flash_write_NVR2_redundancy(NVR_ecc_char[CURRENT_SITE_NUMBER()-1],label_name);
		FOR_EACH_SITE_END();
		FUNCTIONAL_TEST();
	ON_FIRST_INVOCATION_END();


    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.FLASH_Redundancy_Write", Functional_Test_FLASH_Redundancy_Write);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_OTP_VNR4_read: public testmethod::TestMethod {
string label_name;
string cap_var;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("label_name",
				 "string",
				 &label_name,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("cap_var",
				 "string",
				 &cap_var,
				 testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
	}

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	static string suitName,testName;
	unsigned int my_data[32];
	double result;
//	unsigned int comp_4byte = 0xffffffff;
	unsigned int comp_2byte = 0xffff;

//	unsigned long long my_data[32];

	ARRAY_I adWave;
	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		Primary.label(label_name);
		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();

    adWave = VECTOR(cap_var).getVectors();

    for(int i=0; i<32; i++)
    {
    	my_data[i] = 0;
    	for(int j=0; j<32; j++)
    	{
    		my_data[i] += (adWave[i*32+j]<<j);
    	}
//    	my_data[i] = my_data_H[i]<<32 + my_data_L[i];
    	if(debug)
    	{
    		hex(cout);
    		cout<<"capture OTP NVR4 my_data["<<i<<"] = 0x"<<my_data[i]<<endl;
//    		cout<<"capture NVR data_H["<<i<<"] = 0x"<<my_data_H[i]<<endl;
//    		cout<<"capture NVR data["<<i<<"] = "<<my_data[i]<<endl;
    	}
    }

    result = (double) (my_data[0x08]&comp_2byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"Check_Sum",LIMIT(TM::Pass),result);

    result = (double) (my_data[0x10]&comp_2byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"CP1_Flag",tmLimits,result);

    result = (double) (my_data[0x11]&comp_2byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"CP2_Flag",tmLimits,result);

    result = (double) (my_data[0x0f]&comp_2byte);
    TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"CP3_Flag",tmLimits,result);

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.OTP_VNR4_read", Functional_Test_OTP_VNR4_read);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_FLASH_Trim_Bit: public testmethod::TestMethod {
string label_name;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("label_name",
				 "string",
				 &label_name,
				 testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
	}

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	static string suitName,testName;
//	VECTOR_DATA myVectorData[edit_size];

//	unsigned long long my_data[32];

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		FOR_EACH_SITE_BEGIN();
			Flash_reload_trim_bit(label_name, Trim_bit[CURRENT_SITE_NUMBER()-1][0],Trim_bit[CURRENT_SITE_NUMBER()-1][1]);
		FOR_EACH_SITE_END();
		FUNCTIONAL_TEST();
	ON_FIRST_INVOCATION_END();


//    Trim_bit[CURRENT_SITE_NUMBER()-1][FLASH_BLOCK] = my_data_L[0]&0xff;

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.FLASH_Trim_Bit", Functional_Test_FLASH_Trim_Bit);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Wait_Time: public testmethod::TestMethod {
double wait_time;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("wait_time",
				 "double",
				 &wait_time,
				 testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
	}

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.

	ON_FIRST_INVOCATION_BEGIN();
		WAIT_TIME(wait_time ms);
	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Wait_Time", Functional_Test_Wait_Time);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Burst: public testmethod::TestMethod {
int test_index;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
		//Add your initialization code here
		addParameter("test_index",
					 "int",
					 &test_index,
					 testmethod::TM_PARAMETER_INPUT);
	}

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	std::vector<FUNC_TEST_BURST_RESULT> mpResult;
	ON_FIRST_INVOCATION_BEGIN();
		FW_TASK("DCRM OVEM,LMAP,,(@@)");
		FUNCTIONAL_TEST();
		FW_TASK("DCRM OVEM,FCM,,(@@)");
	ON_FIRST_INVOCATION_END();
	GET_FUNCTIONAL_RESULT("@", mpResult);
	for(uint i=1; i<mpResult.size(); i++)
	{
		FUNC_TEST_BURST_RESULT funcTestRes = mpResult[i];
		flash_sector_test_result[CURRENT_SITE_NUMBER()-1][test_index][i-1] = funcTestRes.result;
		if(debug) cout << "Result for label sector " << funcTestRes.id << ": "<< (funcTestRes.result==true ? "true" : "false" ) << endl;
	}
    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Burst", Functional_Test_Burst);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_FLASH_Test_Result: public testmethod::TestMethod {
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
		//Add your initialization code here
	}

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	int i=0;
	int failed_sector[CP_site];
	int backup_sector_failed[CP_site];
	int NVR_redundancy_invalid[CP_site];
	int site_num;

	static string suitName,testName;
	GET_TESTSUITE_NAME(suitName);

	site_num = CURRENT_SITE_NUMBER()-1;

	//check failed sector account
	failed_sector[site_num] = 0;
	for(i=0; i<512; i++)
	{
		flash_sector_test_result[site_num][flash_final_result][i] =
		flash_sector_test_result[site_num][flash_0xff_min][i]&
		flash_sector_test_result[site_num][flash_0xff_typ][i]&
		flash_sector_test_result[site_num][flash_0xff_max][i]&
		flash_sector_test_result[site_num][flash_ckbd_min][i]&
		flash_sector_test_result[site_num][flash_i_ckbd_max][i]&
		flash_sector_test_result[site_num][flash_0x00_typ][i]&
		flash_sector_test_result[site_num][flash_0xff_retest][i];

		if(flash_sector_test_result[site_num][flash_final_result][i] == 0)
		{
			failed_sector[site_num]++;
		}
	}

	if(debug)
	{
		dec(cout);
		cout<<"site"<<site_num+1<<" failed sector number = "<<failed_sector[site_num]<<endl;
	}

	//check if have backup sector failed
	backup_sector_failed[site_num] = 0;
	if((flash_sector_test_result[site_num][flash_final_result][504]==0)
	 ||(flash_sector_test_result[site_num][flash_final_result][505]==0)
	 ||(flash_sector_test_result[site_num][flash_final_result][506]==0)
	 ||(flash_sector_test_result[site_num][flash_final_result][507]==0)
	 ||(flash_sector_test_result[site_num][flash_final_result][508]==0)
	 ||(flash_sector_test_result[site_num][flash_final_result][509]==0)
	 ||(flash_sector_test_result[site_num][flash_final_result][510]==0)
	 ||(flash_sector_test_result[site_num][flash_final_result][511]==0))
	{
		backup_sector_failed[site_num] = 1;
	}

	if(debug)
	{
		if(backup_sector_failed[site_num])
		{
			cout<<"site"<<site_num+1<<" backup sector failed"<<endl;
		}
	}

	clear_mNVR_redundancy_info(site_num);
	NVR_redundancy_invalid[site_num] = 0;
	//compare recorded failed sector with current failed sector
	for(i=0; i<8; i++)
	{
		valid_redundancy_info[site_num][i] = 0;
		if((redundancy_info_H[site_num][i] == 0xffffffff) &&
		  ((redundancy_info_L[site_num][i]&0xfffffe00) == 0xfffffc00))
		{
			if(debug) cout<<"redundancy info used"<<endl;
			valid_redundancy_info[site_num][i] = (redundancy_info_L[site_num][i]&0x1ff);
			if(flash_sector_test_result[site_num][flash_final_result][valid_redundancy_info[site_num][i]]==0)
			{
				//failed sector already on record, copy redundancy info to struct mNVR_redundancy_info.
				mNVR_redundancy_info[site_num][i].sector_recorded = 1;
				mNVR_redundancy_info[site_num][i].redundancy_sector = valid_redundancy_info[site_num][i];
			}
			else
			{
				//failed sector not failed in current test program
				failed_sector[site_num]++;
			}
		}
		else if((redundancy_info_H[site_num][i] == 0xffffffff) && (redundancy_info_L[site_num][i] == 0xffffffff))
		{
			mNVR_redundancy_info[site_num][i].redundancy_valid = 1;
			if(debug) cout<<"redundancy info to be used"<<endl;
		}
		else
		{
			mNVR_redundancy_info[site_num][i].redundancy_valid = 0;
			NVR_redundancy_invalid[site_num] = 1;
			if(debug)
			{
				hex(cout);
				cout<<"invalid redundancy info, VNR2 addr:0x"<<0x78+i<<endl;
			}
		}
	}

	if(debug)
	{
		if(NVR_redundancy_invalid[site_num])
		{
			cout<<"NVR invalid data redundancy on site"<<site_num+1<<endl;
		}
	}
	//update failed sector info to redundancy info
	if((failed_sector[site_num] <= 8) && (NVR_redundancy_invalid[site_num] == 0))
	{
		for(i=0; i<504; i++)
		{
			if(flash_sector_test_result[site_num][flash_final_result][i] == 0)
			{
				for(int j=0; j<8; j++)
				{
					if(mNVR_redundancy_info[site_num][i].redundancy_sector == i)
					{
						//failed sector on record
						break;
					}
					else if(j==7)
					{
						for(int k=0; k<8; k++)
						{
							if(mNVR_redundancy_info[site_num][k].redundancy_valid)
							{
								mNVR_redundancy_info[site_num][k].redundancy_valid = 0;
								mNVR_redundancy_info[site_num][k].sector_recorded = 1;
								mNVR_redundancy_info[site_num][k].redundancy_sector = i;
							}
						}
					}
				}
			}
		}
	}

	TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"Failed_Sector",tmLimits,failed_sector[site_num]);
	TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"Backup_Sector_Failed",tmLimits,backup_sector_failed[site_num]);
	TestSet.cont(true).judgeAndLog_ParametricTest(suitName,"NVR_redundancy_invalid",tmLimits,NVR_redundancy_invalid[site_num]);

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.FLASH_Test_Result", Functional_Test_FLASH_Test_Result);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_FLASH_Redundancy_data_update: public testmethod::TestMethod {
string label_name;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("label_name",
				 "string",
				 &label_name,
				 testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
	}

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	static string suitName,testName;
	static string FileType;

	static unsigned char data_bin[ByteSector*SectorNum];
	static unsigned char data_reset[ByteSector*SectorNum];
	memset(data_bin, 0xff, ByteSector*SectorNum);
	memset(data_reset, 0xff, ByteSector*SectorNum);
	FileType = "Functional_Test";

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		Read_Bin_File(data_bin,FileType);
		redundancy_secotr_used = 0;
		FOR_EACH_SITE_BEGIN();
			Flash_redundancy_data_update(data_bin);
//			Flash_redundancy_data_update_sector(data_bin+1*1024,  505);
		FOR_EACH_SITE_END();
		Primary.label("flash_program_redundancy_sectors");
		if(redundancy_secotr_used)
		{
			FUNCTIONAL_TEST();
		}

		FOR_EACH_SITE_BEGIN();
			Flash_redundancy_data_update(data_reset);
		FOR_EACH_SITE_END();

	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.FLASH_Redundancy_data_update", Functional_Test_FLASH_Redundancy_data_update);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Buffer_MISC_Trimmed_result: public testmethod::TestMethod {
string label_name;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("label_name",
				 "string",
				 &label_name,
				 testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
	}

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	static string suitName,testName;
	int site_index;
//	unsigned int Trim0, Trim1;
//	unsigned char data[128];
//	unsigned int byte0 = 0xff;
//	unsigned int byte1 = 0xff00;
//	unsigned int byte2 = 0xff0000;
//	unsigned int byte3 = 0xff000000;

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		FOR_EACH_SITE_BEGIN();
			site_index = CURRENT_SITE_NUMBER()-1;
			if(suitName == "Write_Trim_Reg_CP2")
			{
				temp_low_trim[site_index] = 0x0;
				VDD18_high_trim[site_index] = 0x00;	VDD18_low_trim[site_index] = 0x00;
				VDD33_high_trim[site_index] = 0x00;	VDD33_low_trim[site_index] = 0x00;
				OSC_trim[site_index] = 0x00;
			}
			else if(suitName == "Write_Trim_Reg_CP3")
			{
				temp_high_trim[site_index] = 0x0;
				VDD18_high_trim[site_index] = 0x00;	VDD18_low_trim[site_index] = 0x00;
				VDD33_high_trim[site_index] = 0x00;	VDD33_low_trim[site_index] = 0x00;
				OSC_trim[site_index] = 0x00;
			}
			else if(suitName == "Write_Trim_Reg_CP2_Temporary")
			{
				VDD33_high_trim[site_index] = 0x08;	VDD33_low_trim[site_index] = 0x10;
				VDD18_high_trim[site_index] = 0x08;	VDD18_low_trim[site_index] = 0x10;
				temp_high_trim[site_index] = 0xb; temp_low_trim[site_index] = 0x7;
			}
			else if(suitName == "Write_Trim_Reg")
			{
				VDD33_high_trim[site_index] = 0x08;	VDD33_low_trim[site_index] = 0x10;
				VDD18_high_trim[site_index] = 0x08;	VDD18_low_trim[site_index] = 0x10;
				temp_high_trim[site_index] = 0xa; temp_low_trim[site_index] = 0x6; // default value
				OSC_trim[site_index] = 0x220;
//				temp_high_trim[site_index] = 0xb; temp_low_trim[site_index] = 0x6; // device #24
//				temp_high_trim[site_index] = 0xb; temp_low_trim[site_index] = 0x6; // device #24

			}
			else if(suitName == "Write_Trim_FT")
			{
//				VDD33_high_trim[site_index] = 0x08;	VDD33_low_trim[site_index] = 0x10;
//				VDD18_high_trim[site_index] = 0x08;	VDD18_low_trim[site_index] = 0x10;
				temp_high_trim[site_index] = 0xb; temp_low_trim[site_index] = 0x7; // default value
//				OSC_trim[site_index] = 0x220;
//				temp_high_trim[site_index] = 0xb; temp_low_trim[site_index] = 0x6; // device #24
//				temp_high_trim[site_index] = 0xb; temp_low_trim[site_index] = 0x6; // device #24

			}
			Flash_update_trimming_bits(site_index, label_name);
		FOR_EACH_SITE_END();
		FUNCTIONAL_TEST();
	ON_FIRST_INVOCATION_END();

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Buffer_MISC_Trimmed_result", Functional_Test_Buffer_MISC_Trimmed_result);

/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Write_MISC_Trimmed_result: public testmethod::TestMethod {
string label_name;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("label_name",
				 "string",
				 &label_name,
				 testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
	}

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	//Add your test code here.
	static string suitName,testName;
	int OSC_Trim_Diff[CP_site];
	int site_index;
//	unsigned int Trim0, Trim1;
//	unsigned char data[128];
//	unsigned int byte0 = 0xff;
//	unsigned int byte1 = 0xff00;
//	unsigned int byte2 = 0xff0000;
//	unsigned int byte3 = 0xff000000;

	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		FOR_EACH_SITE_BEGIN();
			site_index = CURRENT_SITE_NUMBER()-1;
			VDD18_high_trim[site_index] = 0x08;	VDD18_low_trim[site_index] = 0x10;
			OSC_Trim_Diff[site_index] = abs(OSC_CP2_trim[site_index]-OSC_CP3_trim[site_index]);
			Flash_update_trimming_bits(site_index, label_name);
		FOR_EACH_SITE_END();
		FUNCTIONAL_TEST();
	ON_FIRST_INVOCATION_END();

	TESTSET().cont(true).judgeAndLog_ParametricTest(suitName,suitName,tmLimits,OSC_Trim_Diff[CURRENT_SITE_NUMBER()-1]);

    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Write_MISC_Trimmed_result", Functional_Test_Write_MISC_Trimmed_result);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Read_MISC_Trim_Bit: public testmethod::TestMethod {
string label_name;
string cap_var;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("label_name",
				 "string",
				 &label_name,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("cap_var",
				 "string",
				 &cap_var,
				 testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
	}

  /**
   *This test is invoked per site.
   */
virtual void run()
{
	//Add your test code here.
	static string suitName,testName;
	unsigned int my_data_L;
	unsigned int my_data_H;

	//	unsigned long long my_data[32];

	ARRAY_I adWave;
	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		Primary.label(label_name);
		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();

    adWave = VECTOR(cap_var).getVectors();

    my_data_L = 0;
    my_data_H = 0;
    for(int i=0; i<32; i++)
    {
    	my_data_L += (adWave[i]<<i);
    	my_data_H += (adWave[i+32]<<i);
    }

    my_data_L = my_data_L^0xffffffff;
    my_data_H = my_data_H^0xffffffff;

    if(suitName == "Read_Trim_Reg_CP2")
    {
        OSC_CP2_trim[CURRENT_SITE_NUMBER()-1] = (my_data_H>>16)&0xfff;
		temp_high_trim[CURRENT_SITE_NUMBER()-1] = my_data_H&0xf;
    }
    else if(suitName == "Read_Trim_Reg_CP3")
    {
        OSC_CP3_trim[CURRENT_SITE_NUMBER()-1] = (my_data_H>>16)&0xfff;
		temp_low_trim[CURRENT_SITE_NUMBER()-1] = (my_data_H>>4)&0xf;
    }

    if(debug)
	{
    	hex(cout);
    	cout<<"capture NVR data_L = 0x"<<my_data_L<<"	capture NVR data_H = 0x"<<my_data_H<<endl;
	}

	return;
}

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Read_MISC_Trim_Bit", Functional_Test_Read_MISC_Trim_Bit);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Check_MISC_Trim_Bit: public testmethod::TestMethod {
string label_name;
string cap_var;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("label_name",
				 "string",
				 &label_name,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("cap_var",
				 "string",
				 &cap_var,
				 testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
	}

  /**
   *This test is invoked per site.
   */
virtual void run()
{
	//Add your test code here.
	static string suitName,testName;
	unsigned int my_data_L;
	unsigned int my_data_H;
	int check_fail[CP_site];

	//unsigned long long my_data[32];
	ARRAY_I adWave;
	GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_BEGIN();
		Primary.label(label_name);
		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();
    adWave = VECTOR(cap_var).getVectors();

    my_data_L = 0;
    my_data_H = 0;
    for(int i=0; i<32; i++)
    {
    	my_data_L += (adWave[i]<<i);
    	my_data_H += (adWave[i+32]<<i);
    }

    my_data_L = my_data_L^0xffffffff;
    my_data_H = my_data_H^0xffffffff;

    hex(cout);
    check_fail[CURRENT_SITE_NUMBER()-1] = 0;
    if((unsigned int)OSC_trim[CURRENT_SITE_NUMBER()-1]!=((my_data_H>>16)&0xfff))
    {
    	check_fail[CURRENT_SITE_NUMBER()-1] = 1;
    	cout<<"OSC Trim result check error 0x"<<((my_data_H>>16)&0xfff)<<endl;
    }

    if(suitName == "Check_Trim_Reg_CP2")
    {
        if((unsigned int)temp_high_trim[CURRENT_SITE_NUMBER()-1]!=(my_data_H&0xf))
        {
        	check_fail[CURRENT_SITE_NUMBER()-1] = 1;
        	if(debug) cout<<"temp high trim result check error"<<(my_data_H&0xf)<<endl;
        }
    }
    if(suitName == "Check_Trim_Reg_CP3")
    {
        if((unsigned int)temp_low_trim[CURRENT_SITE_NUMBER()-1]!=((my_data_H&0xf0)>>4))
        {
        	check_fail[CURRENT_SITE_NUMBER()-1] = 1;
        	if(debug) cout<<"temp low trim result check error"<<((my_data_H&0xf0)>>4)<<endl;
        }
    }
    if(suitName == "Check_Trim_Reg_Final")
    {
        if((unsigned int)temp_high_trim[CURRENT_SITE_NUMBER()-1]!=(my_data_H&0xf))
        {
        	check_fail[CURRENT_SITE_NUMBER()-1] = 1;
        	if(debug) cout<<"temp high trim result check error 0x"<<(my_data_H&0xf)<<endl;
        }
        if((unsigned int)temp_low_trim[CURRENT_SITE_NUMBER()-1]!=((my_data_H&0xf0)>>4))
        {
        	check_fail[CURRENT_SITE_NUMBER()-1] = 1;
        	if(debug) cout<<"temp low trim result check error 0x"<<((my_data_H&0xf0)>>4)<<endl;
        }
        if((unsigned int)VDD33_high_trim[CURRENT_SITE_NUMBER()-1]!=(my_data_L&0xff))
        {
        	check_fail[CURRENT_SITE_NUMBER()-1] = 1;
        	if(debug) cout<<"VDD33 high trim result check error 0x"<<(my_data_L&0xff)<<endl;
        }
        if((unsigned int)VDD33_low_trim[CURRENT_SITE_NUMBER()-1]!=((my_data_L&0xff00)>>8))
        {
        	check_fail[CURRENT_SITE_NUMBER()-1] = 1;
        	if(debug) cout<<"VDD33 low trim result check error 0x"<<((my_data_L&0xff00)>>8)<<endl;
        }
        if((unsigned int)((my_data_L&0xff0000)>>16)!=0x08)
        {
        	check_fail[CURRENT_SITE_NUMBER()-1] = 1;
        	if(debug) cout<<"VDD18 high trim result check error 0x"<<((my_data_L&0xff0000)>>16)<<endl;
        }
        if((unsigned int)((my_data_L&0xff000000)>>24)!=0x10)
        {
        	check_fail[CURRENT_SITE_NUMBER()-1] = 1;
        	if(debug) cout<<"VDD18 low trim result check error 0x"<<((my_data_L&0xff000000)>>24)<<endl;
        }
    }

    if(debug)
	{
    	hex(cout);
    	cout<<"capture NVR data_L = 0x"<<my_data_L<<"	capture NVR data_H = 0x"<<my_data_H<<endl;
	}

    TESTSET().cont(true).judgeAndLog_ParametricTest(suitName,suitName,tmLimits,check_fail[CURRENT_SITE_NUMBER()-1]);

	return;
}

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Check_MISC_Trim_Bit", Functional_Test_Check_MISC_Trim_Bit);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_Set_MISC_Reg: public testmethod::TestMethod {
string label_name;
int addr;
int data_H;
int data_L;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("label_name",
				 "string",
				 &label_name,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("addr",
				 "int",
				 &addr,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("data_H",
				 "int",
				 &data_H,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("data_L",
				 "int",
				 &data_L,
				 testmethod::TM_PARAMETER_INPUT);
	}

  /**
   *This test is invoked per site.
   */
virtual void run()
{
	//Add your test code here.
	static string suitName,testName;
	static unsigned int my_data;
	static unsigned int my_addr;
	my_addr = 0x40017000;

	ARRAY_I adWave;
	GET_TESTSUITE_NAME(suitName);

	my_addr = my_addr + addr;
	my_data = data_L + (data_H<<16);

	ON_FIRST_INVOCATION_BEGIN();
		misc_reg_set(label_name, my_addr, my_data);
		FUNCTIONAL_TEST();
	ON_FIRST_INVOCATION_END();

	return;
}

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.Set_MISC_Reg", Functional_Test_Set_MISC_Reg);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class Functional_Test_UART_Protocol: public testmethod::TestMethod {
string label_name;
string cap_var;
	/**
	*Initialize the parameter interface to the testflow.
	*This method is called just once after a testsuite is created.
	*/
	virtual void initialize()
	{
	//Add your initialization code here
	addParameter("label_name",
				 "string",
				 &label_name,
				 testmethod::TM_PARAMETER_INPUT);
	addParameter("cap_var",
				 "string",
				 &cap_var,
				 testmethod::TM_PARAMETER_INPUT);
	//Note: Test Method API should not be used in this method!
	}

  /**
   *This test is invoked per site.
   */
virtual void run()
{
	//Add your test code here.
	static string suitName,testName;

	//	unsigned long long my_data[32];

	ARRAY_I adWave;
	GET_TESTSUITE_NAME(suitName);

	ON_FIRST_INVOCATION_BEGIN();
		CONNECT();
		Primary.label(label_name);
		DIGITAL_CAPTURE_TEST();
	ON_FIRST_INVOCATION_END();

	UART_Protocols(label_name, cap_var);

	return;
}

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("Functional_Test.UART_Protocol", Functional_Test_UART_Protocol);

