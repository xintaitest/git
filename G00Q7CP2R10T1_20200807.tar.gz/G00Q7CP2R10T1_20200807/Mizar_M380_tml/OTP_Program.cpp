#include "testmethod.hpp"

//for test method API interfaces
#include "mapi.hpp"
using namespace std;

struct Efuse_Data_s
{
  unsigned char	Device_key[8];                              //0x00-0x01, Crypto_Flash_Key byte7~0
  unsigned char	hardware_unique[8];                         //0x02-0x03, Crypto_Flash_Key byte15~8
  unsigned char	per_chip[8];                                //0x04-0x05, Mac_Flash_Key byte7~0
  unsigned char	key_HUK[8];                                 //0x06-0x07, Mac_Flash_Key byte15~8

  unsigned char	ICV_provisioning_master_key[16];            //0x08-0x0B, not use
  unsigned char	ICV_code_encryption_key[16];                //0x0C-0x0F, not use
  unsigned char	ICV_programmed_flag[4];                     //0x10,write 0x808080XX,XX = Number of bit '0' in HUK

  unsigned char	Root_of_Trust_Public_Key[32];               //0x11-0x18, HBK[31:0]
  unsigned char	OEM_provisioning_master_key[16];            //0x19-0x1C, not use
  unsigned char	OEM_code_encryption_key[16];                //0x1D-0x20, not use
  unsigned char	OEM_programmed_flag[4];                     //0x21,write 0x808080XX,XX = Number of bit '0' in HBK

  unsigned char	Anti_RollBack_Counter[20];                  //0x22-0x26, record firmware vision, leave it to 0
  unsigned char	General_purpose_configuration_flags[4];     //0x27, initialization to 0x00000005
/**************************************************************************************************************
                                                            bit[2:0] PLL Freq select
                                                            000: 16 MHz
                                                            001: 20 MHz
                                                            010: 30 MHz
                                                            011: 40 MHz
                                                            100: 50 MHz
                                                            101: 60 MHz
                                                            110: 70 MHz
                                                            111: 80 MHz
                                                            bit[3] internal/external clock
                                                            0: use external clock
                                                            1: use internal clock
                                                            bit[7:4] reserver
                                                            bit[10:8] firmware size in flash and redundance
                                                            000: 128KB firmware size, block A and block B redundance
                                                            001: 192KB firmware size, block A and block B redundance
                                                            010: 256KB firmware size, block A and block B redundance
                                                            011: 320KB firmware size, block A and block B redundance
                                                            100: 384KB firmware size, block A and block B redundance
                                                            101: 448KB firmware size, block A and block B redundance
                                                            110: 512KB firmware size, block A and block B redundance
                                                            111: block A only, unlimited size.
                                                            bit[11] enable switch block A and block B
                                                            0: enable
                                                            1: disable
                                                            bit[15:12] reserver
                                                            bit[23:16] FLUSH FREQ
                                                            bit[31:24] reserver
**************************************************************************************************************/
  unsigned char	DCU_128_bit_lock_mask[16];                  //0x28-0x2B, completed flag, set to 0xF012345F
  unsigned char	SERIAL_ID[4];                               //0x2C, 32 bit unsigned integer serial number of each unique part.
  unsigned char	Mode_Name[4];                               //0x2D, MFGID
/**************************************************************************************************************
                                                            bit[7:0] Company ID
                                                            0x00: SQ
                                                            0x01: GQ
                                                            bit[11:8] FLASH_size
                                                            0000: 64KB
                                                            0001: 128KB
                                                            ......
                                                            1111: 1MB
                                                            bit[15:12] SRAM size
                                                            0000: 16KB
                                                            0001: 32KB
                                                            ......
                                                            1001: 160KB
                                                            1010 ~ 1111: reserver
                                                            bit[31:16] Peripherals, support interface port
                                                            [16]: UART0;
                                                            [17]: UART1;
                                                            [18]: SPI0;
                                                            [19]: SPI1;
                                                            [20]: SPI2;
                                                            [21]: SPI3;
                                                            [22]: I2C0;
                                                            [23]: I2C1;
**************************************************************************************************************/
	unsigned char	MDATE[4];                               //0x2E, MDATE, 32 bit unsigned integer time offset in seconds from 00:00 Jan1 1970

	unsigned char	MFG_PK_Zero_Bit_Number[4];              //0x2F, MFG PK bit '0' number
	unsigned char	MFG_PK[64];                             //0x30-0x3F, MFG PK
	unsigned char	Crypto_Flash_Key[16];                   //0x40-0x43, Crypto Flash Key(SM4)
	unsigned char	Mac_Flash_Key[16];                      //0x44-0x47, Mac Flash Key(SM4)
	unsigned char	Flash_Key_Zero_Bit_Number[4];           //0x48, Flash Key bit '0' number
/**************************************************************************************************************
                                                            bit[7:0] Crypto Flash Key bit '0' number
                                                            bit[15:8] Mac Flash Key bit '0' number
                                                            bit[31:16] reserver
**************************************************************************************************************/
};


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class OTP_Program: public testmethod::TestMethod {

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    //Add your test code here.
    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const 
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("OTP_Program", OTP_Program);
