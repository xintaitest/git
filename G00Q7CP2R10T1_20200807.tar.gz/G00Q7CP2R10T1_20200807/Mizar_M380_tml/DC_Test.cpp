#include "testmethod.hpp"

//for test method API interfaces
#include <stdlib.h>
#include "mapi.hpp"
#include "Public.h"
#include "d2s/d2sFramework.h"
#include "d2s/d2s_MDIO.h"
#include "OutputDCUtil.hpp"

using namespace std;
using namespace V93kLimits;

enum {TWO_LEVEL = 2};  /*two kinds of output level*/
enum MeasuredLevelType { LOW_LEVEL = 0, HIGH_LEVEL = 1 };

/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_Iforce_Vmeasure: public testmethod::TestMethod {
protected:
  string  Test_pins;
  double  iRange_uA;
  double  ForceCurrent_uA;
  double  wait_time;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!
	addParameter("Test_pins",
	             "PinString",
	             &Test_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("iRange_uA",
	             "double",
	             &iRange_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("ForceCurrent_uA",
	             "double",
	             &ForceCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
	             "double",
	             &wait_time,
	             testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	PPMU_SETTING setting;
	PPMU_RELAY relay_on ,relay_off;
	PPMU_MEASURE ppmuMeasure;
	PPMU_CLAMP clamp_on, clamp_off;
	TASK_LIST task1;
	static STRING_VECTOR pinList;
	static string suitName,testName;
	TMLimits::LimitInfo mLimitInfo;
	double LowLimit, HighLimit, UnitRatio;
	string mUnits, mLslTyp, mUslTyp;

	ON_FIRST_INVOCATION_BEGIN();
		//DISCONNECT();
		CONNECT();
//		FUNCTIONAL_TEST();
		FW_TASK("rlyc idle,off,(Except_Control)\n");
		FLUSH(TM::APRM);
		pinList = PinUtility.getDigitalPinNamesFromPinList(Test_pins,TM::ALL_DIGITAL,true,true);

		setting.pin(Test_pins).iRange(iRange_uA uA).min(-1 V).max(3.5 V).iForce(ForceCurrent_uA uA);
		relay_on.pin(Test_pins).status("PPMU_ON");
		relay_on.wait(wait_time ms);
		relay_off.pin(Test_pins).status("AC_ON");

		ppmuMeasure.pin(Test_pins).execMode(TM::PVAL);

		clamp_on.pin(Test_pins).status("CLAMP_ON").low(-1 V).high(3.5 V);
		clamp_off.pin(Test_pins).status("CLAMP_OFF");

		task1.add(setting).add(clamp_on).add(relay_on).add(clamp_off).add(ppmuMeasure).add(relay_off);
		task1.execute();

		flex_relay_control("ALL_PINS","AC","X");

//		FW_TASK("rlyc idle,off,(SerDes_Pins)\n");
//		FLUSH(TM::APRM);

		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(unsigned int i=0;i<pinList.size();i++)
		{
			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],ppmuMeasure.getValue(pinList[i]));
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	for(unsigned int i=0;i<pinList.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],testName,tmLimits,ppmuMeasure.getValue(pinList[i])*1e3);
	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.Iforce_Vmeasure", DC_Test_Iforce_Vmeasure);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_Iforce_Vmeasure_with_PPMU_Vforce: public testmethod::TestMethod {
protected:
  string  Test_pins;
  double  iRange_uA;
  double  ForceCurrent_uA;
  double  wait_time;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!
	addParameter("Test_pins",
	             "PinString",
	             &Test_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("iRange_uA",
	             "double",
	             &iRange_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("ForceCurrent_uA",
	             "double",
	             &ForceCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
	             "double",
	             &wait_time,
	             testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	PPMU_SETTING setting;
	PPMU_RELAY relay_on ,relay_off;
	PPMU_MEASURE ppmuMeasure;
	PPMU_CLAMP clamp_on, clamp_off;
	TASK_LIST task1;
	static STRING_VECTOR pinList;
	static string suitName,testName;
	TMLimits::LimitInfo mLimitInfo;
	double LowLimit, HighLimit, UnitRatio;
	string mUnits, mLslTyp, mUslTyp;

	ON_FIRST_INVOCATION_BEGIN();
		//DISCONNECT();
		CONNECT();
//		FUNCTIONAL_TEST();
		FW_TASK("rlyc idle,off,(Except_Control)\n");
		FLUSH(TM::APRM);
		pinList = PinUtility.getDigitalPinNamesFromPinList(Test_pins,TM::ALL_DIGITAL,true,true);

		setting.pin(Test_pins).iRange(iRange_uA uA).min(-1 V).max(3.5 V).iForce(ForceCurrent_uA uA);
		relay_on.pin(Test_pins).status("PPMU_ON");
		relay_on.wait(wait_time ms);
		relay_off.pin(Test_pins).status("AC_ON");

		ppmuMeasure.pin(Test_pins).execMode(TM::PVAL);

		clamp_on.pin(Test_pins).status("CLAMP_ON").low(-1 V).high(3.5 V);
		clamp_off.pin(Test_pins).status("CLAMP_OFF");

		task1.add(setting).add(clamp_on).add(relay_on).add(clamp_off).add(ppmuMeasure).add(relay_off);
		task1.execute();

		flex_relay_control("ALL_PINS","AC","X");

//		FW_TASK("rlyc idle,off,(SerDes_Pins)\n");
//		FLUSH(TM::APRM);

		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(unsigned int i=0;i<pinList.size();i++)
		{
			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],ppmuMeasure.getValue(pinList[i]));
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	for(unsigned int i=0;i<pinList.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],testName,tmLimits,ppmuMeasure.getValue(pinList[i]));
	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.Iforce_Vmeasure_with_PPMU_Vforce", DC_Test_Iforce_Vmeasure_with_PPMU_Vforce);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_Iforce_Vmeasure_Sensor_Trim: public testmethod::TestMethod {
protected:
  string  Test_pins;
  string  Label_name;
  double  iRange_uA;
  double  ForceCurrent_uA;
  double  wait_time;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!
	addParameter("Test_pins",
	             "PinString",
	             &Test_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("Label_name",
	             "string",
	             &Label_name,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("iRange_uA",
	             "double",
	             &iRange_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("ForceCurrent_uA",
	             "double",
	             &ForceCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
	             "double",
	             &wait_time,
	             testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	PPMU_SETTING setting;
	PPMU_RELAY relay_on ,relay_off;
	PPMU_MEASURE ppmuMeasure[16];
	PPMU_CLAMP clamp_on, clamp_off;
	TASK_LIST task1;
	static STRING_VECTOR pinList;
	static string suitName,testName;
	TMLimits::LimitInfo mLimitInfo;
	//double LowLimit, HighLimit, UnitRatio;
	string mUnits, mLslTyp, mUslTyp;
	string Label_name = "VDD_18_Low_Set";
	string SetLabel, Str_itoa;
	char str_char[10];

	for(int i=0; i<=15; i++)
	{
		ON_FIRST_INVOCATION_BEGIN();

			sprintf(str_char, "%d", i);
			Str_itoa = str_char;
			SetLabel = Label_name + Str_itoa;
			Primary.label(SetLabel);
			CONNECT();
			FUNCTIONAL_TEST();

			FW_TASK("rlyc idle,off,(Except_Trim_pins)\n");
			FLUSH(TM::APRM);
			pinList = PinUtility.getDigitalPinNamesFromPinList(Test_pins,TM::ALL_DIGITAL,true,true);

			setting.pin(Test_pins).iRange(iRange_uA uA).min(-1 V).max(3.5 V).iForce(ForceCurrent_uA uA);
			relay_on.pin(Test_pins).status("PPMU_ON");
			relay_on.wait(wait_time ms);
			relay_off.pin(Test_pins).status("AC_ON");

			ppmuMeasure[i].pin(Test_pins).execMode(TM::PVAL);

			clamp_on.pin(Test_pins).status("CLAMP_ON").low(-1 V).high(3.5 V);
			clamp_off.pin(Test_pins).status("CLAMP_OFF");

			task1.add(setting).add(clamp_on).add(relay_on).add(clamp_off).add(ppmuMeasure[i]).add(relay_off);
			task1.execute();

			flex_relay_control("ALL_PINS","AC","X");

	//		FW_TASK("rlyc idle,off,(SerDes_Pins)\n");
	//		FLUSH(TM::APRM);

			GET_TESTSUITE_NAME(suitName);
		ON_FIRST_INVOCATION_END();
	}

	//get test table information
	testName = suitName;

//	if(debug)
//	{
//		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
//		for(unsigned int i=0;i<pinList.size();i++)
//		{
//			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
//			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],ppmuMeasure[i].getValue(pinList[i]));
//		}
//		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
//	}
//
//	for(unsigned int i=0;i<pinList.size();i++)
//	{
//		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],testName,tmLimits,ppmuMeasure[i].getValue(pinList[i]));
//	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.Iforce_Vmeasure_Sensor_Trim", DC_Test_Iforce_Vmeasure_Sensor_Trim);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_Vforce_Imeasure_uA: public testmethod::TestMethod {
protected:
  string  Test_pins;
  double  iRange_uA;
  double  ForceVoltage_V;
  double  MinCurrent_uA;
  double  MaxCurrent_uA;
  double  wait_time;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!
	addParameter("Test_pins",
	             "PinString",
	             &Test_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("iRange_uA",
	             "double",
	             &iRange_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("ForceVoltage_V",
	             "double",
	             &ForceVoltage_V,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("MinCurrent_uA",
	             "double",
	             &MinCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("MaxCurrent_uA",
	             "double",
	             &MaxCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
	             "double",
	             &wait_time,
	             testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	PPMU_SETTING setting;
	PPMU_RELAY relay_on ,relay_off;
	PPMU_MEASURE ppmuMeasure;
	PPMU_CLAMP clamp_on, clamp_off;
	TASK_LIST task1;
	static STRING_VECTOR pinList;
	static string suitName,testName;
	TMLimits::LimitInfo mLimitInfo;
	double LowLimit, HighLimit, UnitRatio;
	string mUnits, mLslTyp, mUslTyp;
	ON_FIRST_INVOCATION_BEGIN();
		//DISCONNECT();
		CONNECT();
//		FUNCTIONAL_TEST();
		FW_TASK("rlyc idle,off,(ALL_PINS)\n");
		FLUSH(TM::APRM);
		pinList = PinUtility.getDigitalPinNamesFromPinList(Test_pins,TM::ALL_DIGITAL,true,true);

		setting.pin(Test_pins).iRange(iRange_uA uA);
		setting.pin(Test_pins).vForce(ForceVoltage_V).min(MinCurrent_uA uA).max(MaxCurrent_uA uA);
		relay_on.pin(Test_pins).status("PPMU_ON");
		relay_on.wait(wait_time ms);
		relay_off.pin(Test_pins).status("AC_ON");

		ppmuMeasure.pin(Test_pins).execMode(TM::PVAL);

		clamp_on.pin(Test_pins).status("CLAMP_ON").low(0 V).high(3.5 V);
		clamp_off.pin(Test_pins).status("CLAMP_OFF");

		task1.add(setting).add(clamp_on).add(relay_on).add(clamp_off).add(ppmuMeasure).add(relay_off);
		task1.execute();

//		flex_relay_control("ALL_PINS","AC","X");
		FW_TASK("rlyc idle,off,(ALL_PINS)\n");

		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;
	getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(unsigned int i=0;i<pinList.size();i++)
		{
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],ppmuMeasure.getValue(pinList[i]));
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	for(unsigned int i=0;i<pinList.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],testName,tmLimits,ppmuMeasure.getValue(pinList[i])*1e6);
	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.Vforce_Imeasure_uA", DC_Test_Vforce_Imeasure_uA);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_Iforce_Vmeasure_Vcom: public testmethod::TestMethod {
protected:
  string  Test_pins;
  string  Test_pins_PAM4;
  string  Test_pins_NRZ;
  double  iRange_uA;
  double  ForceCurrent_uA;
  double  wait_time;
  int isMultiLimit;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!
	addParameter("Test_pins",
	             "PinString",
	             &Test_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("Test_pins_PAM4",
	             "PinString",
	             &Test_pins_PAM4,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("Test_pins_NRZ",
	             "PinString",
	             &Test_pins_NRZ,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("iRange_uA",
	             "double",
	             &iRange_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("ForceCurrent_uA",
	             "double",
	             &ForceCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
	             "double",
	             &wait_time,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("isMultiLimit",
	             "int",
	             &isMultiLimit,
	             testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	PPMU_SETTING setting;
	PPMU_RELAY relay_on ,relay_off;
	PPMU_MEASURE ppmuMeasure;
	PPMU_CLAMP clamp_on, clamp_off;
	TASK_LIST task1;
	static STRING_VECTOR pinList, pinList_PAM4, pinList_NRZ;
	static string suitName,testName;
	TMLimits::LimitInfo mLimitInfo;
	double LowLimit, HighLimit, UnitRatio;
	string mUnits, mLslTyp, mUslTyp;

	ON_FIRST_INVOCATION_BEGIN();
		//DISCONNECT();
		CONNECT();
//		FUNCTIONAL_TEST();
		FW_TASK("rlyc idle,off,(Except_Control)\n");
		FLUSH(TM::APRM);
		pinList = PinUtility.getDigitalPinNamesFromPinList(Test_pins,TM::ALL_DIGITAL,true,true);
		pinList_PAM4 = PinUtility.getDigitalPinNamesFromPinList(Test_pins_PAM4,TM::ALL_DIGITAL,true,true);
		pinList_NRZ = PinUtility.getDigitalPinNamesFromPinList(Test_pins_NRZ,TM::ALL_DIGITAL,true,true);

		setting.pin(Test_pins).iRange(iRange_uA uA).min(-1 V).max(3.5 V).iForce(ForceCurrent_uA uA);
		relay_on.pin(Test_pins).status("PPMU_ON");
		relay_on.wait(wait_time ms);
		relay_off.pin(Test_pins).status("AC_ON");

		ppmuMeasure.pin(Test_pins).execMode(TM::PVAL);

		clamp_on.pin(Test_pins).status("CLAMP_ON").low(-1 V).high(3.5 V);
		clamp_off.pin(Test_pins).status("CLAMP_OFF");

		task1.add(setting).add(clamp_on).add(relay_on).add(clamp_off).add(ppmuMeasure).add(relay_off);
		task1.execute();

		flex_relay_control("ALL_PINS","AC","X");

//		FW_TASK("rlyc idle,off,(SerDes_Pins)\n");
//		FLUSH(TM::APRM);

		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		testName = "NRZ";
		for(unsigned int i=0;i<pinList_NRZ.size();i++)
		{
			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList_NRZ[i],ppmuMeasure.getValue(pinList_NRZ[i]));
		}
		testName = "PAM4";
		for(unsigned int i=0;i<pinList_PAM4.size();i++)
		{
			getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList_PAM4[i],ppmuMeasure.getValue(pinList_PAM4[i]));
		}

		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	testName = "NRZ";
	for(unsigned int i=0;i<pinList_NRZ.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList_NRZ[i],testName,tmLimits,ppmuMeasure.getValue(pinList_NRZ[i]));
	}

	testName = "PAM4";
	for(unsigned int i=0;i<pinList_PAM4.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList_PAM4[i],testName,tmLimits,ppmuMeasure.getValue(pinList_PAM4[i]));
	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.Iforce_Vmeasure_Vcom", DC_Test_Iforce_Vmeasure_Vcom);



/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_Iforce_Vmeasure_TestPoint: public testmethod::TestMethod {
protected:
  string  Test_pins;
  string  group_name;
  double  iRange_uA;
  double  ForceCurrent_uA;
  double  wait_time;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!
	addParameter("Test_pins",
	             "PinString",
	             &Test_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("group_name",
	             "string",
	             &group_name,
	             testmethod::TM_PARAMETER_INPUT)
				 .setOptions("RX_PLL:TX_PLL:RX_LAN:TX_LAN");
	addParameter("iRange_uA",
	             "double",
	             &iRange_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("ForceCurrent_uA",
	             "double",
	             &ForceCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
	             "double",
	             &wait_time,
	             testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	PPMU_SETTING setting;
	PPMU_RELAY relay_on ,relay_off;
	PPMU_MEASURE ppmuMeasure;
	PPMU_CLAMP clamp_on, clamp_off;
	TASK_LIST task1;
	static STRING_VECTOR pinList;
	static string suitName,testName;
	TMLimits::LimitInfo mLimitInfo;
	double LowLimit, HighLimit, UnitRatio;
	string mUnits, mLslTyp, mUslTyp;

	d2sFramework fr;
	d2s_MDIO& MDIO = d2s_MDIO::Instance();
	fr.registerTransactionPort(MDIO);

	for(unsigned int i=0; i<=32; i++)
	{
		if(mTestPointArray[i].group_name == group_name)
		{
			ON_FIRST_INVOCATION_BEGIN();

				//DISCONNECT();
				CONNECT();
				fr.d2s_LABEL_BEGIN(mTestPointArray[i].full_item_name, (d2sFrameWorkModeType::Enum) d2sFrameworkMode);
				//EngineeringMode = 0, LearningMode = 1, ProductionMode = 2, DefaultMode = 3

				MDIO.write(mTestPointArray[i].address, mTestPointArray[i].default_data + (mTestPointArray[i].vtsgroup_data<<mTestPointArray[i].vtsgroup_low_bit));
				fr.d2s_LABEL_END();

				FUNCTIONAL_TEST();

				FW_TASK("rlyc idle,off,(Except_Control)\n");
				FLUSH(TM::APRM);
				pinList = PinUtility.getDigitalPinNamesFromPinList(Test_pins,TM::ALL_DIGITAL,true,true);

				setting.pin(Test_pins).iRange(iRange_uA uA).min(-1 V).max(3.5 V).iForce(ForceCurrent_uA uA);
				relay_on.pin(Test_pins).status("PPMU_ON");
				relay_on.wait(wait_time ms);
				relay_off.pin(Test_pins).status("AC_ON");

				ppmuMeasure.pin(Test_pins).execMode(TM::PVAL);

				clamp_on.pin(Test_pins).status("CLAMP_ON").low(-1 V).high(3.5 V);
				clamp_off.pin(Test_pins).status("CLAMP_OFF");

				task1.add(setting).add(clamp_on).add(relay_on).add(clamp_off).add(ppmuMeasure).add(relay_off);
				task1.execute();

				flex_relay_control("ALL_PINS","AC","X");

//				FW_TASK("rlyc idle,off,(SerDes_Pins)\n");
//				FLUSH(TM::APRM);

				GET_TESTSUITE_NAME(suitName);
			ON_FIRST_INVOCATION_END();

			//get test table information
			testName = mTestPointArray[i].full_item_name;

			if(debug)
			{
				cout<<"Testsuit:"<<suitName<<", testName: "<<testName<<" test result:"<<endl;
				for(unsigned int i=0;i<pinList.size();i++)
				{
					getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);
					print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],ppmuMeasure.getValue(pinList[i]));
				}
			cout<<"Testsuit:"<<suitName<<", testName: "<<testName<<" end\n"<<endl;
			}

			for(unsigned int i=0;i<pinList.size();i++)
			{
				TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],testName,tmLimits,ppmuMeasure.getValue(pinList[i]));
			}
		}
	}
	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.Iforce_Vmeasure_TestPoint", DC_Test_Iforce_Vmeasure_TestPoint);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_Vforce_Imeasure_with_PPMU_Vforce: public testmethod::TestMethod {
protected:
  string  All_pins;
  string  Test_pins;
  string  Pullup_pins;
  string  Pulldown_pins;
  double  iRange_uA;
  double  ForceVoltage_V;
  double  MinCurrent_uA;
  double  MaxCurrent_uA;
  double  wait_time;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!

	addParameter("All_pins",
	             "PinString",
	             &All_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("Test_pins",
	             "PinString",
	             &Test_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("Pullup_pins",
	             "PinString",
	             &Pullup_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("Pulldown_pins",
	             "PinString",
	             &Pulldown_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("iRange_uA",
	             "double",
	             &iRange_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("ForceVoltage_V",
	             "double",
	             &ForceVoltage_V,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("MinCurrent_uA",
	             "double",
	             &MinCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("MaxCurrent_uA",
	             "double",
	             &MaxCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
	             "double",
	             &wait_time,
	             testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	PPMU_SETTING setting;
	PPMU_RELAY relay_on ,relay_off;
	PPMU_MEASURE ppmuMeasure;
	PPMU_CLAMP clamp_on, clamp_off;
	TASK_LIST task1;
	static STRING_VECTOR pinList;
	static string suitName, testName;
	double LowLimit, HighLimit, UnitRatio;
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;

	ON_FIRST_INVOCATION_BEGIN();
//		DISCONNECT();
		CONNECT();
//		FUNCTIONAL_TEST();
		FW_TASK("rlyc idle,off,(ALL_PINS)\n");
//		FW_TASK("rlyc idle,off,(Except_Control)\n");
		FLUSH(TM::APRM);
		pinList = PinUtility.getDigitalPinNamesFromPinList(Test_pins,TM::ALL_DIGITAL,true,true);

		setting.pin(Test_pins).iRange(iRange_uA uA);
		setting.pin(Pullup_pins).iRange(iRange_uA uA);
		setting.pin(Pulldown_pins).iRange(iRange_uA uA);

		setting.pin(Test_pins).vForce(ForceVoltage_V).min(MinCurrent_uA uA).max(MaxCurrent_uA uA);
		setting.pin(Pullup_pins).vForce(3.3).min(MinCurrent_uA uA).max(MaxCurrent_uA uA);
		setting.pin(Pulldown_pins).vForce(0).min(MinCurrent_uA uA).max(MaxCurrent_uA uA);

		relay_on.pin(All_pins).status("PPMU_ON");
		relay_on.wait(wait_time ms);
		relay_off.pin(All_pins).status("AC_ON");

		ppmuMeasure.pin(All_pins).execMode(TM::PVAL);

		clamp_on.pin(All_pins).status("CLAMP_ON").low(-0.5 V).high(4 V);
		clamp_off.pin(All_pins).status("CLAMP_OFF");

		task1.add(setting).add(clamp_on).add(relay_on).add(clamp_off).add(ppmuMeasure).add(relay_off);
		task1.execute();

		flex_relay_control("ALL_PINS","AC","X");

		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;
	getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(unsigned int i=0;i<pinList.size();i++)
		{
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],ppmuMeasure.getValue(pinList[i]));
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	for(unsigned int i=0;i<pinList.size();i++)
	{
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],testName,tmLimits,ppmuMeasure.getValue(pinList[i])*1e6);
		if(PAT_compare) PAT_Limit_compare(suitName, testName, pinList[i], ppmuMeasure.getValue(pinList[i])*1e6);
	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.Vforce_Imeasure_with_PPMU_Vforce", DC_Test_Vforce_Imeasure_with_PPMU_Vforce);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_Vforce_Imeasure_with_Resistance_Calculator: public testmethod::TestMethod {
protected:
  string  All_pins;
  string  Test_pins;
  string  Pullup_pins;
  string  Pulldown_pins;
  double  iRange_uA;
  double  ForceVoltage_V;
  double  MinCurrent_uA;
  double  MaxCurrent_uA;
  double  wait_time;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!

	addParameter("All_pins",
	             "PinString",
	             &All_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("Test_pins",
	             "PinString",
	             &Test_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("Pullup_pins",
	             "PinString",
	             &Pullup_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("Pulldown_pins",
	             "PinString",
	             &Pulldown_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("iRange_uA",
	             "double",
	             &iRange_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("ForceVoltage_V",
	             "double",
	             &ForceVoltage_V,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("MinCurrent_uA",
	             "double",
	             &MinCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("MaxCurrent_uA",
	             "double",
	             &MaxCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
	             "double",
	             &wait_time,
	             testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	PPMU_SETTING setting;
	PPMU_RELAY relay_on ,relay_off;
	PPMU_MEASURE ppmuMeasure;
	PPMU_CLAMP clamp_on, clamp_off;
	TASK_LIST task1;
	static STRING_VECTOR pinList;
	static string suitName, testName;
	double LowLimit, HighLimit, UnitRatio;
	double Resistance, VDD33_Voltage = 3.3;
	TMLimits::LimitInfo mLimitInfo;
	string mUnits, mLslTyp, mUslTyp;

	ON_FIRST_INVOCATION_BEGIN();
//		DISCONNECT();
		CONNECT();
//		FUNCTIONAL_TEST();
		FW_TASK("rlyc idle,off,(ALL_PINS)\n");
//		FW_TASK("rlyc idle,off,(Except_Control)\n");
		FLUSH(TM::APRM);
		pinList = PinUtility.getDigitalPinNamesFromPinList(Test_pins,TM::ALL_DIGITAL,true,true);

		setting.pin(Test_pins).iRange(iRange_uA uA);
		setting.pin(Pullup_pins).iRange(iRange_uA uA);
		setting.pin(Pulldown_pins).iRange(iRange_uA uA);

		setting.pin(Test_pins).vForce(ForceVoltage_V).min(MinCurrent_uA uA).max(MaxCurrent_uA uA);
		setting.pin(Pullup_pins).vForce(3.3).min(MinCurrent_uA uA).max(MaxCurrent_uA uA);
		setting.pin(Pulldown_pins).vForce(0).min(MinCurrent_uA uA).max(MaxCurrent_uA uA);

		relay_on.pin(All_pins).status("PPMU_ON");
		relay_on.wait(wait_time ms);
		relay_off.pin(All_pins).status("AC_ON");

		ppmuMeasure.pin(All_pins).execMode(TM::PVAL);

		clamp_on.pin(All_pins).status("CLAMP_ON").low(-0.5 V).high(4 V);
		clamp_off.pin(All_pins).status("CLAMP_OFF");

		task1.add(setting).add(clamp_on).add(relay_on).add(clamp_off).add(ppmuMeasure).add(relay_off);
		task1.execute();

		flex_relay_control("ALL_PINS","AC","X");
//		FW_TASK("rlyc idle,off,(ALL_PINS)\n");

		GET_TESTSUITE_NAME(suitName);
	ON_FIRST_INVOCATION_END();

	//get test table information
	testName = suitName;
	getLimitInfo(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp);

	if(debug)
	{
		cout<<"Testsuit:"<<suitName<<" test result:"<<endl;
		for(unsigned int i=0;i<pinList.size();i++)
		{
			Resistance = VDD33_Voltage/abs(ppmuMeasure.getValue(pinList[i]))/1e3;
			print_datalog_ui_report(suitName, testName, LowLimit, HighLimit, mUnits, UnitRatio, mLslTyp, mUslTyp, pinList[i],Resistance);
		}
		cout<<"Testsuit:"<<suitName<<" end\n"<<endl;
	}

	for(unsigned int i=0;i<pinList.size();i++)
	{
		Resistance = VDD33_Voltage/abs(ppmuMeasure.getValue(pinList[i]))/1e3;
		TESTSET().cont(true).judgeAndLog_ParametricTest(pinList[i],testName,tmLimits,Resistance);
		if(PAT_compare) PAT_Limit_compare(suitName, testName, pinList[i], Resistance);
	}

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.Vforce_Imeasure_with_Resistance_Calculator", DC_Test_Vforce_Imeasure_with_Resistance_Calculator);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_limit_initial: public testmethod::TestMethod {
protected:

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	  ON_FIRST_INVOCATION_BEGIN();
	  	  if(!limit_initialed)
	  	  {
	  		initial_dynamic_PAT_limit();
	  		limit_initialed = 1;
	  	  }
	  ON_FIRST_INVOCATION_END();
	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.limit_initial", DC_Test_limit_initial);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_limit_data_clear: public testmethod::TestMethod {
protected:

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	  ON_FIRST_INVOCATION_BEGIN();
	  if(mDynamic_PAT_limit[0].tested_unit >= mDynamic_PAT_limit[0].initial_population)
	  {
		  reset_dynamic_PAT_limit();
	  }
	  ON_FIRST_INVOCATION_END();
	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.limit_data_clear", DC_Test_limit_data_clear);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_BADC_Measure: public testmethod::TestMethod {
protected:
  string  Test_pins;
  double  iRange_uA;
  double  ForceVoltage_V;
  double  MinCurrent_uA;
  double  MaxCurrent_uA;
  double  wait_time;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!
	addParameter("Test_pins",
	             "PinString",
	             &Test_pins,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("iRange_uA",
	             "double",
	             &iRange_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("ForceVoltage_V",
	             "double",
	             &ForceVoltage_V,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("MinCurrent_uA",
	             "double",
	             &MinCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("MaxCurrent_uA",
	             "double",
	             &MaxCurrent_uA,
	             testmethod::TM_PARAMETER_INPUT);
	addParameter("wait_time",
	             "double",
	             &wait_time,
	             testmethod::TM_PARAMETER_INPUT);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
//	  int siteNum;
//	  string tsName;
//
//	  HV_DC_TASK HV_meas1;
//	  siteNum = 4;
//
//	  // connect BADC relay before measurement
//	  ON_FIRST_INVOCATION_BEGIN();
//	  	  GET_TESTSUITE_NAME(tsName);
//	  	  DISCONNECT();
//	  	  CONNECT();
//	  	  HV_meas1.pin(Test_pins)
//	  			  .vForce(10 V)
//	  			  .min(-10 uA)
//	  			  .max(10 uA)
//	  			  .execMode("HV_PPMU_BADC_VAL");
//	  	  HV_meas1.execute();
//  	  ON_FIRST_INVOCATION_END();


	  HV_DC_TASK hvDCtask;



	  ON_FIRST_INVOCATION_BEGIN();

	    CONNECT();



	    hvDCtask.pin(Test_pins)
	         .vForce(10 V)
	         .min( 0 mA)
	         .max(10 mA)
	         .execMode("HV_PPMU_BADC_VAL");
	    hvDCtask.execute();

	    STRING_VECTOR svPinList =  PinUtility.expandDigitalPinNamesFromPinList(Test_pins,TM::IO_PIN,TM::IGNORE_MISSING_PIN_NAMES);

	    FOR_EACH_SITE_BEGIN();
	      for (STRING_VECTOR::iterator it = svPinList.begin(); it != svPinList.end(); ++it) {

	          cerr << (*it) << " measured " << hvDCtask.getValue((*it)) << "A\n";
	      }
	    FOR_EACH_SITE_END();
	    DISCONNECT();
	  ON_FIRST_INVOCATION_END();

	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.BADC_Measure", DC_Test_BADC_Measure);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_AC_Relay_Off: public testmethod::TestMethod {
protected:
	string AC_Off_Pins;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
		addParameter("AC_Off_Pins",
				     "PinString",
				     &AC_Off_Pins,
				     testmethod::TM_PARAMETER_INPUT);
    //Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	  ON_FIRST_INVOCATION_BEGIN();
	  	  FW_TASK("rlyc idle,off,(GPIO1)\n");
	  ON_FIRST_INVOCATION_END();
	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.AC_Relay_Off", DC_Test_AC_Relay_Off);


/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class DC_Test_AC_Relay_On: public testmethod::TestMethod {
protected:

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    //Note: Test Method API should not be used in this method!
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	  ON_FIRST_INVOCATION_BEGIN();
	  	  flex_relay_control("ALL_PINS","AC","X");
	  ON_FIRST_INVOCATION_END();
	return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    //Note: Test Method API should not be used in this method!
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.AC_Relay_On", DC_Test_AC_Relay_On);



/**
 *----------------------------------------------------------------------*
 * @testmethod class: OutputDC
 *
 * @Purpose: measure output level
 *
 *----------------------------------------------------------------------*
 * @Description:
 *   string pinlist:              {@ | pinlist}
 *     Name of pins to be tested.
 *     valid pin types: O,IO
 *   string mode                  {ProgramLoad|PPMU|SPMU|PPMUTerm|SPMUTerm}
 *     ProgramLoad - use programmable load
 *     PPMU        - use PPMU
 *     SPMU        - use SPMU
 *     PPMUTerm    - use PPMU with termination ON
 *     SPMUTerm    - use SPMU with termination ON
 *   string measuredLevel         {LOW,HIGH,BOTH}
 *     LOW         - output low level
 *     HIGH        - output high level
 *     BOTH        - output low and high level
 *   testmethod::SpecValue  forceCurrentLow    {uA}
 *     force current for low levle test, base unit is uA.
 *   testmethod::SpecValue  forceCurrentHigh   {uA}
 *     force current for high levle test, base unit is uA.
 *   testmethod::SpecValue  maxPassLow          {V}
 *     max pass threshold for low level, base unit is V.
 *   testmethod::SpecValue  minPassLow          {V}
 *     min pass threshold for low level, base unit is V.
 *   testmethod::SpecValue  maxPassHigh         {V}
 *     max pass threshold for high level, base unit is V.
 *   testmethod::SpecValue  minPassHigh         {V}
 *     min pass threshold for high level, base unit is V.
 *   testmethod::SpecValue  settlingTimeLow    {ms}
 *     The settling time before PMU/SPMU measurement for low level,
 *     base unit is ms.
 *   testmethod::SpecValue  settlingTimeHigh   {ms}
 *     The settling time before PMU/SPMU measurement for high level,
 *     base unit is ms.
 *   testmethod::SpecValue spmuClampVoltageLow_V  {V}
 *     clamp voltage for spmu measurement for low level, base unit is V.
 *   DOUBLE spmuClampVoltageHigh_V {V}
 *     clamp voltage for spmu measurement for high level, base unit is V.
 *   string vectorRange
 *     vector range to be scanned for low or high output.
 *     valid input format:
 *       number
 *       number1,number2
 *       number1-number2
 *   string output:               {ReportUI | None}
 *     Print message or not.
 *     ReportUI - for debug mode
 *     None     - for production mode
 *
 * @Note:
 *   1. In case of GPF mode and production test, please use 'ProgramLoad' mode,
 *      and look into OutputDCTest::doMeasurementByActiveLoad() to
 *      make some modifications there for high throughput.
 *   2. To use multiport burst label with PMU/SPMU method,
 *      please look into OutputDCTest::doMeasurementByPMU()
 *      and make some modifications there.
 *   3. When working in PinScale system and using the "PPMU" mode, ppmuClamp
 *      by default is set to pass limit low/high each measure level respectively.
 *----------------------------------------------------------------------*
 */
class DC_Test_OutputDC: public testmethod::TestMethod {
protected:
  double _results[4];
  string  pinlist;
  string  mode;
  string  measuredLevel;
  testmethod::SpecValue  forceCurrentLow;
  testmethod::SpecValue  forceCurrentHigh;
  testmethod::SpecValue  maxPassLow;
  testmethod::SpecValue  minPassLow;
  testmethod::SpecValue  maxPassHigh;
  testmethod::SpecValue  minPassHigh;
  testmethod::SpecValue  settlingTimeLow;
  testmethod::SpecValue  settlingTimeHigh;
  testmethod::SpecValue  spmuClampVoltageLow;
  testmethod::SpecValue  spmuClampVoltageHigh;
  string  vectorRange;
  string  output;
  string mTestName;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("result0",
                 "double",
                 &_results[0],
                 testmethod::TM_PARAMETER_OUTPUT)
      .setDefault("0.0");
    addParameter("result1",
                 "double",
                 &_results[1],
                 testmethod::TM_PARAMETER_OUTPUT)
      .setDefault("0.0");
    addParameter("result2",
                 "double",
                 &_results[2],
                 testmethod::TM_PARAMETER_OUTPUT)
      .setDefault("0.0");
    addParameter("result3",
                 "double",
                 &_results[3],
                 testmethod::TM_PARAMETER_OUTPUT)
      .setDefault("0.0");
    addParameter("pinlist",
                 "PinString",
                 &pinlist)
      .setComment("O or IO pins");
    addParameter("mode",
                 "string",
                 &mode)
      .setDefault("ProgramLoad")
      .setOptions("PPMU:SPMU:PPMUTerm:SPMUTerm:ProgramLoad");
    addParameter("measuredLevel",
                 "string",
                 &measuredLevel)
      .setDefault("BOTH")
      .setOptions("LOW:HIGH:BOTH");
    addParameter("forceCurrentLow",
                 "SpecValue",
                 &forceCurrentLow)
      .setDefault("0[uA]")
      .setComment("force current for low level meas., e.g. 10[uA]");
    addParameter("forceCurrentHigh",
                 "SpecValue",
                 &forceCurrentHigh)
      .setDefault("0[uA]")
      .setComment("force current for high level meas., e.g. 100[uA]");
    addParameter("maxPassLow",
                 "SpecValue",
                 &maxPassLow)
      .setDefault("0[V]")
      .setVisible(false)
      .setComment("max pass voltage for low level meas., e.g. 1[V]");
    addParameter("minPassLow",
                 "SpecValue",
                 &minPassLow)
      .setDefault("0[V]")
      .setVisible(false)
      .setComment("min pass voltage for low level meas., e.g. 5[V]");
    addParameter("maxPassHigh",
                 "SpecValue",
                 &maxPassHigh)
      .setDefault("0[V]")
      .setVisible(false)
      .setComment("max pass voltage for high level meas., e.g. 1[V]");
    addParameter("minPassHigh",
                 "SpecValue",
                 &minPassHigh)
      .setDefault("0[V]")
      .setVisible(false)
      .setComment("min pass voltage for high level meas., e.g. 5[V]");
    addParameter("settlingTimeLow",
                 "SpecValue",
                 &settlingTimeLow)
      .setDefault("0[ms]")
      .setComment("settling time for low level meas., e.g. 1[ms]");
    addParameter("settlingTimeHigh",
                 "SpecValue",
                 &settlingTimeHigh)
      .setDefault("0[ms]")
      .setComment("settling time for high level meas., e.g. 1[ms]");
    addParameter("spmuClampVoltageLow",
                 "SpecValue",
                 &spmuClampVoltageLow)
      .setDefault("0[V]")
      .setComment("clamp voltage for spmu meas. for low level, e.g. 1[V]");
    addParameter("spmuClampVoltageHigh",
                 "SpecValue",
                 &spmuClampVoltageHigh)
      .setDefault("0[V]")
      .setComment("clamp voltage for spmu meas. for high level, e.g. 5[V]");
    addParameter("vectorRange",
                 "string",
                 &vectorRange)
      .setComment("vector range to be scanned for low or high output.\n"
    	          "valid input format:\n"
                  "1) number\n"
                  "2) number1,number2\n"
                  "3) number1-number2");
    addParameter("testName",
                 "string",
                 &mTestName)
    .setDefault("("+OutputDcTest::DEFAULT_TESTNAME_LOW+","+OutputDcTest::DEFAULT_TESTNAME_HIGH+")")
    .setComment("(1)\"BOTH\" measurement need two test limits' names in pairs, "
         "pair.first is for low level measurement, no unit means 'V' \n"
         "pair.second is for high level measurement , no unit means 'V'\n"
         "(2)\"LOW\" or \"HIGH\" measurement at least need one test limit.\n"
         "if test table is used, the limit name is defined in table\n"
         "if predefined limit is used, the limit name must be as same as default.");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("None:ReportUI:showFailOnly")
      .setComment("Print message on UI report window if 'ReportUI'");

    addLimit(OutputDcTest::DEFAULT_TESTNAME_LOW);
    addLimit(OutputDcTest::DEFAULT_TESTNAME_HIGH);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
	    /*
	     * Assume all sites' parameters and limit are the same,
	     * here use 'static' direction to keep the content for later reference on all sites.
	     */
	    static OutputDcTest::TestParam param;
	    //static OutputDcTest::TestLimit testLimit;
	    static TestLimitOfTML testLimit;
	    /*
	     * For output dc test with programmeable load, all sites' result are stored in 'result' locally, but not in API.
	     * here use 'static' direction to sustain these values of variables for all sites.
	     */
	    static OutputDcTest::TestResult result;

	      /*
	       * Process all parameters needed in test. Actually this function is
	       * called once under multisite because all input parameters should be
	       * the same through all sites. The processed parameters are stored into
	       * the static variable 'param' for later reference on all sites.
	       */
	    ON_FIRST_INVOCATION_BEGIN();
	      OutputDcTest::processParameters(pinlist,
	                                      measuredLevel,
	                                      forceCurrentLow.getValueAsTargetUnit("uA"),
	                                      forceCurrentHigh.getValueAsTargetUnit("uA"),
	                                      minPassLow.getValueAsTargetUnit("V"),
	                                      maxPassLow.getValueAsTargetUnit("V"),
	                                      minPassHigh.getValueAsTargetUnit("V"),
	                                      maxPassHigh.getValueAsTargetUnit("V"),
	                                      mode,
	                                      settlingTimeLow.getValueAsTargetUnit("ms"),
	                                      settlingTimeHigh.getValueAsTargetUnit("ms"),
	                                      spmuClampVoltageLow.getValueAsTargetUnit("mV"),
	                                      spmuClampVoltageHigh.getValueAsTargetUnit("mV"),
	                                      vectorRange,
	                                      param);

	      /*
	       * Process the limit needed in test. Actually this function is
	       * called once under multisite because all limits should be the
	       * same through all sites. The processed limit are stored into the
	       * static variable 'limit' for later reference on all sites.
	       */
	      //OutputDcTest::processLimit(param,mTestName,testLimit);
	      OutputDcTest::processLimit(param,testLimit,mTestName);

	    ON_FIRST_INVOCATION_END();

	    /*
	     * Execute measurement with the specified 'param' and store results
	     * into the 'result' judged with 'limit'. The multisite handling, i.e.
	     * ON_FIRST_INVOCATION block are executed inside this function.
	     */

	    if (param.mode == "ProgramLoad")
	    {
	      OutputDcTest::doMeasurementByProgramLoad(param,result);
	    }
	    else
	    {
	      OutputDcTest::doMeasurementByPMU(param,testLimit,result);
	    }

	    /*
	     * Judge and datalog based on the 'result'. This function uses
	     * testsuite name as test name, so if you'd like to use your own
	     * test names for judgement and datalogging it's needed to modify
	     * this funciton or create new one.
	     */
//	    OutputDcTest::judgeAndDatalog(param,testLimit,result,_results);

	    /*
	     * Output contents of the 'result' to Report Window if specified by
	     * the "output" parameter.
	     */
//	    OutputDcTest::reportToUI(param,testLimit,output,result);

	    int times = 1; /*measurement times*/
	    int siteNumber;
	    static string suitName, testName;
	    string mUnits;
	    double value = 0.0;
	    LIMIT Limit_PAT;
	    MeasuredLevelType level;
	    ARRAY_D measuredValueArray(param.expandedPins.size());
//	    TM::COMPARE lowCmp, highCmp;
//	    double lowVal,highVal;

	    siteNumber = (param.mode != "ProgramLoad")? 0 : CURRENT_SITE_NUMBER();
	    GET_TESTSUITE_NAME(suitName);
	    testName = suitName;

	    if(param.measuredLevel == "LOW")
	    {
	      level = LOW_LEVEL;
	      times = 1;
	    }
	    else if (param.measuredLevel == "HIGH")
	    {
	      times = 1;
	      level = HIGH_LEVEL;
	    }
	    else /*BOTH*/
	    {
	      level = LOW_LEVEL;
	      times = 2;
	    }

	    for(int i=0; i<times; i++)
	    {
	        for(STRING_VECTOR::size_type index = 0;
	            index < param.expandedPins.size();
	            ++index)
	        {
	          value = result.resultPerSite[level].getPinsValue(param.expandedPins[index],siteNumber);

	          TESTSET().cont(true).judgeAndLog_ParametricTest(param.expandedPins[index],testName,tmLimits, value);
	          if(PAT_compare) PAT_Limit_compare(suitName, testName, param.expandedPins[index], value);
	        }
	    }

	    return ;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
	    if(parameterIdentifier == "mode")
	    {
	      //enable spmu clamp only for SPMU related mode.
	      if (mode == "SPMU" || mode == "SPMUTerm")
	      {
	        getParameter("spmuClampVoltageLow").setEnabled(true);
	        getParameter("spmuClampVoltageHigh").setEnabled(true);
	      }
	      else
	      {
	        getParameter("spmuClampVoltageLow").setEnabled(false);
	        getParameter("spmuClampVoltageHigh").setEnabled(false);
	      }

	      //enable settling time for non-progamableLoad mode.
	      if (mode != "ProgramLoad")
	      {
	        getParameter("settlingTimeLow").setEnabled(true);
	        getParameter("settlingTimeHigh").setEnabled(true);
	      }
	      else
	      {
	        getParameter("settlingTimeLow").setEnabled(false);
	        getParameter("settlingTimeHigh").setEnabled(false);
	      }
	    }
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string getComment() const
  {
    string comment = " please add your comment for this method.";
    return comment;
  }
};
REGISTER_TESTMETHOD("DC_Test.OutputDC", DC_Test_OutputDC);

