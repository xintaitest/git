/*
 * WorkStation_2_Servers.cpp
 *
 *  Created on: Feb 11, 2019
 *      Author: zzhao
 */


#include  <iostream>

using namespace std;

extern "C" void GetDevPath(char *);
#if __GNUC__ >= 3
using namespace std;
#endif

#ifdef __cplusplus
extern "C"
{
#endif

#include  "WorkStation_2_Servers.h"
#include  <sys/socket.h>
#include  <sys/ioctl.h>
#include  <sys/time.h>
#include  <arpa/inet.h>
#include  <malloc.h>
#include  <stdio.h>
#include  <unistd.h>
#include  <sys/types.h>
#include  <netinet/in.h>
#include  <stdlib.h>
#include  <time.h>
#include  <string.h>
#include  <pthread.h>
#include  <errno.h>

#define  SERVER_PORT 7000  //  define the defualt connect port id
#define  LENGTH_OF_LISTEN_QUEUE 10  // length of listen queue in server
#define  BUFFER_SIZE 4096
#define  WELCOME_MESSAGE "welcome to connect the server."
//SPIL SERVER IP
#define  SERVERIP "10.60.95.99"
//#define  SERVERIP "192.168.6.187"
//#define  SERVERIP "10.150.48.68"
#define REMOTE_SERVER_PORT 7001  //define the defualt remote server connect port id
#define LOCAL_PORT  (7002+rand()%58533)
#define KEY_LEN 48
#define MAX_KEY_NUM ((BUFFER_SIZE-12)/ KEY_LEN)


//static char des_key[8]={'w', 'a', 'r','r', 'i', 'o', 'r', 's'};

typedef struct tag_burn_para{
    int clifd;  /*client socket fd*/
}burn_para;

typedef struct tag_burn_packet{
	uint32_t len; //pack len
	uint32_t cmd; //pack cmd
	uint32_t cmd_para; //cmd parameter
	char pdata[0];
}burn_packet;

enum
{
	BURN_CMD_UNKNOW = 0,
	BURN_CMD_REQUEST_KEY,			//1
	BURN_CMD_REPLY_KEY,				//2
	BURN_CMD_CHECK_CALI,		    //3
	BURN_CMD_UPLOAD_RX,				//4
	BURN_CMD_UPLOAD_TX,				//5
	BURN_CMD_DOWNLOAD_RX,			//6
	BURN_CMD_DOWNLOAD_TX,			//7
	BURN_CMD_DOWN_CALI_DATA,		//8
	BURN_CMD_SAVE_ITEM_DATA,		//9
};

int char_length(char *input)
{
	int i;
	for(i = 0; i<512; i++)
	{
		if(*(input+i) == '\0')
		{
			return i;
		}
		else
		{
			i++;
		}
	}
	return -1;
}


bool client_servers(int &clifd)
{
	// add your code
	struct sockaddr_in serv_addr, clin_addr;
	socklen_t sock_len,clin_len;
	sock_len = sizeof(serv_addr);
	clin_len = sizeof(clin_addr);

	//reuse socket address for bind fail issue,comment due to too much waiting time
	//setsockopt(clifd,SOL_SOCKET,SO_REUSEADDR,&socket_on,sizeof(socket_on));

	//creat socket clifd
	//SOCK_STREAM = TCP
	if ((clifd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		printf(" create socket error!\n ");
		cout<<"Error:timeout 0"<<endl;
		return 0;
	}

	srand(time(NULL)); // initialize random generator

	bzero( &clin_addr, sizeof (clin_addr));
	clin_addr.sin_family = AF_INET;
	clin_addr.sin_port = htons(LOCAL_PORT);
	clin_addr.sin_addr.s_addr = htons(INADDR_ANY);
	//INADDR_ANY = 0.0.0.0 = any address
	bzero( &serv_addr, sizeof (serv_addr));
	serv_addr.sin_family = AF_INET;
	inet_aton(SERVERIP, &serv_addr.sin_addr);
	serv_addr.sin_port = htons(REMOTE_SERVER_PORT);

	if (bind(clifd, (struct sockaddr* ) &clin_addr, sizeof (clin_addr)) < 0) //bind address (0.0.0.0)with socket clifd
	{
		if (debug)
		{
			printf("bind error type is %s \n",strerror(errno));
			printf("client bind to port %d failure!\n ", REMOTE_SERVER_PORT);
			cout<<""<<endl;
			//printf("client  bind to port  %d try %d!\n ", REMOTE_SERVER_PORT,100-bind_finish);
			//return 0; //bind wrong fail result bug,ignore bind return result.
		}
	}
	/*
	if (connect(clifd, ( struct sockaddr * ) &serv_addr, sock_len) < 0) { //connect socket clifd to serv_addr 192.168.6.187
		printf("can't connect to %s! ", SERVERIP);
		cout<<""<<endl;
		return 0;
	}
	 */
	//new added
	timeval tm;
	//Set timeout when can not connect to server.
	tm.tv_sec= 2;
	tm.tv_usec = 0;
	unsigned long ul = 1;
	int rm = ioctl(clifd,FIONBIO,&ul);
	if(rm == -1)
	{
		//ioctl failed
		cout<<"Error:timeout 1"<<endl;
		return 0;
	}
	if(connect(clifd,(sockaddr*)&serv_addr,sizeof(sockaddr)) == 0)
	{
		//connect success
		cout<<"Error:timeout 2"<<endl;
		return 0;
	}
	if(errno != EINPROGRESS)
	{
		cout<<"Error:timeout 3"<<endl;
		return 0;
	}
	//
	fd_set writeSet;
	//fd_set readSet;
	FD_ZERO(&writeSet);
	FD_SET(clifd,&writeSet);
	int num = select(clifd + 1,NULL,&writeSet,NULL,&tm);
	if(num > 0)
	{
		if(FD_ISSET(clifd,&writeSet))
		{
			int error = 0;
			int errLen = sizeof(error);
			if(getsockopt(clifd,SOL_SOCKET,SO_ERROR,&error,(socklen_t*)&errLen) < 0)
			{
				cout<<"Error:timeout 4"<<endl;
				return 0;
			}
			if(error != 0)
			{
				cout<<"Error:timeout 5"<<endl;
				return 0;
			}

		}
	}
	else
	{
		cout<<"Error:timeout 6"<<endl;
		return 0;
	}
	//
	ul = 0;
	ioctl(clifd,FIONBIO,&ul);
	return 1;
}


int device_key_request(int &clifd, unsigned char *rev_data)
{
//	#define error_code_byte 1
//	#define chip_ID_byte 12
//	#define OTP_byte 292
//	#define Flash_byte 4096
//	#define buffer_byte 8192

	int ret = 0;
	unsigned char send_data[4] = {0x11,0x22,0x33,0x44};
	int send_data_len = 4;
	int recv_SN_len = 1+12;
	int recv_OTP_len = 292;
	int recv_FLASH_len = 4096;

	//define variables
	unsigned char buf[BUFFER_SIZE];
	unsigned char *buf_ptr;
	int left_length;

	ret = write(clifd, send_data, send_data_len);
	if(ret < send_data_len)
	{
		cout<<"write request magic number error"<<endl;
		return 0;
	}

	memset(buf, 0, BUFFER_SIZE);
	ret = read(clifd, buf, recv_SN_len);
	if(ret < recv_SN_len)
	{
		cout<<"read serial number error"<<endl;
		return 0;
	}
	memcpy(rev_data, buf, recv_SN_len);

	memset(buf, 0, BUFFER_SIZE);
	ret = read(clifd, buf, recv_OTP_len);
	if(ret < recv_OTP_len)
	{
		cout<<"read OTP data error"<<endl;
		return 0;
	}
	memcpy(rev_data+recv_SN_len, buf, recv_OTP_len);

	buf_ptr = buf;
	left_length = BUFFER_SIZE;

	while(left_length > 0)
	{
		ret = read(clifd, buf_ptr, left_length);
		if (ret <= 0)
		{
			cout<<"read FLASH data error"<<endl;
			return 0;
		}
		else
		{
			buf_ptr += ret;
			left_length -= ret;
		}
	}
	memcpy(rev_data+recv_SN_len+recv_OTP_len, buf, recv_FLASH_len);

	for (int i = 0; i < recv_SN_len+recv_OTP_len+recv_FLASH_len; i++)
	{
		printf("%02X", *(rev_data+i));
		if(i%1024 == 0 && i != 0)
		{
			printf("\n");
		}
	}
	printf("\n");

//	memset(buf, 0, BUFFER_SIZE);
//	ret = read(clifd, buf, recv_FLASH_len);
//	if(ret < recv_FLASH_len)
//	{
//		cout<<"read flash0 data error"<<endl;
//		return 0;
//	}
//	memcpy(rev_data+recv_SN_len+recv_OTP_len, buf, recv_FLASH_len);
//
//	memset(buf, 0, BUFFER_SIZE);
//	ret = read(clifd, buf, recv_FLASH_len);
//	if(ret < recv_FLASH_len)
//	{
//		cout<<"read flash1 data error"<<endl;
//		return 0;
//	}
//	memcpy(rev_data+recv_SN_len+recv_OTP_len+recv_FLASH_len, buf, recv_FLASH_len);
//
//	memset(buf, 0, BUFFER_SIZE);
//	ret = read(clifd, buf, recv_FLASH_len);
//	if(ret < recv_FLASH_len)
//	{
//		cout<<"read flash2 data error"<<endl;
//		return 0;
//	}
//	memcpy(rev_data+recv_SN_len+recv_OTP_len+recv_FLASH_len*2, buf, recv_FLASH_len);
//
//	memset(buf, 0, BUFFER_SIZE);
//	ret = read(clifd, buf, recv_FLASH_len);
//	if(ret < recv_FLASH_len)
//	{
//		cout<<"recv length = "<<ret<<endl;
//		cout<<"read flash3 data error"<<endl;
//		return 0;
//	}
//	memcpy(rev_data+recv_SN_len+recv_OTP_len+recv_FLASH_len*3, buf, recv_FLASH_len);

	return 1;
}

int write_feedback_data(int &clifd, unsigned char *write_data)
{
	int ret = 0;
	int send_data_len = 22;

	ret = write(clifd, write_data, send_data_len);
	if(ret < send_data_len)
	{
		cout<<"write feedback data error"<<endl;
		return 0;
	}

	return 1;
}


#ifdef __cplusplus
}
#endif

