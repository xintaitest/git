hp93000,pattern_master_file,0.1

path:
../vectors

files:
flash_chip_erase_update
m300h_pullup.binl
m300h_pulldown.binl
bscan_pattern_0104.binl
flash_prgm_ff
flash_prgm_00
scan_comp.binl
-- scan_basic.binl
scan_chain.binl
-- scan_comp.binl
-- scan_basic.binl
mbist_pll_pattern.binl.gz
-- FunctionalTest_4040_GPIO_Flag.binl.gz
-- Functiona_Test_4040.binl.gz
-- FunctionalTest.binl.gz
-- Functiona_Test_4040_NoSM2.binl.gz
-- FunctionalRead.binl.gz
FunctionalTest_7758.binl.gz
PeakCurrentTest_7758.binl.gz
-- StressTest_7758.binl.gz
-- StressRead_7758.binl.gz
read_flash_nvr0_addr_0x0002
read_flash_nvr0_addr_0x0001
write_flash_nvr0_addr_0x0002
write_flash_nvr0_addr_0x0001
pad_all_pullmode_off.binl
Functional_BIST_Result
Functional_BIST_Run
Functional_BIST_IDD
Functional_BIST
-- FunctionalTest.binl.gz
reset
pll_OSC_pattern.binl.gz
osc_pattern_avc_debug
osc_pattern_fun
osc_pattern_avc.binl.gz
boot_UART
jtag_misc_set_0
jtag_access_misc.binl
Functional_Boot
PLL_Test
write_flash_nvr0_addr_0x0000.binl.gz
read_flash_nvr0_addr_0x0000.binl.gz
VDD_trimming_pattern
TS_trimming_pattern
flash_program_redundancy_sectors
flash_program_redundancy_sector_1
flash_program_one_sector_high.binl.gz
flash_program_one_sector_low.binl.gz
flash_program_one_sector.binl.gz
flash_program_sector_505.binl.gz
flash_program_sector_506.binl.gz
flash_program_sector_507.binl.gz
flash_program_sector_508.binl.gz
flash_program_sector_509.binl.gz
flash_program_sector_510.binl.gz
flash_program_sector_511.binl.gz
flash_program_sector_512.binl.gz
flash_rd_i_ckbd_burst
flash_rd_ckbd_burst
flash_rd_i_ckbd_sector
flash_rd_i_ckbd_start
flash_rd_ckbd_sector
flash_rd_ckbd_start
flash_rd_0xff_sector
flash_rd_0xff_start
flash_rd_0xff_burst
flash_rd_0x00_burst
flash_rd_0x00_start
flash_rd_0x00_sector
flash_rd_0x00
flash_rd_i_ckbd
flash_prgm_i_ckbd
flash_rd_ckbd
flash_prgm
flash_prgm_ckbd
flash_rd_ff
boot_room
Walking_Z
flash_nvr2_read.binl.gz
flash_chip_erase.binl.gz
FLASH_load_trimming_bit.binl.gz
flash_nvr0_erase.binl.gz
flash_nvr1_erase.binl.gz
FLASH_set_BUKPR.binl.gz
FLASH_set_fastmode_threshold_high.binl.gz
FLASH_set_fastmode_threshold_low.binl.gz
write_CP1_Flag.binl.gz
write_CP2_Flag.binl.gz
write_CP3_Flag.binl.gz
write_FT1_Flag.binl.gz
write_FT2_Flag.binl.gz
read_flash_nvr2_redundancy_info.binl.gz
write_flash_nvr2_redundancy_info.binl.gz
chip_init_pattern.binl.gz
bscan_pattern.binl
mbist_slow_pattern.binl.gz
sensor_pattern.binl.gz


