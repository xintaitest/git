@a=<*.avc>;
open OUT, ">filename.txt";
foreach $filename(@a){
$_ = $filename;
s/\.avc//;
print OUT "$_			\@			$_.avc		Mizar_M300.tmf		{ -w \"Normal_wt\" }\n";
}
