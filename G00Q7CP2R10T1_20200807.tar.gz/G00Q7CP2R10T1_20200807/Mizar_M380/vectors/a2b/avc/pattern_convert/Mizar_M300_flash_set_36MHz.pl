###############################################################################
#  Company: ThinkTech
#  Author: zzhao
#  Date: 2018.9.19
#  Version: 1.0
#  Function Description:
#     Create FLASH SPI read & write avc file for Mizar M300
#
###############################################################################
use POSIX;
mkdir all_avc;
my $DIG_CAP=0;
my $sig_cnt=6;
my $clock_stage=0;
my $isNVR=0;
my $isTMEN=0;	
my $isFlash0=1;
my %signals;
my $pattern_start = 0;
my $transfer_bin_to_avc_FLASH;
my $transfer_bin_to_avc_OTP;
my $SPI_spead = 10000000;
my $frequency = 10000000;
my $period = 50;
my $repeat = 68;
my $op_byte = 56216;
my @array_hex;
my @array_bin;

#GPIO0,GPIO1,TRST,TCK,TMS,TDI,TDO,XTAL_IN
$signals{1}={
	"name"=>"TMS",
	"data"=>"1"
};
$signals{2}={
	"name"=>"TCK",
	"data"=>"P"
};
$signals{3}={
	"name"=>"TDI",
	"data"=>"0"
};
$signals{4}={
	"name"=>"DTO",
	"data"=>"X"
};
$signals{5}={
	"name"=>"TRST",
	"data"=>"1"
};
$signals{6}={
	"name"=>"XTAL_IN",
	"data"=>"0"
};


###Main Function-Register Write&Read#################
open(LIST, "pattern_list.txt")||die "Can't create $outfile! $@\n";
while(<LIST>){
if(/\#/){
next;
}
if(/pattern_name:(\w+)/){
	$pat_name=$1;
	}
if(/write_FLASH:(0x\w+)\/0x(\w+)/){
	$addr=$1;
	$data=$2;
  $write_FLASH=1;
	}
if(/read_FLASH:(0x\w+)\/0x(\w+)/){
	$addr=$1;
	$data=$2;
  $read_FLASH=1;
	}
if(/write_FLASH_NVR2:(0x\w+)\/0x(\w+)/){
	$addr=$1;
	$data=$2;
  $write_FLASH_NVR2=1;
	}
if(/FLASH_set_reg:0x(\w+)\/0x(\w+)/){
	$addr=$1;
	$data=$2;
  $FLASH_set_reg=1;
	}
if(/flash_sector_erase:(0x\w+)/){
	$flash_sector_erase = 1;
	$addr=$1;
	}
if(/flash_NVR_sector_erase:(0x\w+)/){
	$flash_NVR_sector_erase = 1;
	$addr=$1;
	}
if(/JTAG_stop/){
  $JTAG_stop=1;
	}
if(/load_bin_file/){
  $load_bin_file=1;
	}
if(/transfer_bin_to_avc_FLASH/){
	$transfer_bin_to_avc_FLASH = 1;
}
if(/transfer_bin_to_avc_OTP/){
	$transfer_bin_to_avc_OTP = 1;
}
if(/read_FLASH_bin/){
	$read_FLASH_bin = 1;
}
if(/read_OTP_bin/){
	$read_OTP_bin = 1;
}
if(/flash_chip_erase/){
	$flash_chip_erase = 1;
}
if(/flash_erase_nvr2_sector/){
	$flash_erase_nvr2_sector = 1;
}
if(/read_flash_by_sector/){
	$read_flash_by_sector = 1;
}
if(/testmode_read_FLASH/){
	$testmode_read_FLASH = 1;
}

&create_pat($pat_name,$addr,$data,$write_FLASH,$read_FLASH,$write_FLASH_NVR2,$FLASH_set_reg,$JTAG_stop,$load_bin_file,$read_FLASH_bin,$read_OTP_bin,$flash_chip_erase,$flash_erase_nvr2_sector,$flash_sector_erase,$flash_NVR_sector_erase,$read_flash_by_sector,$testmode_read_FLASH);
  $pat_name="";
  $addr="";
  $data="";
  $write_FLASH=0;
  $read_FLASH=0;
  $write_FLASH_NVR2=0;
  $FLASH_set_reg=0;
  $JTAG_stop=0;
  $load_bin_file=0;
  $flash_chip_erase=0;
  $flash_erase_nvr2_sector=0;
  $transfer_bin_to_avc_FLASH = 0;
  $transfer_bin_to_avc_OTP = 0;
  $read_FLASH_bin = 0;
  $read_OTP_bin = 0;
  $flash_sector_erase=0;
  $flash_NVR_sector_erase=0;
  $read_flash_by_sector=0;
  $testmode_read_FLASH=0;
}

close LIST;
###End Main Function##################################

sub create_pat(){
my $pat_name=shift;
my $addr=shift;
my $data=shift;
my $write_FLASH=shift;
my $read_FLASH=shift;
my $write_FLASH_NVR2=shift;
my $FLASH_set_reg=shift;
my $JTAG_stop=shift;
my $load_bin_file=shift;
my $read_FLASH_bin=shift;
my $read_OTP_bin=shift;
my $flash_chip_erase=shift;
my $flash_erase_nvr2_sector=shift;
my $flash_sector_erase=shift;
my $flash_NVR_sector_erase=shift;
my $read_flash_by_sector=shift;
my $testmode_read_FLASH=shift;


   $addr_cm=$addr;
   $data_cm=$data;
   $my_addr_cm=$addr;
   $my_data_cm=$data;
   $addr=hex $addr_cm;
   $data=hex $data_cm;
if($pat_name ne ""){
  $outfile=${pat_name}.".avc";
  open(OUT, ">./all_avc/$outfile")||die "Can't create $outfile! $@\n";
  &print_head;
  $pattern_start = 0;
  #&JTAG_stop();  
}
elsif(($addr_cm ne "") && ($write_FLASH==1)){
  &write_FLASH($addr,$data_cm);
}
elsif(($addr_cm ne "") && ($read_FLASH==1)){
  &read_FLASH($addr,$data_cm);
}
elsif(($addr_cm ne "") && ($write_FLASH_NVR2==1)){
  &write_FLASH_NVR2($addr,$data_cm);
}
elsif(($addr_cm ne "") && ($FLASH_set_reg==1)){
  &FLASH_set_reg($addr,$data_cm);
}
elsif( $JTAG_stop == 1){
	&JTAG_stop();
}
elsif( $load_bin_file == 1){
	&load_bin_file();
}
elsif($transfer_bin_to_avc_FLASH == 1){
  &transfer_bin_to_avc_FLASH();
}
elsif($transfer_bin_to_avc_OTP == 1){
  &transfer_bin_to_avc_OTP();
}
elsif($read_FLASH_bin == 1){
  &read_FLASH_bin();
}
elsif($read_OTP_bin == 1){
  &read_OTP_bin();
}
elsif($flash_chip_erase == 1){
  &flash_chip_erase();
}
elsif($flash_erase_nvr2_sector == 1){
  &flash_erase_nvr2_sector();
}
elsif($flash_sector_erase == 1){
  &sector_erase_flash($addr);
}
elsif($flash_NVR_sector_erase == 1){
  &flash_NVR_sector_erase($addr);
}
elsif($read_flash_by_sector == 1){
  &read_flash_by_sector();
}
elsif($testmode_read_FLASH == 1){
  &testmode_read_FLASH();
}

##close(OUT);
}

sub print_head(){
  print OUT "DEFAULT_STATE RST_N,DFT_TEST_EN,GPIO0,I2C1_SDA CLK_SEL;\n";
  print OUT "\@ ", " 1 1 0 1 1;\n";
  print OUT "DEFAULT_STATE SPI3_SCS,UART0_RX,UART0_TX,UART1_RX,UART1_TX,I2C0_SCL,I2C0_SDA,I2C1_SCL,GPIO1,GPIO2,GPIO3,GPIO4,GPIO5,GPIO6,GPIO7,SPI0_SCLK,SPI0_SI,SPI0_SO,SPI0_SCS,SPI1_SCLK,SPI1_SI,SPI1_SO,SPI1_SCS,SPI2_SCLK,SPI2_SI,SPI2_SO,SPI2_SCS,SPI3_SCLK,SPI3_SI,SPI3_SO,XTAL_OUT,TEST_IBP, TEST_VBG;\n";
  print OUT "\@ ", " Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z;\n";
  print OUT "FORMAT TMS TCK TDI TDO TRST XTAL_IN;\n";
}

sub print_line(){
	$signals{6}{"data"} = !$signals{6}{"data"};
	if($signals{6}{"data"} != 1)
	{
		$signals{6}{"data"} = 0;
	}
  $comment=shift;
  if ($pattern_start == 1)
  {
  	  print OUT "R100 functional";
  	  $pattern_start = 0;
  } else {
  		print OUT "R1 functional";
  }
  for(my$i=1;$i<=$sig_cnt;$i++){
    print OUT " ",$signals{$i}{"data"};
  }
  print OUT " $comment;\n";
  $comment="";
}

sub print_wait_line(){
  $comment=shift;
	
  print OUT "R100000 functional";
  
  for(my$i=1;$i<=$sig_cnt;$i++){
    print OUT " ",$signals{$i}{"data"};
  }
  print OUT " $comment;\n";
  $comment="";
}

sub print_n_line(){
  $comment=shift;
  $line_count = shift;

  print OUT "R${line_count} functional";

  for(my$i=1;$i<=$sig_cnt;$i++){
    print OUT " ",$signals{$i}{"data"};
  }
  print OUT " $comment;\n";
  $comment="";

	#while($line_count--)
	#{
  #	print OUT "R1 functional";
  #	for(my$i=1;$i<=$sig_cnt;$i++){
  #  	print OUT " ",$signals{$i}{"data"};
  #	}
	#	print OUT " $comment;\n";
	#	$comment="";
  #}
}

sub SPI_start(){
   my $v1=shift;
   my $v2=shift;
   my $v3=shift;
   if($v3 ne ""){
    $comment="start ".$v3." addr:".$v1.", data:".$v2;
    #$operation ="$v3 ";
    #$sub_address = "$v1 ";
    #$sub_data = "$v2 ";
  }
	$signals{1}{"data"}="1";
	$signals{2}{"data"}="P";
	$signals{3}{"data"}="0";
	$signals{4}{"data"}="X";
	$signals{4}{"data"}="X";
	&print_line("$comment");
  #&print_line("");
  #&print_line("");
	#&print_line("");
}

sub SPI_read_start(){
   my $v1=shift;
   my $v2=shift;
   my $v3=shift;
   my $bin=shift;
   if($v3 ne ""){
    $comment="start ".$v3." addr:".$v1.", data:".$v2." bit0";
    #$operation ="$v3 ";
    #$sub_address = "$v1 ";
    #$sub_data = "$v2 ";
  }
  $bit0==substr($bin,71,1);
	$signals{1}{"data"}="1"; #TMS
	$signals{2}{"data"}="P";
	$signals{3}{"data"}="0";
	if($bit0==1) {
		$signals{4}{"data"}="H";
	} else {
		$signals{4}{"data"}="L";
	}
	&print_line("$comment");
  #&print_line("");
  #&print_line("");
	#&print_line("");
}

sub JTAG_stop(){
	$signals{1}{"data"}="1";
	$signals{2}{"data"}="P";
	$signals{3}{"data"}="0";
	$signals{4}{"data"}="X";
	#&print_line("");
	#&print_line("");
	&print_line("JTAG Stop");
	&print_line("");
	#&print_line("");
	#&print_line("");
	#&print_line("");
	#&print_line("");
}

sub read_FLASH(){
	
  my $read_addr=shift;
  my $read_data=shift;
  
	&read_flash_initial($read_addr,$read_data);
	&read_flash_address($read_addr,$read_data);

}

sub read_flash_sector(){
	my $sector = shift;
	my $read_data = "ffffffffffffffff";

	for($addr=0; $addr<128; $addr++)
	{
		&read_flash_72bit($sector*128+$addr,$read_data);
	}
}


sub testmode_read_FLASH(){
	
  my $read_addr=shift;
  my $read_data=shift;
  
	&enter_read_flash_mode();
	
	&read_flash_sector(0);
}


sub read_OTP(){
	
  my $read_addr=shift;
  my $read_data=shift;

  #original
  my $ce_oe_we = 0x7;
  my $control = 0x000;
  my $end_config = 0x280;
  &SPI_OTP_write_data($read_addr,$read_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x4;
  my $control = 0x000;
  &SPI_OTP_write_data($read_addr,$read_data, $ce_oe_we, $control, $end_config);

  &read_flash_32bit($read_addr,$read_data);
  &JTAG_stop();
}

sub SPI_write_byte(){
	my $dec=shift;
	my $dec_hex=unpack("H2",pack("C",$dec));
     $bin=unpack("B8",pack("C",$dec));
      for($i=0;$i<=7;$i++) {
      	 $bit_num=7-$i;
         $bit=substr($bin,$i,1);
         $signals{1}{"data"}="0";
         $signals{2}{"data"}="P";
         $signals{3}{"data"}=$bit;
         $signals{4}{"data"}="X";
         if ($i == 0) {
         	  &print_line("0x${dec_hex} bit${bit_num}=$bit");
            } else {
              &print_line("bit${bit_num}=$bit");
              }
      }
      ###end of byte
			$signals{1}{"data"}="0";
			$signals{2}{"data"}="P";
			$signals{3}{"data"}="0";
			$signals{4}{"data"}="X";
      &print_line("");
}

sub SPI_read_byte(){
	my $dec=shift;
	my $dec_hex=unpack("H2",pack("C",$dec));
     $bin=unpack("B8",pack("C",$dec));
      for($i=0;$i<=7;$i++) {
      	 $bit_num=7-$i;
         $bit=substr($bin,$i,1);
         if ($bit eq "0"){$bit="L",$bit_state="0";}
         elsif($bit eq "1"){$bit="H",$bit_state="1";}
         $signals{1}{"data"}="0";
         $signals{2}{"data"}="P";
         $signals{3}{"data"}=$bit;
         $signals{4}{"data"}="X";
         if($DIG_CAP==1) {
          $signals{3}{"data"}="C";
         }
         if ($i == 0) {
         	  &print_line("0x${dec_hex} bit${bit_num}=$bit");
         } else {
         	&print_line("bit${bit_num}=$bit");
         }
      }
      ###end of byte
			$signals{1}{"data"}="0";
			$signals{2}{"data"}="P";
			$signals{3}{"data"}="0";
			$signals{4}{"data"}="X";
      &print_line("");
}


sub SPI_ce_oe_we(){
	my $bit_length = 3-1;
	my $bit_full_length = 8-1;
	my $dec=shift;
	my $dec_hex=unpack("H2",pack("C",$dec));
	$bin=unpack("B8",pack("C",$dec));
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("ce_oe_we 0x${dec_hex} bit${bit_num}=$bit");
  		} else {
  	  	&print_line("ce_oe_we bit${bit_num}=$bit");
  	  }
	}
}

sub SPI_control(){
	my $bit_length = 10-1;
	my $bit_full_length = 16-1;
	my $dec=shift;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	
	my $dec_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	$bin=unpack("B16",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("control 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("control bit${bit_num}=$bit");
  	}
	}
}

sub SPI_control_bitX(){
	my $dec=shift;
	my $control_bit = shift;
	my $bit_length = $control_bit-1;
	my $bit_full_length = 16-1;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	
	my $dec_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	$bin=unpack("B16",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("control 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("control bit${bit_num}=$bit");
  	}
	}
}

sub SPI_address_16bit(){
  my $write_addr=shift;
  my $bit_length = 16-1;
	my $bit_full_length = 16-1;
	
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
  
	my $dec_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	$bin=unpack("B16",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("address 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("address bit${bit_num}=$bit");
  	}
	}
}

sub SPI_address_12bit(){
  my $write_addr=shift;
  my $bit_length = 12-1;
	my $bit_full_length = 16-1;
	
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
  
	my $dec_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	$bin=unpack("B16",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("address 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("address bit${bit_num}=$bit");
  	}
	}
}

sub data_output_with_ecc(){
	my $write_data=shift;
	
	my $dec_byte1=substr($write_data,14,2);
	my $dec_byte2=substr($write_data,12,2);
	my $dec_byte3=substr($write_data,10,2);
	my $dec_byte4=substr($write_data,8,2);
	my $dec_byte5=substr($write_data,6,2);
	my $dec_byte6=substr($write_data,4,2);
	my $dec_byte7=substr($write_data,2,2);
	my $dec_byte8=substr($write_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	$dec_byte5 = hex($dec_byte5);
	$dec_byte6 = hex($dec_byte6);
	$dec_byte7 = hex($dec_byte7);
	$dec_byte8 = hex($dec_byte8);
	$dec_byte9 = hex($dec_byte9);
	
	my $word0 = hex(substr($write_data,8,8));
	my $word1 = hex(substr($write_data,0,8));
	my $dec_byte9=&genecc($word0,$word1);
	
	my $dec_hex=unpack("H18",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
	print OUT "$dec_hex\n";
}

sub SPI_data_72bit(){
  my $write_data=shift;
  my $bit_length = 72-1;
	my $bit_full_length = 72-1;


	my $dec_byte1=substr($write_data,14,2);
	my $dec_byte2=substr($write_data,12,2);
	my $dec_byte3=substr($write_data,10,2);
	my $dec_byte4=substr($write_data,8,2);
	my $dec_byte5=substr($write_data,6,2);
	my $dec_byte6=substr($write_data,4,2);
	my $dec_byte7=substr($write_data,2,2);
	my $dec_byte8=substr($write_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	$dec_byte5 = hex($dec_byte5);
	$dec_byte6 = hex($dec_byte6);
	$dec_byte7 = hex($dec_byte7);
	$dec_byte8 = hex($dec_byte8);
	$dec_byte9 = hex($dec_byte9);
	
	my $word0 = hex(substr($write_data,8,8));
	my $word1 = hex(substr($write_data,0,8));
	my $dec_byte9=&genecc($word0,$word1);
	
	my $dec_hex=unpack("H18",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	my $bin=unpack("B72",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("data 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("data bit${bit_num}=$bit");
  	}
	}
}

sub read_flash_72bit(){
	my $read_addr=shift;
	my $read_data=shift;
  my $bit_length = 72-1;
	my $bit_full_length = 72-1;

	my $dec_byte1=substr($read_data,14,2);
	my $dec_byte2=substr($read_data,12,2);
	my $dec_byte3=substr($read_data,10,2);
	my $dec_byte4=substr($read_data,8,2);
	my $dec_byte5=substr($read_data,6,2);
	my $dec_byte6=substr($read_data,4,2);
	my $dec_byte7=substr($read_data,2,2);
	my $dec_byte8=substr($read_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	$dec_byte5 = hex($dec_byte5);
	$dec_byte6 = hex($dec_byte6);
	$dec_byte7 = hex($dec_byte7);
	$dec_byte8 = hex($dec_byte8);
	$dec_byte9 = hex($dec_byte9);
	
	my $word0 = hex(substr($read_data,8,8));
	my $word1 = hex(substr($read_data,0,8));
	my $dec_byte9=&genecc($word0,$word1);
	
	my $dec_hex=unpack("H18",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	my $bin=unpack("B72",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
	my $dec=$read_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="1";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	if($DIG_CAP==1){
  		$signals{4}{"data"}="C";
  	} else {
  		if($bit=="1"){
  			$signals{4}{"data"}="H";
  		} else {
  			$signals{4}{"data"}="L";
  		}
  	}
  	  	
  	if ($i == 0) {
  		&print_line("read addr 0x${address_hex}, data 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("data bit${bit_num}=$bit");
  	}
	}
}

sub read_flash_32bit(){
	my $read_addr=shift;
	my $read_data=shift;
  my $bit_length = 32-1;
	my $bit_full_length = 32-1;

	my $dec_byte1=substr($read_data,6,2);
	my $dec_byte2=substr($read_data,4,2);
	my $dec_byte3=substr($read_data,2,2);
	my $dec_byte4=substr($read_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	
	my $word = hex(substr($read_data,0,8));
	
	my $dec_hex=unpack("H8",pack("C4",$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	my $bin=unpack("B32",pack("C4",$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
	my $dec=$read_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="1";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	if($DIG_CAP==1){
  		$signals{4}{"data"}="C";
  	} else {
  		if($bit=="1"){
  			$signals{4}{"data"}="H";
  		} else {
  			$signals{4}{"data"}="L";
  		}
  	}
  	  	
  	if ($i == 0) {
  		&print_line("read addr 0x${address_hex}, data 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("data bit${bit_num}=$bit");
  	}
	}
}

sub SPI_data_64bit(){
  my $write_data=shift;
  my $bit_length = 64-1;
	my $bit_full_length = 64-1;

	my $dec_byte1=substr($write_data,14,2);
	my $dec_byte2=substr($write_data,12,2);
	my $dec_byte3=substr($write_data,10,2);
	my $dec_byte4=substr($write_data,8,2);
	my $dec_byte5=substr($write_data,6,2);
	my $dec_byte6=substr($write_data,4,2);
	my $dec_byte7=substr($write_data,2,2);
	my $dec_byte8=substr($write_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	$dec_byte5 = hex($dec_byte5);
	$dec_byte6 = hex($dec_byte6);
	$dec_byte7 = hex($dec_byte7);
	$dec_byte8 = hex($dec_byte8);
	
	my $word0 = hex(substr($write_data,8,8));
	my $word1 = hex(substr($write_data,0,8));
	#my $dec_byte9=&genecc($word0,$word1);
	
	my $dec_hex=unpack("H16",pack("C8",$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	my $bin=unpack("B64",pack("C8",$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("data 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("data bit${bit_num}=$bit");
  	}
	}
}

sub SPI_data_32bit(){
  my $write_data=shift;
  my $bit_length = 32-1;
	my $bit_full_length = 32-1;


	my $dec_byte1=substr($write_data,6,2);
	my $dec_byte2=substr($write_data,4,2);
	my $dec_byte3=substr($write_data,2,2);
	my $dec_byte4=substr($write_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	
	my $word0 = hex(substr($write_data,0,8));
	
	my $dec_hex=unpack("H8",pack("C4",$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	my $bin=unpack("B32",pack("C4",$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("data 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("data bit${bit_num}=$bit");
  	}
	}
}

sub genecc()
{
	$data0 = shift;
	$data1 = shift;
  $C0x     = 0xCB4B34E9;
  $C01     = 0xAAAAAAD5;
  $C02     = 0x999999B3;
  $C04     = 0x8787878F;
  $C08     = 0x7F807F80;
  $C016    = 0x007FFF80;
  $C032    = 0xFFFFFF80;
  $C064    = 0x0000007F;
  $C1x     = 0xED3A65B4;
  $C11     = 0xDAB5556A;
  $C12     = 0xB66CCCD9;
  $C14     = 0x71E3C3C7;
  $C18     = 0x0FE03FC0;
  $C116    = 0x001FFFC0;
  $C132    = 0x0000003F;
  $C164    = 0x00000000;
  $ecc;

	$eccout00 = $data0 & $C0x;
	$eccout01 = $data0 & $C01;
	$eccout02 = $data0 & $C02;
	$eccout03 = $data0 & $C04;
	$eccout04 = $data0 & $C08;
	$eccout05 = $data0 & $C016;
	$eccout06 = $data0 & $C032;
	$eccout07 = $data0 & $C064;

	$eccout10 = $data1 & $C1x;
	$eccout11 = $data1 & $C11;
	$eccout12 = $data1 & $C12;
	$eccout13 = $data1 & $C14;
	$eccout14 = $data1 & $C18;
	$eccout15 = $data1 & $C116;
	$eccout16 = $data1 & $C132;
	$eccout17 = $data1 & $C164;

  for ($i = 1, $tmp = ($eccout00 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout00 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout10); $i < 32; $i++, $tmp >>= 1) {
    $eccout00 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout01 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout01 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout11); $i < 32; $i++, $tmp >>= 1) {
    $eccout01 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout02 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout02 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout12); $i < 32; $i++, $tmp >>= 1) {
    $eccout02 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout03 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout03 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout13); $i < 32; $i++, $tmp >>= 1) {
    $eccout03 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout04 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout04 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout14); $i < 32; $i++, $tmp >>= 1) {
    $eccout04 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout05 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout05 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout15); $i < 32; $i++, $tmp >>= 1) {
    $eccout05 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout06 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout06 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout16); $i < 32; $i++, $tmp >>= 1) {
    $eccout06 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout07 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout07 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout17); $i < 32; $i++, $tmp >>= 1) {
    $eccout07 ^= $tmp;
  }

	$ecc = ($eccout00 & 0x1) | (($eccout01 & 0x1) << 1) | (($eccout02 & 0x1) << 2) | (($eccout03 & 0x1) << 3) |
        (($eccout04 & 0x1) << 4) | (($eccout05 & 0x1) << 5) | (($eccout06 & 0x1) << 6) | (($eccout07 & 0x1) << 7);
        
  return $ecc;
}

sub SPI_end_config(){
	my $bit_length = 12-1;
	my $bit_full_length = 16-1;
	my $dec=shift;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	
	my $dec_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	$bin=unpack("B16",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("end config 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("end config bit${bit_num}=$bit");
  	}
	}
}

sub SPI_end_config_bitX(){
	my $dec=shift;
	my $config_bit=shift;
	my $bit_length = $config_bit-1;
	my $bit_full_length = 16-1;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	
	my $dec_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	$bin=unpack("B16",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("end config 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("end config bit${bit_num}=$bit");
  	}
	}
}

sub SPI_wait_time(){
  my $wait_time=shift;
  my $wait_cycle = $wait_time/$period;
	my $wait_cycle = ceil($wait_cycle);
	
	$signals{1}{"data"}="1";
  $signals{2}{"data"}="P";
  $signals{3}{"data"}="0";
  $signals{4}{"data"}="X";
	
  print OUT "R$wait_cycle functional";
  
  for(my$i=1;$i<=$sig_cnt;$i++){
    print OUT " ",$signals{$i}{"data"};
  }
  print OUT " wait $wait_time ns;\n";
  $comment="";
}

sub SPI_print_n_line(){
  my $n_line=shift;
  my $wait_time = $n_line*$period;
  
  print OUT "R$n_line functional";
  
  for(my$i=1;$i<=$sig_cnt;$i++){
    print OUT " ",$signals{$i}{"data"};
  }
  print OUT " wait $wait_time ns;\n";
  $comment="";
}

sub SPI_FLASH_write_data(){
  my $write_addr=shift;
  my $write_data=shift;
  my $ce_oe_we = shift;
  my $control = shift;
  my $end_config = shift;
  my $control_bit = 10;
  my $config_bit = 12;
  $control=$control|($isNVR<<6);
  $control=$control|($isTMEN<<7);
  
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));

  &SPI_start("0x$address_hex","0x$write_data","write");
	&SPI_ce_oe_we($ce_oe_we);
	&SPI_control_bitX($control, $control_bit);
	&SPI_address_16bit($write_addr);
	&SPI_data_72bit($write_data);
	&SPI_end_config_bitX($end_config, $config_bit);
	&JTAG_stop();
}

sub SPI_FLASH_write_data_without_stop(){
  my $write_addr=shift;
  my $write_data=shift;
  my $ce_oe_we = shift;
  my $control = shift;
  my $end_config = shift;
  my $control_bit = 10;
  my $config_bit = 12;
  $control=$control|($isNVR<<6);
  $control=$control|($isTMEN<<7);
  
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));

  &SPI_start("0x$address_hex","0x$write_data","write");
	&SPI_ce_oe_we($ce_oe_we);
	&SPI_control_bitX($control, $control_bit);
	&SPI_address_16bit($write_addr);
	&SPI_data_72bit($write_data);
	&SPI_end_config_bitX($end_config, $config_bit);
	#&JTAG_stop();
}

sub SPI_FLASH_write_data_with_read(){
  my $write_addr=shift;
  my $write_data=shift;
  my $read_data=shift;
  my $ce_oe_we = shift;
  my $control = shift;
  my $end_config = shift;
  my $control_bit = 10;
  my $config_bit = 12;
  $control=$control|($isNVR<<6);
  $control=$control|($isTMEN<<7);
  
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	
	#analysis pre-write data
	my $dec_byte1=substr($read_data,14,2);
	my $dec_byte2=substr($read_data,12,2);
	my $dec_byte3=substr($read_data,10,2);
	my $dec_byte4=substr($read_data,8,2);
	my $dec_byte5=substr($read_data,6,2);
	my $dec_byte6=substr($read_data,4,2);
	my $dec_byte7=substr($read_data,2,2);
	my $dec_byte8=substr($read_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	$dec_byte5 = hex($dec_byte5);
	$dec_byte6 = hex($dec_byte6);
	$dec_byte7 = hex($dec_byte7);
	$dec_byte8 = hex($dec_byte8);
	$dec_byte9 = hex($dec_byte9);
	
	my $word0 = hex(substr($read_data,8,8));
	my $word1 = hex(substr($read_data,0,8));
	my $dec_byte9=&genecc($word0,$word1);
	
	my $dec_hex=unpack("H18",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	my $bin=unpack("B72",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
  &SPI_read_start("0x$address_hex","0x$read_data","read", $bit);
	&SPI_ce_oe_we($ce_oe_we);
	&SPI_control_bitX($control, $control_bit);
	&SPI_address_16bit($write_addr);
	&SPI_data_72bit($write_data);
	&SPI_end_config_bitX($end_config, $config_bit);
	#&JTAG_stop();
}

sub SPI_OTP_write_data(){
	
	my $write_addr=shift;
  my $write_data=shift;
  my $ce_oe_we = shift;
  my $control = shift;
  my $end_config = shift;
  my $control_bit = 11;
  my $config_bit = 12;
  $control=$control|($isNVR<<4);
  
  #print OUT "control:$control ;\n";
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	
  &SPI_start("0x$address_hex","0x$write_data","write");
	&SPI_ce_oe_we($ce_oe_we);
	&SPI_control_bitX($control, $control_bit);
	&SPI_address_12bit($write_addr);
	&SPI_data_32bit($write_data);
	&SPI_end_config_bitX($end_config, $config_bit);
	&JTAG_stop();
}

sub enter_read_flash_mode(){
  my $write_addr=shift;
  my $write_data=shift;

  #original
  my $ce_oe_we = 0x7;
  my $control = 0x100;
  my $end_config = 0x008;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub read_flash_initial(){
  my $write_addr=shift;
  my $write_data=shift;

  #original
  my $ce_oe_we = 0x7;
  my $control = 0x100;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#read address
	my $ce_oe_we = 0x4;
  my $control = 0x100;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#read address
	my $ce_oe_we = 0x4;
  my $control = 0x100;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
}

sub read_flash_address(){
  my $next_addr=shift;
  my $read_data=shift;
  my $write_data=$read_data;
  my $read_addr=$next_addr-1;

  #read address
  my $ce_oe_we = 0x4;
  my $control = 0x100;
  my $end_config = 0x000;
	&SPI_FLASH_write_data_without_stop($next_addr,$write_data, $ce_oe_we, $control, $end_config);
	&read_flash_72bit($read_addr,$read_data);
	&JTAG_stop();
}

sub read_OTP_initial(){
  my $write_addr=shift;
  my $write_data=shift;

  #original
  my $ce_oe_we = 0x7;
  my $control = 0x000;
  my $end_config = 0x280;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x4;
  my $control = 0x000;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	&read_flash_32bit($write_addr,$write_data);
}

sub read_OTP_continues(){
  my $write_addr=shift;
  my $write_data=shift;

	#ce prog
	my $ce_oe_we = 0x4;
  my $control = 0x000;
  my $end_config = 0x280;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	&read_flash_32bit($write_addr,$write_data);
	&JTAG_stop();
}

sub flash_erase_one_sector(){
	  my $write_addr=shift;
	  my $write_data=0x0000;
	  
		my $ce_oe_we = 0x7;
		my $control = 0x318;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x7, 0x318
	  
	  my $ce_oe_we = 0x6;
		my $control = 0x304;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  
	  my $ce_oe_we = 0x2;
		my $control = 0x304;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x2, 0x304
	  
	  &SPI_print_n_line(80000); #wait 4 ms
	  
	  my $ce_oe_we = 0x6;
		my $control = 0x304;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  &SPI_print_n_line(1000); #wait 50 us

	  my $ce_oe_we = 0x7;
		my $control = 0x318;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  &SPI_print_n_line(1000); #wait 50 us
}

sub flash_erase_nvr2_sector(){

	my $write_addr=0x0080;
	my $write_data=0x0000;
	  
	my $ce_oe_we = 0x6;
	my $control = 0x000;
  	my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x7, 0x318
	  
	my $ce_oe_we = 0x6;
	my $control = 0x080;
  	my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  
	my $ce_oe_we = 0x3;
	my $control = 0x084;
  	my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x2, 0x304

	my $ce_oe_we = 0x3;
	my $control = 0x004;
  	my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x2, 0x304

	my $ce_oe_we = 0x3;
	my $control = 0x084;
  	my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x2, 0x304

	my $ce_oe_we = 0x6;
	my $control = 0x080;
  	my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x2, 0x304

	my $ce_oe_we = 0x6;
	my $control = 0x0c4;
  	my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x2, 0x304

	my $ce_oe_we = 0x2;
	my $control = 0x0c4;
  	my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x2, 0x304
	
	&SPI_print_n_line(100000); #wait 5 ms

	my $ce_oe_we = 0x6;
	my $control = 0x0c4;
  	my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x2, 0x304

	&SPI_print_n_line(1000); #wait 50 us

	my $ce_oe_we = 0x6;
	my $control = 0x0c0;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x2, 0x304

}

sub flash_chip_erase(){
		#print OUT "flash_chip_erase\n";
	
	  my $write_addr=0x0000;
	  my $write_data=0x0000;
	  
		my $ce_oe_we = 0x7;
		my $control = 0x318;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x7, 0x318
	  
	  my $ce_oe_we = 0x6;
		my $control = 0x30c;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x30c
	  
	  my $ce_oe_we = 0x2;
		my $control = 0x30c;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x2, 0x30c
	  
	  &SPI_print_n_line(600000); #wait 30 ms
	  
	  my $ce_oe_we = 0x6;
		my $control = 0x30c;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x30c

		&SPI_print_n_line(1000); #wait 50 us
	  
	  my $ce_oe_we = 0x7;
		my $control = 0x318;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);  #0x7, 0x318
	  &SPI_print_n_line(1000); #wait 50 us
}

sub FLASH_enter_test_mode(){
  my $write_addr=shift;
  my $write_data=shift;

  #program low 32bit
  #web
  my $ce_oe_we = 0x6;
  my $control = 0x080;
  my $end_config = 0x000;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

  #prog2
  my $ce_oe_we = 0x3;
  my $control = 0x080;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  my $ce_oe_we = 0x3;
  my $control = 0x084;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
  my $ce_oe_we = 0x3;
  my $control = 0x004;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
  my $ce_oe_we = 0x3;
  my $control = 0x084;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  my $ce_oe_we = 0x3;
  my $control = 0x080;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
  my $ce_oe_we = 0x6;
  my $control = 0x080;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

}

sub write_FLASH_NVR2(){

  my $write_addr=shift;
  my $write_data=shift;

  &FLASH_enter_test_mode();
  
  #program high 36bit
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x1c0;
  my $end_config = 0x000;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x6;
  my $control = 0x1c1;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #web
  my $ce_oe_we = 0x2;
  my $control = 0x1c1;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

  #prog2
  my $ce_oe_we = 0x2;
  my $control = 0x1c1;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
 
  #prog2 to low
  my $ce_oe_we = 0x2;
  my $control = 0x1c1;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #we to high
  my $ce_oe_we = 0x2;
  my $control = 0x1c3;
  my $end_config = 0x000;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #program low 36bit 
  #original
  my $ce_oe_we = 0x2;
  my $control = 0x1c3;
  my $end_config = 0x000;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x2;
  my $control = 0x1c3;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

  #web
  my $ce_oe_we = 0x2;
  my $control = 0x1c3;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

  #prog2
  my $ce_oe_we = 0x06;
  my $control = 0x1c1;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #prog2 to low
  my $ce_oe_we = 0x06;
  my $control = 0x1c0;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #we to high
  my $ce_oe_we = 0x07;
  my $control = 0x1c0;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}


sub write_FLASH(){
	
  my $write_addr=shift;
  my $write_data=shift;

  #program high 36bit
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x300;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x6;
  my $control = 0x301;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#web
	my $ce_oe_we = 0x2;
  my $control = 0x301;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x303;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	&SPI_print_n_line(226); #11.3us

	#prog2 to low
	my $ce_oe_we = 0x2;
  my $control = 0x301;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	#we to high
	my $ce_oe_we = 0x6;
  my $control = 0x301;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #program low 36bit 
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x100;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x6;
  my $control = 0x101; 
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#web
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x103;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(226); #11.3us

	#prog2 to low
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	#we to high
	my $ce_oe_we = 0x6;
  my $control = 0x101;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

#read set fast mode 0x0002/0xfffffffffffffffe
#read set threshold 15% 0x0001/0xffffffffffffffe3
#read set threshold 55% 0x0001/0xfffffffffffffff1
sub FLASH_set_reg(){
	
  my $write_addr=shift;
  my $write_data=shift;

  #program high 36bit
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x000;
  my $end_config = 0x000;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x6;
  my $control = 0x000;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #web
  my $ce_oe_we = 0x6;
  my $control = 0x020;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

  #prog2
  my $ce_oe_we = 0x6;
  my $control = 0x000;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
 
  #prog2 to low
  my $ce_oe_we = 0x7;
  my $control = 0x000;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub FLASH_Standby(){
  my $write_addr=shift;
  my $write_data=shift;

  #program high 36bit
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}


sub write_OTP_VNR3(){
	
  my $write_addr=shift;
  my $write_data=shift;
	
  &OTP_enter_test_mode();

  #original
  my $ce_oe_we = 0x7;
  my $control = 0x0b0;
  my $end_config = 0x280;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x6;
  my $control = 0x0b1;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #address 0x0001
  #web
  my $ce_oe_we = 0x2;
  my $control = 0x0b1;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #prog2
  my $ce_oe_we = 0x2;
  my $control = 0x0b3;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  &SPI_print_n_line(68); #3.4us

  #prog2
  my $ce_oe_we = 0x2;
  my $control = 0x0b1;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x6;
  my $control = 0x0b1;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x7;
  my $control = 0x0b0;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x130;
  my $end_config = 0x280;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x6;
  my $control = 0x131;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #address 0x0001
  #web
  my $ce_oe_we = 0x2;
  my $control = 0x131;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #prog2
  my $ce_oe_we = 0x2;
  my $control = 0x133;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  &SPI_print_n_line(68); #3.4us

  #prog2
  my $ce_oe_we = 0x2;
  my $control = 0x131;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x6;
  my $control = 0x131;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x7;
  my $control = 0x130;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

#OTP set fast read mode 0x03/0xfffffffe
#OTP set low read threshold 0x06/0xfffffff2
#OTP set high read threshold 0x06/0xfffffffa
sub write_OTP_reg(){
	
  my $write_addr=shift;
  my $write_data=shift;
  
  &OTP_enter_reg_set_mode();

  #original
  my $ce_oe_we = 0x3;
  my $control = 0x020;
  my $end_config = 0x280;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x6;
  my $control = 0x20;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #address 0x0001
  #web
  my $ce_oe_we = 0x6;
  my $control = 0x028;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #prog2
  my $ce_oe_we = 0x6;
  my $control = 0x020;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #prog2
  my $ce_oe_we = 0x3;
  my $control = 0x020;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

}

sub OTP_enter_reg_set_mode(){
	
  my $write_addr=shift;
  my $write_data=shift;

  #original
  my $ce_oe_we = 0x4;
  my $control = 0x020;
  my $end_config = 0x280;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x1;
  my $control = 0x020;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #address 0x0001
  #web
  my $ce_oe_we = 0x3;
  my $control = 0x02b;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #prog2
  my $ce_oe_we = 0x3;
  my $control = 0x00b;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	

  #ce prog
  my $ce_oe_we = 0x3;
  my $control = 0x02b;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
}

sub OTP_enter_test_mode(){
	
  my $write_addr=shift;
  my $write_data=shift;

  #original
  my $ce_oe_we = 0x4;
  my $control = 0x020;
  my $end_config = 0x280;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #ce prog
  my $ce_oe_we = 0x1;
  my $control = 0x020;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #address 0x0001
  #web
  my $ce_oe_we = 0x1;
  my $control = 0x024;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #prog2
  my $ce_oe_we = 0x1;
  my $control = 0x004;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #ce prog
  my $ce_oe_we = 0x1;
  my $control = 0x024;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
  #ce prog
  my $ce_oe_we = 0x1;
  my $control = 0x020;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
    #ce prog
  my $ce_oe_we = 0x4;
  my $control = 0x020;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
}

sub write_OTP(){
	
  my $write_addr=shift;
  my $write_data=shift;

  #original
  my $ce_oe_we = 0x7;
  my $control = 0x780;
  my $end_config = 0x280;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x6;
  my $control = 0x781;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#address 0x0001
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x781;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x783;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#ce prog
	my $ce_oe_we = 0x6;
  my $control = 0x081;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	&SPI_print_n_line(68); #3.4us
}

sub OTP_Deep_Standby(){
  my $write_addr=shift;
  my $write_data=shift;

  #original
  my $ce_oe_we = 0x7;
  my $control = 0x0c0;
  my $end_config = 0x280;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub calc_11_bit_to_dec()
{
	my $Prog = shift;
  my $Prog2=shift;
  my $Erase=shift;
  my $Chip=shift;
  my $NVR=shift;
  my $TMEN=shift;
  my $DPSTB=shift;
  my $BYTE_0=shift;
  my $BYTE_1=shift;
  my $BYTE_2=shift;
  my $BYTE_3=shift;
  
  my $calc_control = $Prog+($Prog2<<1)+($Erase<<2)+($Chip<<3)+($NVR<<4)+($TMEN<<5)+($DPSTB<<6)+
                     ($BYTE_0<<7)+($BYTE_1<<8)+($BYTE_2<<9)+($BYTE_3<<10);

  return($calc_control);
}

sub OTP_erase_one_sector(){
  my $write_addr=shift;
  my $write_data=0x0000;
  
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x008;
  my $end_config = 0x280;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #ce erase 
  my $ce_oe_we = 0x6;
  my $control = 0x004;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	#we
  my $ce_oe_we = 0x2;
  my $control = 0x004;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  &SPI_print_n_line(80000); #wait 4 ms
	
	#we
  my $ce_oe_we = 0x6;
  my $control = 0x004;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  &SPI_print_n_line(1000); #wait 50 us
	
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x008;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}


sub otp_erase_nvr4_sector(){
  my $write_addr=0x0180;
  my $write_data=0x0000;
  
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x000;
  my $end_config = 0x280;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #ce erase 
  my $ce_oe_we = 0x6;
  my $control = 0x020;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #we
  my $ce_oe_we = 0x3;
  my $control = 0x024;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #we
  my $ce_oe_we = 0x3;
  my $control = 0x004;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #we
  my $ce_oe_we = 0x3;
  my $control = 0x024;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
		
  #we
  my $ce_oe_we = 0x6;
  my $control = 0x020;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #we
  my $ce_oe_we = 0x6;
  my $control = 0x024;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #we
  my $ce_oe_we = 0x2;
  my $control = 0x024;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  &SPI_print_n_line(400000); #wait 20 ms

  #we
  my $ce_oe_we = 0x6;
  my $control = 0x024;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  &SPI_print_n_line(4000); #wait 200 us

  #we
  my $ce_oe_we = 0x6;
  my $control = 0x020;
  &SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}


sub OTP_chip_erase(){
	
  my $write_addr=shift;
  my $write_data=0x0000;

  my $Prog = 0;
  my $Prog2=0;
  my $Erase=0;
  my $Chip=1;
  my $NVR=$isNVR;
  my $TMEN=0;
  my $DPSTB=0;
  my $BYTE_0=0;
  my $BYTE_1=0;
  my $BYTE_2=0;
  my $BYTE_3=0;

  #original
  my $ce_oe_we = 0x7;
  my $control = &calc_11_bit_to_dec($Prog,$Prog2,$Erase,$Chip,$NVR,$TMEN,$DPSTB,$BYTE_0,$BYTE_1,$BYTE_2,$BYTE_3);
  my $end_config = 0x280;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #ce erase 
  $Erase=1;
  my $ce_oe_we = 0x6;
  my $control = &calc_11_bit_to_dec($Prog,$Prog2,$Erase,$Chip,$NVR,$TMEN,$DPSTB,$BYTE_0,$BYTE_1,$BYTE_2,$BYTE_3);
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	#we
  my $ce_oe_we = 0x2;
  my $control = &calc_11_bit_to_dec($Prog,$Prog2,$Erase,$Chip,$NVR,$TMEN,$DPSTB,$BYTE_0,$BYTE_1,$BYTE_2,$BYTE_3);
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(400000); #wait 20 ms
	
	#we
  my $ce_oe_we = 0x6;
  my $control = &calc_11_bit_to_dec($Prog,$Prog2,$Erase,$Chip,$NVR,$TMEN,$DPSTB,$BYTE_0,$BYTE_1,$BYTE_2,$BYTE_3);
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(4000); #wait 200 us
	
	$Erase=0;
	$Chip=0;
	#original
  my $ce_oe_we = 0x7;
  my $control = &calc_11_bit_to_dec($Prog,$Prog2,$Erase,$Chip,$NVR,$TMEN,$DPSTB,$BYTE_0,$BYTE_1,$BYTE_2,$BYTE_3);
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub write_FLASH_low_36bit_initial(){
  my $write_addr=shift;
  my $write_data=shift;

  #program low 32bit
  #preset
  my $ce_oe_we = 0x6;
  my $control = 0x101;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x100;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x6;
  my $control = 0x101; 
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

}

sub write_FLASH_high_36bit_initial(){
  my $write_addr=shift;
  my $write_data=shift;
  
  #program low 32bit
  
  #preset
  my $ce_oe_we = 0x6;
  my $control = 0x301;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x300;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x6;
  my $control = 0x301; 
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   
}

sub disable_FLASH(){

  my $write_addr=0x0000;
  my $write_data=0x0000000000000000;
  
  #preset
  my $ce_oe_we = 0x6;
  my $control = 0x301;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x300;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
}

sub write_FLASH_low_36bit_continues(){
  my $write_addr=shift;
  my $write_data=shift;

  #program low 32bit
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x103;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	&SPI_print_n_line(452); #11.3us

	#prog2 to low
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub write_FLASH_high_36bit_continues(){
  my $write_addr=shift;
  my $write_data=shift;

  #program low 32bit
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x301;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x303;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	&SPI_print_n_line(226); #11.3us

	#prog2 to low
	my $ce_oe_we = 0x2;
  my $control = 0x301;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub load_bin_file(){
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	#my $op_byte = 1048576;
	#print OUT "open bin file";
	open(bin_file, "<FunctionalTest-7758.bin.sig")||die "Can't open ./FunctionalTest-7758.bin.sig! $@\n";
	binmode(bin_file);
	read(bin_file,my $buf,$op_byte);
	my $hex=unpack("H*",$buf);
	chomp($hex);
	
	#for($i=0; $i<$op_byte; $i++)
	#{
	#	$array_bin[$i] = "11111111";
	#	$array_hex[$i] = "ff";
	#}
	
	#&SPI_chip_erase();
	#&flash_chip_erase();
	#&OTP_chip_erase();
	
	for($i=0; $i<$op_byte; $i++)
	{
		if(substr($hex,$i*2,2))
		{
			$array_bin[$i] = unpack("B8",substr($buf,$i,1));
			$array_hex[$i] = substr($hex,$i*2,2);
		}else{
			$array_bin[$i] = "11111111";
			$array_hex[$i] = "ff";
		}
		
		#print OUT $array_hex[$i];
		if(($i+1)%8 == 0 && $i!=0)
		{
			#print OUT "\n";
			#$write_8byte = $array_hex[$i].$array_hex[$i-1].$array_hex[$i-2].$array_hex[$i-3].$array_hex[$i-4].$array_hex[$i-5].$array_hex[$i-6].$array_hex[$i-7];
			#&data_output_with_ecc($write_8byte);
		}
		#if($array_bin[$i]){
			#print OUT $array_hex[$i]." to bin ".$array_bin[$i]."\n";
		#}else{
			#last;
		#}
	}
}

sub transfer_bin_to_avc_FLASH(){
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	my $part = 256;
	my $base_address = 0x0000;
	#my $base_address = 0x0400*510;
	
#	&transfer_bin_to_avc_FLASH_Low();
#	&transfer_bin_to_avc_FLASH_High();
	
	#&FLASH_enter_test_mode();
	#&write_FLASH(0x11,"ffffffffffffaa55");
	#&read_FLASH(0x10,"a5a5a5a55a5a5a5a");
	#&read_FLASH(0x51,"a5a5a5a55a5a5a5a");
	#&read_FLASH(0x52,"ffffffffffffffff");
	#&read_FLASH(0x53,"ffffffffffffffff");
	
=pod
	for($i=0; $i<$op_byte; $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = ($i+$base_address)/8;
		&write_FLASH($address_16bit,$write_8byte);
	}
=cut

#=pod
	for($i=0; $i<$op_byte; $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = ($i+$base_address)/8;
		if($address_16bit%32==0){
			&write_FLASH_low_36bit_initial($address_16bit,$write_8byte);
			&write_FLASH_low_36bit_continues($address_16bit,$write_8byte);
		} else {
			&write_FLASH_low_36bit_continues($address_16bit,$write_8byte);
		}
	}
	&disable_FLASH();
  
	for($i=0; $i<$op_byte; $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = ($i+$base_address)/8;
		if($address_16bit%32==0){
			&write_FLASH_high_36bit_initial($address_16bit,$write_8byte);
			&write_FLASH_high_36bit_continues($address_16bit,$write_8byte);
		} else {
			&write_FLASH_high_36bit_continues($address_16bit,$write_8byte);
		}
	}
	&disable_FLASH();
#=cut

#	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){ #0xa880
#		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
#		$$address_16bit = ($i+$base_address)/8;
#		&write_FLASH($address_16bit,$write_8byte);
#	}
#	
#	$part = 261;
#	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){ #0xa880
#		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
#		$$address_16bit = ($i+$base_address)/8;
#		&write_FLASH($address_16bit,$write_8byte);
#	}
#
#	$part = 324;
#	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){ #0xa880
#		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
#		$$address_16bit = ($i+$base_address)/8;
#		&write_FLASH($address_16bit,$write_8byte);
#	}
#	
#	$part = 325;
#	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){ #0xa880
#		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
#		$$address_16bit = ($i+$base_address)/8;
#		&write_FLASH($address_16bit,$write_8byte);
#	}
}

sub transfer_bin_to_avc_FLASH_Low(){
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	my $part = 256;
	#my $base_address = 0x0000;
	my $base_address = 0x0400;

	for($i=0; $i<$op_byte; $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = ($i+$base_address)/8;
		if($address_16bit%32==0){
			&write_FLASH_low_36bit_initial($address_16bit,$write_8byte);
			&write_FLASH_low_36bit_continues($address_16bit,$write_8byte);
		} else {
			&write_FLASH_low_36bit_continues($address_16bit,$write_8byte);
		}
	}
	&disable_FLASH();
}

sub transfer_bin_to_avc_FLASH_High(){
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	my $part = 256;
	#my $base_address = 0x0000;
	my $base_address = 0x0400;

	for($i=0; $i<$op_byte; $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = ($i+$base_address)/8;
		if($address_16bit%32==0){
			&write_FLASH_high_36bit_initial($address_16bit,$write_8byte);
			&write_FLASH_high_36bit_continues($address_16bit,$write_8byte);
		} else {
			&write_FLASH_high_36bit_continues($address_16bit,$write_8byte);
		}
	}
	&disable_FLASH();
}


sub transfer_bin_to_avc_OTP(){
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	my $part = 256;
	my $base_address = 0x0000;
	
	&write_OTP(0x0010,"55aaaa55");
	
	#for($i=0; $i<$op_byte; $i = $i+4){
	#	$write_4byte = $array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
	#	$address_4byte = ($i+$base_address)/4;
	#	&write_OTP($address_4byte,$write_4byte);
	#}
}

sub read_flash_by_sector(){
	#print OUT "read_flash_by_sector\n";
	my $sector = 0;
	for($sector=0; $sector<128; $sector++)
	{
		$outfile="read_flash_sector_$sector".".avc";
	  open(OUT, ">./all_avc/$outfile")||die "Can't create $outfile! $@\n";
	  &print_head;
	  $pattern_start = 0;
		&read_FLASH_one_sector($sector);
		close (OUT);
	}	
  #&JTAG_stop();  
}

sub read_FLASH_one_sector(){
	my $sector_num = shift;
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	my $part = 256;
	#my $base_address = 0x0000;
	my $base_address = $sector_num*0x400;
	my $sector_byte = 1024;

	$is_initial = 1;
	for($i=$base_address; $i<$base_address+$sector_byte; $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = $i/8;
		$next_address = $address_16bit+1;
		if($is_initial) {
			&read_flash_initial($address_16bit,$write_8byte);
			&read_flash_address($next_address,$write_8byte);
			$is_initial = 0;
		} else {
			&read_flash_address($next_address,$write_8byte);
		}
	}
	&JTAG_stop();
}
sub read_FLASH_bin(){
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	my $part = 256;
	#my $base_address = 0x0000;
	my $base_address = 0x0400;
		
	$is_initial = 1;
	for($i=0; $i<$op_byte; $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = ($i+$base_address)/8;
		$next_address = $address_16bit+1;
		if($is_initial) {
			&read_flash_initial($address_16bit,$write_8byte);
			&read_flash_address($next_address,$write_8byte);
			$is_initial = 0;
		} else {
			&read_flash_address($next_address,$write_8byte);
		}
	}
	&JTAG_stop();

=pod
	$is_initial = 1;
	my $part = 256;
	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = $i/8;
		$next_address = $address_16bit+1;
		if($is_initial) {
			&read_flash_initial($address_16bit,$write_8byte);
			&read_flash_address($next_address,$write_8byte);
			$is_initial = 0;
		} else {
			&read_flash_address($next_address,$write_8byte);
		}
	}
	
	my $part = 261;
	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = $i/8;
		$next_address = $address_16bit+1;
		if($is_initial) {
			&read_flash_initial($address_16bit,$write_8byte);
			&read_flash_address($next_address,$write_8byte);
			$is_initial = 0;
		} else {
			&read_flash_address($next_address,$write_8byte);
		}
	}
	
	my $part = 324;
	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = $i/8;
		$next_address = $address_16bit+1;
		if($is_initial) {
			&read_flash_initial($address_16bit,$write_8byte);
			&read_flash_address($next_address,$write_8byte);
			$is_initial = 0;
		} else {
			&read_flash_address($next_address,$write_8byte);
		}
	}
	
	my $part = 325;
	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = $i/8;
		$next_address = $address_16bit+1;
		if($is_initial) {
			&read_flash_initial($address_16bit,$write_8byte);
			&read_flash_address($next_address,$write_8byte);
			$is_initial = 0;
		} else {
			&read_flash_address($next_address,$write_8byte);
		}
	}
	&JTAG_stop();
=cut
}

sub sector_erase_flash(){
	#print OUT "sector_erase_flash\n";
	$sector_address = shift;
	
	&flash_erase_one_sector($sector_address);
	#&flash_erase_nvr2_sector();
}

sub flash_NVR_sector_erase(){
	$isNVR=1;
	$sector_address = shift;	
	&flash_erase_one_sector($sector_address);
	$isNVR=0;
}

sub read_OTP_bin(){
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	my $base_address = 0x0000;
	
	&read_OTP(0x0180,"55aaaa55");
	&read_OTP(0x0181,"55aaaa55");
	&read_OTP(0x0182,"55aaaa55");
	&read_OTP(0x0183,"55aaaa55");
	&read_OTP(0x0184,"55aaaa55");
	&read_OTP(0x0185,"55aaaa55");
	&read_OTP(0x0186,"55aaaa55");
	&read_OTP(0x0187,"55aaaa55");
	&read_OTP(0x0188,"55aaaa55");
	&read_OTP(0x0189,"55aaaa55");
	&read_OTP(0x018a,"55aaaa55");
	&read_OTP(0x018b,"55aaaa55");
	&read_OTP(0x018c,"55aaaa55");
	&read_OTP(0x018d,"55aaaa55");
	&read_OTP(0x018e,"55aaaa55");
	&read_OTP(0x018f,"55aaaa55");
	&read_OTP(0x0190,"55aaaa55");
	&read_OTP(0x0191,"55aaaa55");
	&read_OTP(0x0192,"55aaaa55");
	&read_OTP(0x0193,"55aaaa55");
	&read_OTP(0x0194,"55aaaa55");
	&read_OTP(0x0195,"55aaaa55");
	&read_OTP(0x0196,"55aaaa55");
	&read_OTP(0x0197,"55aaaa55");
	&read_OTP(0x0198,"55aaaa55");
	&read_OTP(0x0199,"55aaaa55");
	&read_OTP(0x019a,"55aaaa55");
	&read_OTP(0x019b,"55aaaa55");
	&read_OTP(0x019c,"55aaaa55");
	&read_OTP(0x019d,"55aaaa55");
	&read_OTP(0x019e,"55aaaa55");
	&read_OTP(0x019f,"55aaaa55");
	

=pod
	$is_initial=1;
	for($i=0; $i<$op_byte; $i = $i+4){
		$write_4byte = $array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_12bit = $i/4;
		if($is_initial) {
			&read_OTP_initial($address_12bit,$write_4byte);
			$is_initial=0;
		} else {
			&read_OTP_continues($address_12bit,$write_4byte);
		}
	}
=cut
	&JTAG_stop();
}


sub sector_erase_otp(){
	#print OUT "sector_erase_otp\n";
	$sector_address = shift;
	
	#&OTP_erase_one_sector($sector_address);
	&otp_erase_nvr4_sector();
}

