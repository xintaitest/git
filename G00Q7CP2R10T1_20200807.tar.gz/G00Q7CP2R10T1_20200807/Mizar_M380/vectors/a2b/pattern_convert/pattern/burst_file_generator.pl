=pod
mkdir burst_files;
my $file_name = "flash_rd_i_ckbd_burst";
my $start_label = "flash_rd_i_ckbd_start";
my $burst_label = "flash_rd_i_ckbd_sector";
my $sub_label_num = 512;
my $SQPG_num = $sub_label_num+2;
my $burst_num = $sub_label_num+1;


open OUT, ">./burst_files/$file_name";
print OUT "hp93000,vector,0.1\n";
print OUT "DMAS SQPG,SM,$SQPG_num,(@)\n";
print OUT "SQLB \"$file_name\",BRST,0,$burst_num,\"Normal_wt\"\n";
print OUT "SQPG 0,CALL,,\"$start_label\",,(@)\n";

for($i=1; $i<=$sub_label_num;	$i++)
{
	print OUT "SQPG $i,CALL,,\"$burst_label\",,(@)\n";
}

print OUT "SQPG $burst_num,BEND,,,,(@)\n";
print OUT "WSDM 1,2\n";
print OUT "NOOP \"7.4.2\",,,\n";
=cut

mkdir burst_files;
my $file_name = "read_flash_sectors";
my $burst_label = "read_flash_sector_";
my $sub_label_num = 128;
my $SQPG_num = $sub_label_num+1;
my $burst_num = $sub_label_num;

open OUT, ">./burst_files/$file_name";
print OUT "hp93000,vector,0.1\n";
print OUT "DMAS SQPG,SM,$SQPG_num,(@)\n";
print OUT "SQLB \"$file_name\",BRST,0,$burst_num,\"Normal_wt\"\n";
#print OUT "SQPG 0,CALL,,\"$start_label\",,(@)\n";

for($i=0; $i<$sub_label_num;	$i++)
{
	print OUT "SQPG $i,CALL,,\"$burst_label$i\",,(@)\n";
}

print OUT "SQPG $burst_num,BEND,,,,(@)\n";
print OUT "WSDM 1,2\n";
print OUT "NOOP \"7.4.2\",,,\n";

