###############################################################################
#  Company: ThinkTech
#  Author: zzhao
#  Date: 2018.9.19
#  Version: 1.0
#  Function Description:
#     Create FLASH SPI read & write avc file for Mizar M300
#
###############################################################################
use POSIX;
mkdir all_avc;
my $DIG_CAP=0;
my $sig_cnt=7;
my $isNVR=0;
my $isFlash0=1;
my %signals;
my $pattern_start = 0;
my $transfer_bin_to_avc_FLASH;
my $tranfer_bin_to_avc_OTP;
my $SPI_spead = 10000000;
my $frequency = 10000000;
my $period = 50;
my $repeat = 68;
my $op_byte = 65536;
my @array_hex;
my @array_bin;

#GPIO0,GPIO1,TRST,TCK,TMS,TDI,TDO
$signals{1}={
	"name"=>"TMS",
	"data"=>"1"
};
$signals{2}={
	"name"=>"TCK",
	"data"=>"P"
};
$signals{3}={
	"name"=>"TDI",
	"data"=>"0"
};
$signals{4}={
	"name"=>"DTO",
	"data"=>"X"
};
$signals{5}={
	"name"=>"GPIO0",
	"data"=>"0"
};
$signals{6}={
	"name"=>"GPIO1",
	"data"=>"0"
};
$signals{7}={
	"name"=>"TRST",
	"data"=>"1"
};



###Main Function-Register Write&Read#################
open(LIST, "pattern_list.txt")||die "Can't create $outfile! $@\n";
while(<LIST>){
if(/pattern_name:(\w+)/){
	$pat_name=$1;
	}
if(/write_FLASH:(0x\w+)\/(0x\w+)/){
	$addr=$1;
	$data=$2;
  $write_FLASH=1;
	}
if(/read_FLASH:(0x\w+)\/(0x\w+)/){
	$addr=$1;
	$data=$2;
  $read_FLASH=1;
	}
if(/write_OTP:(0x\w+)\/(0x\w+)/){
	$addr=$1;
	$data=$2;
  $write_OTP=1;
	}
if(/read_OTP:(0x\w+)\/(0x\w+)/){
	$addr=$1;
	$data=$2;
  $read_OTP=1;
	}
if(/write_SPI:(0x\w+)\/(0x\w+)/){
	$addr=$1;
	$data=$2;
  $write_SPI=1;
	}
if(/read_SPI:(0x\w+)\/(0x\w+)/){
	$addr=$1;
	$data=$2;
  $read_SPI=1;
	}
if(/write_TX:(0x\w+)\/(0x\w+)/){
	$addr=$1;
	$data=$2;
  $write_TX=1;
	}
if(/read_RX:(0x\w+)\/(0x\w+)/){
	$addr=$1;
	$data=$2;
  $read_RX=1;
	}
if(/SPI_stop/){
  $SPI_stop=1;
	}
if(/load_bin_file/){
  $load_bin_file=1;
	}
if(/transfer_bin_to_avc_FLASH/){
	$transfer_bin_to_avc_FLASH = 1;
}
if(/tranfer_bin_to_avc_OTP/){
	$tranfer_bin_to_avc_OTP = 1;
}
if(/read_FLASH_bin/){
	$read_FLASH_bin = 1;
}
if(/read_OTP_bin/){
	$read_OTP_bin = 1;
}

&create_pat($pat_name,$addr,$data,$write_MAC,$read_FLASH,$write_OTP,$read_OTP,$write_SPI,$read_SPI,$write_TX,$read_RX,$SPI_stop,$load_bin_file);
  $addr="";
  $data="";
  $pat_name="";
  $write_MAC=0;
  $read_FLASH=0;
  $write_OTP=0;
  $read_OTP=0;
  $write_SPI=0;
  $read_SPI=0;
  $write_TX=0;
  $read_RX=0;
  $SPI_stop=0;
  $load_bin_file=0;
  $transfer_bin_to_avc_FLASH = 0;
  $tranfer_bin_to_avc_OTP = 0;
  $read_FLASH_bin = 0;
  $read_OTP_bin = 0;
  $write_FLASH=0;
  $read_FLASH=0;
  $write_OTP=0;
  $read_OTP=0;
}

close LIST;
###End Main Function##################################

sub create_pat(){
my $pat_name=shift;
my $addr=shift;
my $data=shift;
my $write_FLASH=shift;
my $read_FLASH=shift;
my $write_OTP=shift;
my $read_OTP=shift;
my $write_SPI=shift;
my $read_SPI=shift;
my $write_TX=shift;
my $read_RX=shift;
my $SPI_stop=shift;
my $load_bin_file=shift;

   $addr_cm=$addr;
   $data_cm=$data;
   $my_addr_cm=$addr;
   $my_data_cm=$data;
   $addr=hex $addr_cm;
   $data=hex $data_cm;
if($pat_name ne ""){
  $outfile=${pat_name}.".avc";
  open(OUT, ">./all_avc/$outfile")||die "Can't create $outfile! $@\n";
  &print_head;
  $pattern_start = 0;
  #&SPI_stop();
}
elsif(($addr_cm ne "") && ($write_FLASH==1)){
  &write_FLASH($addr,$data,$addr_cm,$data_cm);
}
elsif(($addr_cm ne "") && ($read_FLASH==1)){
  &read_FLASH($addr,$data,$addr_cm,$data_cm);
}

elsif(($addr_cm ne "") && ($write_OTP==1)){
  &write_OTP($addr,$data,$addr_cm,$data_cm);
}
elsif(($addr_cm ne "") && ($read_OTP==1)){
  &read_OTP($addr,$data,$addr_cm,$data_cm);
}

elsif(($addr_cm ne "") && ($write_SPI==1)){
  &write_LOCAL($addr,$data,$addr_cm,$data_cm);
}
elsif(($addr_cm ne "") && ($read_SPI==1)){
  &read_LOCAL($addr,$data,$addr_cm,$data_cm);
}
elsif(($addr_cm ne "") && (${write_TX}==1)){
	&write_TX($addr,$data,$addr_cm,$data_cm);
}
elsif(($addr_cm ne "") && (${read_RX}==1)){
	&read_RX($addr,$data,$addr_cm,$data_cm);
}
elsif( $SPI_stop == 1){
	&SPI_stop();
}
elsif( $load_bin_file == 1){
	&load_bin_file();
}
elsif($transfer_bin_to_avc_FLASH == 1){
  &transfer_bin_to_avc_FLASH();
}
elsif($tranfer_bin_to_avc_OTP == 1){
  &tranfer_bin_to_avc_OTP();
}
elsif($read_FLASH_bin == 1){
  &read_FLASH_bin();
}
elsif($read_OTP_bin == 1){
  &read_OTP_bin();
}
##close(OUT);
}

sub print_head(){
  print OUT "DEFAULT_STATE XTAL_IN GPIO2,GPIO3,DFT_SCAN_RESET,DFT_SCAN_SET,DFT_SCAN_EN,LDO_SLP,DFT_TEST_EN,SPI3_SCS,RST_N;\n";
  print OUT "\@ ", " P 1 1 1 1 0 1 1 0 1;\n";
  print OUT "DEFAULT_STATE UART0_RX,UART0_TX,UART1_RX,UART1_TX,I2C0_SCL,I2C0_SDA,I2C1_SCL,I2C1_SDA,GPIO4,GPIO5,GPIO6,GPIO7,SPI0_SCLK,SPI0_SI,SPI0_SO,SPI0_SCS,SPI1_SCLK,SPI1_SI,SPI1_SO,SPI1_SCS,SPI2_SCLK,SPI2_SI,SPI2_SO,SPI2_SCS,SPI3_SCLK,SPI3_SI,SPI3_SO,XTAL_OUT,TS_OD_18,TS_UD_18,V33_OD_18,V33_UD_18,V18_OD_18,V18_UD_18,LV_TDO,TRIM_SI,TRIM_SO,DFT_SI,DFT_SO,ROM_DONE,ROM_FAIL,POR_N ;\n";
  print OUT "\@ ", " Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z Z;\n";
  print OUT "FORMAT TMS TCK TDI TDO GPIO0 GPIO1 TRST;\n";
}

sub print_line(){
  $comment=shift;
  if ($pattern_start == 1)
  {
  	  print OUT "R100 functional";
  	  $pattern_start = 0;
  } else {
  		print OUT "R1 functional";
  }
  for(my$i=1;$i<=$sig_cnt;$i++){
    print OUT " ",$signals{$i}{"data"};
  }
  print OUT " $comment;\n";
  $comment="";
}

sub print_wait_line(){
  $comment=shift;
	
  print OUT "R100000 functional";
  
  for(my$i=1;$i<=$sig_cnt;$i++){
    print OUT " ",$signals{$i}{"data"};
  }
  print OUT " $comment;\n";
  $comment="";
}

sub print_n_line(){
  $comment=shift;
  $line_count = shift;

  print OUT "R${line_count} functional";

  for(my$i=1;$i<=$sig_cnt;$i++){
    print OUT " ",$signals{$i}{"data"};
  }
  print OUT " $comment;\n";
  $comment="";

	#while($line_count--)
	#{
  #	print OUT "R1 functional";
  #	for(my$i=1;$i<=$sig_cnt;$i++){
  #  	print OUT " ",$signals{$i}{"data"};
  #	}
	#	print OUT " $comment;\n";
	#	$comment="";
  #}
}

sub SPI_start(){
   my $v1=shift;
   my $v2=shift;
   my $v3=shift;
   if($v3 ne ""){
    $comment="start ".$v3." addr:".$v1.", data:".$v2;
    #$operation ="$v3 ";
    #$sub_address = "$v1 ";
    #$sub_data = "$v2 ";
  }
	$signals{1}{"data"}="1";
	$signals{2}{"data"}="P";
	$signals{3}{"data"}="0";
	$signals{4}{"data"}="X";
	&print_line("$comment");
  #&print_line("");
  #&print_line("");
	#&print_line("");
}

sub SPI_read_start(){
   my $v1=shift;
   my $v2=shift;
   my $v3=shift;
   my $bin=shift;
   if($v3 ne ""){
    $comment="start ".$v3." addr:".$v1.", data:".$v2." bit0";
    #$operation ="$v3 ";
    #$sub_address = "$v1 ";
    #$sub_data = "$v2 ";
  }
  $bit0==substr($bin,71,1);
	$signals{1}{"data"}="1"; #TMS
	$signals{2}{"data"}="P";
	$signals{3}{"data"}="0";
	if($bit0==1) {
		$signals{4}{"data"}="H";
	} else {
		$signals{4}{"data"}="L";
	}
	&print_line("$comment");
  #&print_line("");
  #&print_line("");
	#&print_line("");
}

sub SPI_stop(){
	$signals{1}{"data"}="1";
	$signals{2}{"data"}="P";
	$signals{3}{"data"}="0";
	$signals{4}{"data"}="X";
	#&print_line("");
  	#&print_line("");
  	&print_line("");
	&print_line("SPI Stop");
	#&print_line("");
	#&print_line("");
	#&print_line("");
	#&print_line("");
}

sub write_MAC(){
  my $register_addr=shift;
  my $write_data=shift;
  my $addr_comm=shift;
  my $data_comm=shift;
  #Command
  #send start signals
  &SPI_start("$addr_comm","$data_comm","write");
  &print_line("");
  &print_line("");
  &print_line("Command");
  #command C0 byte_en[3:0]
  &SPI_write_byte(0x0f);
  #command C1 address low
  $address_low = $register_addr >> 0;
  &SPI_write_byte($address_low);
  #command C2 address high
  $address_high = $register_addr >> 8;
  &SPI_write_byte($address_high);
  #command C3 write command
  &SPI_write_byte(0x90);
  #&SPI_write_byte(0x90);
  &print_line("");
  &print_line("");
  &print_line("");
  
  #Response
  &print_line("Response");
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &print_line("");
  &print_line("");
  &print_line("");
  
  #Data
  &print_line("Data");
  $data0 = $write_data >> 0;
  &SPI_write_byte($data0);
  $data1 = $write_data >> 8;
  &SPI_write_byte($data1);
  $data2 = $write_data >> 16;
  &SPI_write_byte($data2);
  $data3 = $write_data >> 24;
  &SPI_write_byte($data3);
	&print_line("");
  &print_line("");
  &print_line("");
  
  #Status
  &print_line("Status");
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
	&print_line("");
  &print_line("");
  &SPI_stop();
}

sub read_FLASH(){
  my $read_addr=shift;
  my $read_data=shift;
  my $addr_comm=shift;
  my $data_comm=shift;
  
	&read_flash_initial($read_addr,$read_data);
	&read_flash_address($read_addr,$read_data);
}

sub read_OTP(){
  my $read_addr=shift;
  my $read_data=shift;

  #original
  my $ce_oe_we = 0x7;
  my $control = 0x000;
  my $end_config = 0x280;
	&SPI_OTP_write_data($read_addr,$read_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x4;
  my $control = 0x000;
	&SPI_OTP_write_data($read_addr,$read_data, $ce_oe_we, $control, $end_config);

	&read_flash_32bit($read_addr,$read_data);
}

sub write_LOCAL(){
  my $register_addr=shift;
  my $write_data=shift;
  my $addr_comm=shift;
  my $data_comm=shift;
  #Command
  #send start signals
  &SPI_start("$addr_comm","$data_comm","write");
  &print_line("");
  &print_line("");
  &print_line("");
  &print_line("Command");
  #command C0 byte_en[3:0]
  &SPI_write_byte(0x0f);
  #command C1 address low
  $address_low = $register_addr >> 0;
  &SPI_write_byte($address_low);
  #command C2 address high
  $address_high = $register_addr >> 8;
  &SPI_write_byte($address_high);
  #command C3 write command
  &SPI_write_byte(0x80);
  &print_line("");
  &print_line("");
  &print_line("");
  
  #Response
  &print_line("Response");
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &print_line("");
  &print_line("");
  &print_line("");
  
  #Data
  &print_line("Data");
  $data0 = $write_data >> 0;
  &SPI_write_byte($data0);
  $data1 = $write_data >> 8;
  &SPI_write_byte($data1);
  $data2 = $write_data >> 16;
  &SPI_write_byte($data2);
  $data3 = $write_data >> 24;
  &SPI_write_byte($data3);
	&print_line("");
  &print_line("");
  &print_line("");
  
  #Status
  &print_line("Status");
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
	&print_line("");
  &print_line("");
  &print_line("");
  &SPI_stop();
}

sub read_LOCAL(){
  my $register_addr=shift;
  my $write_data=shift;
  my $addr_comm=shift;
  my $data_comm=shift;
  #Command
  #send start signals
  &SPI_start("$addr_comm","$data_comm","write");
  &print_line("");
  &print_line("");
  &print_line("");
  &print_line("Command");
  #command C0 byte_en[3:0]
  &SPI_write_byte(0x00);
  #command C1 address low
  $address_low = $register_addr >> 0;
  &SPI_write_byte($address_low);
  #command C2 address high
  $address_high = $register_addr >> 8;
  &SPI_write_byte($address_high);
  #command C3 read command
  &SPI_write_byte(0x00);
  &print_line("");
  &print_line("");
  &print_line("");
  
  #Response
  &print_line("Response");
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &print_line("");
  &print_line("");
  &print_line("");
  
  #Data read
  &print_line("Data");
  $data0 = $write_data >> 0;
  &SPI_read_byte($data0);
  $data1 = $write_data >> 8;
  &SPI_read_byte($data1);
  $data2 = $write_data >> 16;
  &SPI_read_byte($data2);
  $data3 = $write_data >> 24;
  &SPI_read_byte($data3);
	&print_line("");
  &print_line("");
  &print_line("");
  
  #Status
  &print_line("Status");
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
	&print_line("");
  &print_line("");
  &print_line("");
  &SPI_stop();
}

sub write_TX(){
  my $write_len=shift;
  my $write_data=shift;
  my $addr_comm=shift;
  my $data_comm=shift;
  #Command
  #send start signals
  &SPI_start("$addr_comm","$data_comm","write");
  &print_line("");
  &print_line("Command");
  #command C0 byte_en[3:0]
  &SPI_write_byte(0xa0);
  #command C1 rsv
  &SPI_write_byte(0x00);
  #&SPI_write_byte(0x90);
  #command C2 len high
  $write_len_high = $write_len >> 8;
  &SPI_write_byte($write_len_high);
  #command C3 len low
  $write_len_low = $write_len >> 0;
  &SPI_write_byte($write_len_low);
  &print_line("");
  
  #Response
  &print_line("Response");
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &print_line("");
  
  #Data
  &print_line("Data");
  $data0 = $write_data >> 0;
  &SPI_write_byte($data0);
  $data1 = $write_data >> 8;
  &SPI_write_byte($data1);
  $data2 = $write_data >> 16;
  &SPI_write_byte($data2);
  $data3 = $write_data >> 24;
  &SPI_write_byte($data3);
	&print_line("");
  
  #Status
  &print_line("Status");
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
	&print_line("");
  &SPI_stop();
}

sub read_RX(){
  my $register_addr=shift;
  my $write_data=shift;
  my $addr_comm=shift;
  my $data_comm=shift;
  #Command
  #send start signals
  &SPI_start("$addr_comm","$data_comm","write");
  &print_line("");
  &print_line("");
  &print_line("");
  &print_line("Command");
  #command C0 byte_en[3:0]
  &SPI_write_byte(0x0f);
  #command C1 address low
  $address_low = $register_addr >> 0;
  &SPI_write_byte($address_low);
  #command C2 address high
  $address_high = $register_addr >> 8;
  &SPI_write_byte($address_high);
  #command C3 write command
  &SPI_write_byte(0x90);
  #&SPI_write_byte(0x90);
  &print_line("");
  &print_line("");
  &print_line("");
  
  #Response
  &print_line("Response");
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &print_line("");
  &print_line("");
  &print_line("");
  
  #Data
  &print_line("Data");
  $data0 = $write_data >> 0;
  &SPI_write_byte($data0);
  $data1 = $write_data >> 8;
  &SPI_write_byte($data1);
  $data2 = $write_data >> 16;
  &SPI_write_byte($data2);
  $data3 = $write_data >> 24;
  &SPI_write_byte($data3);
	&print_line("");
  &print_line("");
  &print_line("");
  
  #Status
  &print_line("Status");
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
  &SPI_write_byte(0x00);
	&print_line("");
  &print_line("");
  &print_line("");
  &SPI_stop();
}

sub SPI_write_byte(){
	my $dec=shift;
	my $dec_hex=unpack("H2",pack("C",$dec));
     $bin=unpack("B8",pack("C",$dec));
      for($i=0;$i<=7;$i++) {
      	 $bit_num=7-$i;
         $bit=substr($bin,$i,1);
         $signals{1}{"data"}="0";
         $signals{2}{"data"}="P";
         $signals{3}{"data"}=$bit;
         $signals{4}{"data"}="X";
         if ($i == 0) {
         	  &print_line("0x${dec_hex} bit${bit_num}=$bit");
            } else {
              &print_line("bit${bit_num}=$bit");
              }
      }
      ###end of byte
			$signals{1}{"data"}="0";
			$signals{2}{"data"}="P";
			$signals{3}{"data"}="0";
			$signals{4}{"data"}="X";
      &print_line("");
}

sub SPI_read_byte(){
	my $dec=shift;
	my $dec_hex=unpack("H2",pack("C",$dec));
     $bin=unpack("B8",pack("C",$dec));
      for($i=0;$i<=7;$i++) {
      	 $bit_num=7-$i;
         $bit=substr($bin,$i,1);
         if ($bit eq "0"){$bit="L",$bit_state="0";}
         elsif($bit eq "1"){$bit="H",$bit_state="1";}
         $signals{1}{"data"}="0";
         $signals{2}{"data"}="P";
         $signals{3}{"data"}=$bit;
         $signals{4}{"data"}="X";
         if($DIG_CAP==1) {
          $signals{3}{"data"}="C";
         }
         if ($i == 0) {
         	  &print_line("0x${dec_hex} bit${bit_num}=$bit");
         } else {
         	&print_line("bit${bit_num}=$bit");
         }
      }
      ###end of byte
			$signals{1}{"data"}="0";
			$signals{2}{"data"}="P";
			$signals{3}{"data"}="0";
			$signals{4}{"data"}="X";
      &print_line("");
}


sub SPI_ce_oe_we(){
	my $bit_length = 3-1;
	my $bit_full_length = 8-1;
	my $dec=shift;
	my $dec_hex=unpack("H2",pack("C",$dec));
	$bin=unpack("B8",pack("C",$dec));
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("ce_oe_we 0x${dec_hex} bit${bit_num}=$bit");
  		} else {
  	  	&print_line("ce_oe_we bit${bit_num}=$bit");
  	  }
	}
}

sub SPI_control(){
	my $bit_length = 10-1;
	my $bit_full_length = 16-1;
	my $dec=shift;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	
	my $dec_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	$bin=unpack("B16",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("control 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("control bit${bit_num}=$bit");
  	}
	}
}

sub SPI_control_bitX(){
	my $dec=shift;
	my $control_bit = shift;
	my $bit_length = $control_bit-1;
	my $bit_full_length = 16-1;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	
	my $dec_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	$bin=unpack("B16",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("control 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("control bit${bit_num}=$bit");
  	}
	}
}

sub SPI_address_16bit(){
  my $write_addr=shift;
  my $bit_length = 16-1;
	my $bit_full_length = 16-1;
	
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
  
	my $dec_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	$bin=unpack("B16",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("address 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("address bit${bit_num}=$bit");
  	}
	}
}

sub SPI_address_12bit(){
  my $write_addr=shift;
  my $bit_length = 12-1;
	my $bit_full_length = 16-1;
	
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
  
	my $dec_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	$bin=unpack("B16",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("address 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("address bit${bit_num}=$bit");
  	}
	}
}

sub SPI_data_72bit(){
  my $write_data=shift;
  my $bit_length = 72-1;
	my $bit_full_length = 72-1;


	my $dec_byte1=substr($write_data,14,2);
	my $dec_byte2=substr($write_data,12,2);
	my $dec_byte3=substr($write_data,10,2);
	my $dec_byte4=substr($write_data,8,2);
	my $dec_byte5=substr($write_data,6,2);
	my $dec_byte6=substr($write_data,4,2);
	my $dec_byte7=substr($write_data,2,2);
	my $dec_byte8=substr($write_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	$dec_byte5 = hex($dec_byte5);
	$dec_byte6 = hex($dec_byte6);
	$dec_byte7 = hex($dec_byte7);
	$dec_byte8 = hex($dec_byte8);
	$dec_byte9 = hex($dec_byte9);
	
	my $word0 = hex(substr($write_data,8,8));
	my $word1 = hex(substr($write_data,0,8));
	my $dec_byte9=&genecc($word0,$word1);
	
	my $dec_hex=unpack("H18",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	my $bin=unpack("B72",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("data 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("data bit${bit_num}=$bit");
  	}
	}
}

sub read_flash_72bit(){
	my $read_addr=shift;
	my $read_data=shift;
  	my $bit_length = 72-1;
	my $bit_full_length = 72-1;

	my $dec_byte1=substr($read_data,14,2);
	my $dec_byte2=substr($read_data,12,2);
	my $dec_byte3=substr($read_data,10,2);
	my $dec_byte4=substr($read_data,8,2);
	my $dec_byte5=substr($read_data,6,2);
	my $dec_byte6=substr($read_data,4,2);
	my $dec_byte7=substr($read_data,2,2);
	my $dec_byte8=substr($read_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	$dec_byte5 = hex($dec_byte5);
	$dec_byte6 = hex($dec_byte6);
	$dec_byte7 = hex($dec_byte7);
	$dec_byte8 = hex($dec_byte8);
	$dec_byte9 = hex($dec_byte9);
	
	my $word0 = hex(substr($read_data,8,8));
	my $word1 = hex(substr($read_data,0,8));
	my $dec_byte9=&genecc($word0,$word1);
	
	my $dec_hex=unpack("H18",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	my $bin=unpack("B72",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
	my $dec=$read_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="1";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	if($DIG_CAP==1){
  		$signals{4}{"data"}="C";
  	} else {
  		if($bit=="1"){
  			$signals{4}{"data"}="H";
  		} else {
  			$signals{4}{"data"}="L";
  		}
  	}
  	  	
  	if ($i == 0) {
  		&print_line("read addr 0x${address_hex}, data 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("data bit${bit_num}=$bit");
  	}
	}
}

sub read_flash_32bit(){
	my $read_addr=shift;
	my $read_data=shift;
  my $bit_length = 32-1;
	my $bit_full_length = 32-1;

	my $dec_byte1=substr($read_data,6,2);
	my $dec_byte2=substr($read_data,4,2);
	my $dec_byte3=substr($read_data,2,2);
	my $dec_byte4=substr($read_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	
	my $word = hex(substr($read_data,0,8));
	
	my $dec_hex=unpack("H8",pack("C4",$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	my $bin=unpack("B32",pack("C4",$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
	my $dec=$read_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	if($DIG_CAP==1){
  		$signals{4}{"data"}="C";
  	} else {
  		if($bit=="1"){
  			$signals{4}{"data"}="H";
  		} else {
  			$signals{4}{"data"}="L";
  		}
  	}
  	  	
  	if ($i == 0) {
  		&print_line("read addr 0x${address_hex}, data 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("data bit${bit_num}=$bit");
  	}
	}
}

sub SPI_data_64bit(){
  my $write_data=shift;
  my $bit_length = 64-1;
	my $bit_full_length = 64-1;

	my $dec_byte1=substr($write_data,14,2);
	my $dec_byte2=substr($write_data,12,2);
	my $dec_byte3=substr($write_data,10,2);
	my $dec_byte4=substr($write_data,8,2);
	my $dec_byte5=substr($write_data,6,2);
	my $dec_byte6=substr($write_data,4,2);
	my $dec_byte7=substr($write_data,2,2);
	my $dec_byte8=substr($write_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	$dec_byte5 = hex($dec_byte5);
	$dec_byte6 = hex($dec_byte6);
	$dec_byte7 = hex($dec_byte7);
	$dec_byte8 = hex($dec_byte8);
	
	my $word0 = hex(substr($write_data,8,8));
	my $word1 = hex(substr($write_data,0,8));
	#my $dec_byte9=&genecc($word0,$word1);
	
	my $dec_hex=unpack("H16",pack("C8",$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	my $bin=unpack("B64",pack("C8",$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("data 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("data bit${bit_num}=$bit");
  	}
	}
}

sub SPI_data_32bit(){
  my $write_data=shift;
  my $bit_length = 32-1;
	my $bit_full_length = 32-1;


	my $dec_byte1=substr($write_data,6,2);
	my $dec_byte2=substr($write_data,4,2);
	my $dec_byte3=substr($write_data,2,2);
	my $dec_byte4=substr($write_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	
	my $word0 = hex(substr($write_data,0,8));
	
	my $dec_hex=unpack("H8",pack("C4",$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	my $bin=unpack("B32",pack("C4",$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("data 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("data bit${bit_num}=$bit");
  	}
	}
}

sub genecc()
{
	$data0 = shift;
	$data1 = shift;
  $C0x     = 0xCB4B34E9;
  $C01     = 0xAAAAAAD5;
  $C02     = 0x999999B3;
  $C04     = 0x8787878F;
  $C08     = 0x7F807F80;
  $C016    = 0x007FFF80;
  $C032    = 0xFFFFFF80;
  $C064    = 0x0000007F;
  $C1x     = 0xED3A65B4;
  $C11     = 0xDAB5556A;
  $C12     = 0xB66CCCD9;
  $C14     = 0x71E3C3C7;
  $C18     = 0x0FE03FC0;
  $C116    = 0x001FFFC0;
  $C132    = 0x0000003F;
  $C164    = 0x00000000;
  $ecc;

	$eccout00 = $data0 & $C0x;
	$eccout01 = $data0 & $C01;
	$eccout02 = $data0 & $C02;
	$eccout03 = $data0 & $C04;
	$eccout04 = $data0 & $C08;
	$eccout05 = $data0 & $C016;
	$eccout06 = $data0 & $C032;
	$eccout07 = $data0 & $C064;

	$eccout10 = $data1 & $C1x;
	$eccout11 = $data1 & $C11;
	$eccout12 = $data1 & $C12;
	$eccout13 = $data1 & $C14;
	$eccout14 = $data1 & $C18;
	$eccout15 = $data1 & $C116;
	$eccout16 = $data1 & $C132;
	$eccout17 = $data1 & $C164;

  for ($i = 1, $tmp = ($eccout00 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout00 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout10); $i < 32; $i++, $tmp >>= 1) {
    $eccout00 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout01 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout01 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout11); $i < 32; $i++, $tmp >>= 1) {
    $eccout01 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout02 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout02 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout12); $i < 32; $i++, $tmp >>= 1) {
    $eccout02 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout03 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout03 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout13); $i < 32; $i++, $tmp >>= 1) {
    $eccout03 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout04 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout04 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout14); $i < 32; $i++, $tmp >>= 1) {
    $eccout04 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout05 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout05 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout15); $i < 32; $i++, $tmp >>= 1) {
    $eccout05 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout06 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout06 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout16); $i < 32; $i++, $tmp >>= 1) {
    $eccout06 ^= $tmp;
  }

  for ($i = 1, $tmp = ($eccout07 >> 1); $i < 32; $i++, $tmp >>= 1) {
    $eccout07 ^= $tmp;
  }
  for ($i = 0, $tmp = ($eccout17); $i < 32; $i++, $tmp >>= 1) {
    $eccout07 ^= $tmp;
  }

	$ecc = ($eccout00 & 0x1) | (($eccout01 & 0x1) << 1) | (($eccout02 & 0x1) << 2) | (($eccout03 & 0x1) << 3) |
        (($eccout04 & 0x1) << 4) | (($eccout05 & 0x1) << 5) | (($eccout06 & 0x1) << 6) | (($eccout07 & 0x1) << 7);
        
  return $ecc;
}

sub SPI_end_config(){
	my $bit_length = 12-1;
	my $bit_full_length = 16-1;
	my $dec=shift;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	
	my $dec_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	$bin=unpack("B16",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("end config 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("end config bit${bit_num}=$bit");
  	}
	}
}

sub SPI_end_config_bitX(){
	my $dec=shift;
	my $config_bit=shift;
	my $bit_length = $config_bit-1;
	my $bit_full_length = 16-1;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	
	my $dec_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	$bin=unpack("B16",pack("C2",$dec_byte2,$dec_byte1));
	
	for($i=0;$i<=$bit_length;$i++) {
  	$bit_num=$i;
  	$bit=substr($bin,$bit_full_length-$i,1);
  	$signals{1}{"data"}="0";
  	$signals{2}{"data"}="P";
  	$signals{3}{"data"}=$bit;
  	$signals{4}{"data"}="X";
  	if ($i == 0) {
  		&print_line("end config 0x${dec_hex} bit${bit_num}=$bit");
  	} else {
  		&print_line("end config bit${bit_num}=$bit");
  	}
	}
}

sub SPI_wait_time(){
  my $wait_time=shift;
  my $wait_cycle = $wait_time/$period;
	my $wait_cycle = ceil($wait_cycle);
	
	$signals{1}{"data"}="1";
  $signals{2}{"data"}="P";
  $signals{3}{"data"}="0";
  $signals{4}{"data"}="X";
	
  print OUT "R$wait_cycle functional";
  
  for(my$i=1;$i<=$sig_cnt;$i++){
    print OUT " ",$signals{$i}{"data"};
  }
  print OUT " wait $wait_time ns;\n";
  $comment="";
}

sub SPI_print_n_line(){
  my $n_line=shift;
  my $wait_time = $n_line*$period;
  
  print OUT "R$n_line functional";
  
  for(my$i=1;$i<=$sig_cnt;$i++){
    print OUT " ",$signals{$i}{"data"};
  }
  print OUT " wait $wait_time ns;\n";
  $comment="";
}

sub SPI_chip_erase(){
	
	$signals{1}{"data"}="1"; #TMS->STROBE
  $signals{2}{"data"}="P"; #TCK->TCK
  $signals{3}{"data"}="0"; #TDI->TDI
  $signals{4}{"data"}="X"; #TDO->TDO
  $signals{7}{"data"}="1"; #TRST->RESETb
  &SPI_print_n_line(178);
  
  $signals{1}{"data"}="1"; #TMS
  $signals{2}{"data"}="P"; #TCK
  $signals{3}{"data"}="0"; #TDI
  $signals{4}{"data"}="X"; #TDO
  $signals{7}{"data"}="0"; #TRST->RESETb,#set TRST to 0
  &SPI_print_n_line(22); 
  
  $signals{1}{"data"}="1"; #TMS
  $signals{2}{"data"}="P"; #TCK
  $signals{3}{"data"}="0"; #TDI
  $signals{4}{"data"}="X"; #TDO
  $signals{7}{"data"}="1"; #TRST->RESETb
  &SPI_print_n_line(205);
  
  $signals{1}{"data"}="0"; #TMS
  $signals{2}{"data"}="P"; #TCK
  $signals{3}{"data"}="1"; #TDI
  $signals{4}{"data"}="X"; #TDO
  $signals{7}{"data"}="1"; #TRST->RESETb
  &SPI_print_n_line(3);

  $signals{1}{"data"}="0"; #TMS
  $signals{2}{"data"}="P"; #TCK
  $signals{3}{"data"}="0"; #TDI
  $signals{4}{"data"}="X"; #TDO
  $signals{7}{"data"}="1"; #TRST->RESETb
  &SPI_print_n_line(98);
  
  $signals{1}{"data"}="0"; #TMS
  $signals{2}{"data"}="P"; #TCK
  $signals{3}{"data"}="1"; #TDI
  $signals{4}{"data"}="X"; #TDO
  $signals{7}{"data"}="1"; #TRST->RESETb
  &SPI_print_n_line(6);
  
  $signals{1}{"data"}="0"; #TMS
  $signals{2}{"data"}="P"; #TCK
  $signals{3}{"data"}="0"; #TDI
  $signals{4}{"data"}="X"; #TDO
  $signals{7}{"data"}="1"; #TRST->RESETb
  &SPI_print_n_line(6);
  
  $signals{1}{"data"}="1"; #TMS
  $signals{2}{"data"}="P"; #TCK
  $signals{3}{"data"}="0"; #TDI
  $signals{4}{"data"}="X"; #TDO
  $signals{7}{"data"}="1"; #TRST->RESETb
  &SPI_print_n_line(10000000); #wait 0.5 second
  &SPI_print_n_line(10000000); #wait 0.5 second
  &SPI_print_n_line(10000000); #wait 0.5 second
  &SPI_print_n_line(10000000); #wait 0.5 second
  &SPI_print_n_line(8000000); #wait 0.4 second
}

sub SPI_FLASH_write_data(){
  my $write_addr=shift;
  my $write_data=shift;
  my $ce_oe_we = shift;
  my $control = shift;
  my $end_config = shift;
  my $control_bit = 10;
  my $config_bit = 12;
  $control=$control||($isNVR<<6);
  
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));

  &SPI_start("0x$address_hex","0x$write_data","write");
	&SPI_ce_oe_we($ce_oe_we);
	&SPI_control_bitX($control, $control_bit);
	&SPI_address_16bit($write_addr);
	&SPI_data_72bit($write_data);
	&SPI_end_config_bitX($end_config, $config_bit);
	&SPI_stop();
}

sub SPI_FLASH_write_data_without_stop(){
  my $write_addr=shift;
  my $write_data=shift;
  my $ce_oe_we = shift;
  my $control = shift;
  my $end_config = shift;
  my $control_bit = 10;
  my $config_bit = 12;
  $control=$control||($isNVR<<6);
  
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));

  &SPI_start("0x$address_hex","0x$write_data","write");
	&SPI_ce_oe_we($ce_oe_we);
	&SPI_control_bitX($control, $control_bit);
	&SPI_address_16bit($write_addr);
	&SPI_data_72bit($write_data);
	&SPI_end_config_bitX($end_config, $config_bit);
	#&SPI_stop();
}

sub SPI_FLASH_write_data_with_read(){
  my $write_addr=shift;
  my $write_data=shift;
  my $read_data=shift;
  my $ce_oe_we = shift;
  my $control = shift;
  my $end_config = shift;
  my $control_bit = 10;
  my $config_bit = 12;
  $control=$control||($isNVR<<6);
  
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));
	
	#analysis pre-write data
	my $dec_byte1=substr($read_data,14,2);
	my $dec_byte2=substr($read_data,12,2);
	my $dec_byte3=substr($read_data,10,2);
	my $dec_byte4=substr($read_data,8,2);
	my $dec_byte5=substr($read_data,6,2);
	my $dec_byte6=substr($read_data,4,2);
	my $dec_byte7=substr($read_data,2,2);
	my $dec_byte8=substr($read_data,0,2);
	#my $dec_byte9="00"; #ECC correct code
	
	$dec_byte1 = hex($dec_byte1);
	$dec_byte2 = hex($dec_byte2);
	$dec_byte3 = hex($dec_byte3);
	$dec_byte4 = hex($dec_byte4);
	$dec_byte5 = hex($dec_byte5);
	$dec_byte6 = hex($dec_byte6);
	$dec_byte7 = hex($dec_byte7);
	$dec_byte8 = hex($dec_byte8);
	$dec_byte9 = hex($dec_byte9);
	
	my $word0 = hex(substr($read_data,8,8));
	my $word1 = hex(substr($read_data,0,8));
	my $dec_byte9=&genecc($word0,$word1);
	
	my $dec_hex=unpack("H18",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	my $bin=unpack("B72",pack("C9",$dec_byte9,$dec_byte8,$dec_byte7,$dec_byte6,$dec_byte5,$dec_byte4,$dec_byte3,$dec_byte2,$dec_byte1));
	
  &SPI_read_start("0x$address_hex","0x$read_data","read", $bit);
	&SPI_ce_oe_we($ce_oe_we);
	&SPI_control_bitX($control, $control_bit);
	&SPI_address_16bit($write_addr);
	&SPI_data_72bit($write_data);
	&SPI_end_config_bitX($end_config, $config_bit);
	#&SPI_stop();
}

sub SPI_OTP_write_data(){
  my $write_addr=shift;
  my $write_data=shift;
  my $ce_oe_we = shift;
  my $control = shift;
  my $end_config = shift;
  my $control_bit = 11;
  my $config_bit = 10;
  $control=$control||($isNVR<<6);
  
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));

  &SPI_start("0x$address_hex","0x$write_data","write");
	&SPI_ce_oe_we($ce_oe_we);
	&SPI_control_bitX($control, $control_bit);
	&SPI_address_12bit($write_addr);
	&SPI_data_32bit($write_data);
	&SPI_end_config_bitX($end_config, $config_bit);
	&SPI_stop();
}

sub SPI_NVR_write_data(){
  my $write_addr=shift;
  my $write_data=shift;
  my $ce_oe_we = shift;
  my $control = shift;
  my $end_config = shift;
  my $control_bit = 10;
  my $config_bit = 12;
  
  my $dec=$write_addr;
	my $dec_byte1=$dec&0xff;
	my $dec_byte2=($dec>>8)&0xff;
	my $address_hex=unpack("H4",pack("C2",$dec_byte2,$dec_byte1));

  &SPI_start("0x$address_hex","0x$write_data","write");
	&SPI_ce_oe_we($ce_oe_we);
	&SPI_control_bitX($control, $control_bit);
	&SPI_address_16bit($write_addr);
	&SPI_data_72bit($write_data);
	&SPI_end_config_bitX($end_config, $config_bit);
	&SPI_stop();
}

sub flash_chip_erase(){
  my $write_addr="0000";
  my $write_data="0000000000000000";
  
  $signals{5}{"data"}="0";
	$signals{6}{"data"}="0";
  
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x000;
  my $end_config = 0x02f;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(10000000); #wait 0.5 second
	&SPI_print_n_line(10000000); #wait 0.5 second
	&SPI_print_n_line(10000000); #wait 0.5 second
	&SPI_print_n_line(10000000); #wait 0.5 second
}


sub OTP_chip_erase(){
  my $write_addr="0000";
  my $write_data="00000000";
  
  $signals{5}{"data"}="0";
	$signals{6}{"data"}="1";
  
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x000;
  my $end_config = 0x2a6;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(10000000); #wait 0.5 second
	&SPI_print_n_line(10000000); #wait 0.5 second
	&SPI_print_n_line(10000000); #wait 0.5 second
	&SPI_print_n_line(10000000); #wait 0.5 second
}

sub read_flash_initial(){
  my $write_addr=shift;
  my $write_data=0x0000;

  #original
  my $ce_oe_we = 0x7;
  my $control = 0x300;
  my $end_config = 0x030;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

  #read address
  my $ce_oe_we = 0x4;
  my $control = 0x300;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#read address
  my $ce_oe_we = 0x4;
  my $control = 0x300;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
}

sub read_flash_address(){
  my $next_addr=shift;
  my $read_data=shift;
  my $write_data=0x0000;
  my $read_addr=$next_addr-1;

  #read address
  my $ce_oe_we = 0x4;
  my $control = 0x340;
  my $end_config = 0x030;
  &SPI_FLASH_write_data_without_stop($next_addr,$write_data, $ce_oe_we, $control, $end_config);
  &read_flash_72bit($read_addr,$read_data)
}

sub read_OTP_initial(){
  my $write_addr=shift;
  my $write_data=shift;

  #original
  my $ce_oe_we = 0x7;
  my $control = 0x000;
  my $end_config = 0x280;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x4;
  my $control = 0x000;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	&read_flash_32bit($write_addr,$write_data);
}

sub read_OTP_continues(){
  my $write_addr=shift;
  my $write_data=shift;

	#ce prog
	my $ce_oe_we = 0x4;
  my $control = 0x000;
  my $end_config = 0x280;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	&read_flash_32bit($write_addr,$write_data);
}

sub flash_erase_one_sector(){
	  my $write_addr=shift;
	  my $write_data=0x0000;
	  
		my $ce_oe_we = 0x7;
		my $control = 0x318;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x7, 0x318
	  
	  my $ce_oe_we = 0x6;
		my $control = 0x304;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  
	  my $ce_oe_we = 0x2;
		my $control = 0x304;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x2, 0x304
	  
	  &SPI_print_n_line(360000); #wait 18 ms
	  
	  my $ce_oe_we = 0x2;
		my $control = 0x304;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  
	  my $ce_oe_we = 0x7;
		my $control = 0x318;
  	my $end_config = 0x000;
	  &SPI_FLASH_write_data($write_addr,write_data, $ce_oe_we, $control, $end_config);  #0x6, 0x304
	  &SPI_print_n_line(1024); #wait 51.2 us
}

sub write_FLASH(){
  my $write_addr=shift;
  my $write_data=shift;

  #program high 36bit
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x300;
  &SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x6;
	my $control = 0x301;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#web
	my $ce_oe_we = 0x2;
	my $control = 0x301;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#prog2
	my $ce_oe_we = 0x2;
	my $control = 0x303;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	&SPI_print_n_line(226); #11.3us

	#prog2 to low
	my $ce_oe_we = 0x2;
	my $control = 0x301;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	#we to high
	my $ce_oe_we = 0x6;
	my $control = 0x301;
	my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #program low 36bit 
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x100;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x6;
  my $control = 0x101; 
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#web
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x103;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(226); #11.3us

	#prog2 to low
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	#we to high
	my $ce_oe_we = 0x6;
  my $control = 0x101;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub write_OTP(){
  my $write_addr=shift;
  my $write_data=shift;

  #original
  my $ce_oe_we = 0x7;
  my $control = 0x080;
  my $end_config = 0x280;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x6;
  my $control = 0x081;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#address 0x0001
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x081;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x083;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x081;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	
  #address 0x0010
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x103;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	
	#address 0x0100
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x201;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x203;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x201;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	
	#address 0x1000
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x401;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x403;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x401;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	#ce prog
	my $ce_oe_we = 0x6;
  my $control = 0x081;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub write_OTP_continues(){
  my $write_addr=shift;
  my $write_data=shift;
	
	#address 0x0001
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x081;
  my $end_config = 0x280;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x083;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x081;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	
  #address 0x0010
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x103;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	
	#address 0x0100
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x201;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x203;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x201;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	
	#address 0x1000
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x401;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x403;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x401;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub OTP_erase_one_sector(){
  my $write_addr=shift;
  my $write_data=0x0000;
  
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x008;
  my $end_config = 0x280;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
  #ce erase 
  my $ce_oe_we = 0x6;
  my $control = 0x004;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	#we
  my $ce_oe_we = 0x2;
  my $control = 0x004;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(80000); #wait 4 ms
	
	#we
  my $ce_oe_we = 0x6;
  my $control = 0x004;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(1000); #wait 50 us
	
	#original
  my $ce_oe_we = 0x7;
  my $control = 0x008;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}


sub write_OTP_initial(){
  my $write_addr=shift;
  my $write_data=shift;

  #original
  my $ce_oe_we = 0x7;
  my $control = 0x080;
  my $end_config = 0x005;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x6;
  my $control = 0x081;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#address 0x0001
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x081;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x083;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x081;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	
  #address 0x0010
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x103;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	
	#address 0x0100
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x201;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x203;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x201;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	
	#address 0x1000
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x401;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x403;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
	&SPI_print_n_line(68); #3.4us
	
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x401;
	&SPI_OTP_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}


sub write_FLASH_low_36bit_initial(){
  my $write_addr=shift;
  my $write_data=shift;

  #program low 32bit
  
  #preset
  my $ce_oe_we = 0x6;
  my $control = 0x101;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x100;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x6;
  my $control = 0x101; 
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#web
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x103;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	&SPI_print_n_line(226); #11.3us

	#prog2 to low
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub write_FLASH_high_36bit_initial(){
  my $write_addr=shift;
  my $write_data=shift;
  
  #program low 32bit
  
  #preset
  my $ce_oe_we = 0x6;
  my $control = 0x301;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x300;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	#ce prog
	my $ce_oe_we = 0x6;
  my $control = 0x301; 
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#web
	my $ce_oe_we = 0x2;
  my $control = 0x301;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x303;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	&SPI_print_n_line(226); #11.3us

	#prog2 to low
	my $ce_oe_we = 0x2;
  my $control = 0x301;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub disable_FLASH(){

  my $write_addr=0x0000;
  my $write_data=0x0000000000000000;
  
  #preset
  my $ce_oe_we = 0x6;
  my $control = 0x301;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
  
  #original
  my $ce_oe_we = 0x7;
  my $control = 0x300;
  my $end_config = 0x000;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
	
}

sub write_FLASH_low_36bit_continues(){
  my $write_addr=shift;
  my $write_data=shift;

  #program low 32bit
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x103;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	&SPI_print_n_line(226); #11.3us

	#prog2 to low
	my $ce_oe_we = 0x2;
  my $control = 0x101;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub write_FLASH_high_36bit_continues(){
  my $write_addr=shift;
  my $write_data=shift;

  #program low 32bit
	#web
	my $ce_oe_we = 0x2;
  my $control = 0x301;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);   

	#prog2
	my $ce_oe_we = 0x2;
  my $control = 0x303;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);

	&SPI_print_n_line(226); #11.3us

	#prog2 to low
	my $ce_oe_we = 0x2;
  my $control = 0x301;
	&SPI_FLASH_write_data($write_addr,$write_data, $ce_oe_we, $control, $end_config);
}

sub load_bin_file(){
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	#my $op_byte = 1048576;
	#print OUT "open bin file";
	open(bin_file, "<functional_sisuo.bin")||die "Can't open ./functional_sisuo.bin! $@\n";
	binmode(bin_file);
	read(bin_file,my $buf,$op_byte);
	my $hex=unpack("H*",$buf);
	chomp($hex);
	
	#for($i=0; $i<$op_byte; $i++)
	#{
	#	$array_bin[$i] = "11111111";
	#	$array_hex[$i] = "ff";
	#}
	
	#&SPI_chip_erase();
	#&flash_chip_erase();
	#&OTP_chip_erase();
	
	for($i=0; $i<$op_byte; $i++)
	{

		if(substr($hex,$i*2,2))
		{
			$array_bin[$i] = unpack("B8",substr($buf,$i,1));
			$array_hex[$i] = substr($hex,$i*2,2);
		}else{
			$array_bin[$i] = "11111111";
			$array_hex[$i] = "ff";
		}
		
		#print OUT $array_hex[$i];
		if(($i+1)%16 == 0 && $i!=0)
		{
			#print OUT "\n";
		}
		#if($array_bin[$i]){
			#print OUT $array_hex[$i]." to bin ".$array_bin[$i]."\n";
		#}else{
			#last;
		#}
	}
}

sub transfer_bin_to_avc_FLASH(){
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	my $part = 256;
	my $base_address = 0x0000;
	
	if($isFlash0) {
		$signals{5}{"data"}="0";
		$signals{6}{"data"}="0";
	} else {
		$signals{5}{"data"}="1";
		$signals{6}{"data"}="0";
	}
	
	#&write_FLASH(0x10,"a5a5a5a55a5a5a5a");
	
	&read_FLASH(0x10,"a5a5a5a55a5a5a5a");
	#&read_FLASH(0x51,"a5a5a5a55a5a5a5a");
	#&read_FLASH(0x52,"ffffffffffffffff");
	#&read_FLASH(0x53,"ffffffffffffffff");
	
#	for($i=0; $i<$op_byte; $i = $i+8){
#		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
#		$address_16bit = ($i+$base_address)/8;
#		if($address_16bit%32==0){
#			&write_FLASH_low_36bit_initial($address_16bit,$write_8byte);
#		} else {
#			&write_FLASH_low_36bit_continues($address_16bit,$write_8byte);
#		}
#	}
#	&disable_FLASH();
#
#	for($i=0; $i<$op_byte; $i = $i+8){
#		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
#		$address_16bit = ($i+$base_address)/8;
#		if($address_16bit%32==0){
#			&write_FLASH_high_36bit_initial($address_16bit,$write_8byte);
#		} else {
#			&write_FLASH_high_36bit_continues($address_16bit,$write_8byte);
#		}
#	}
#	&disable_FLASH();

#	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){ #0xa880
#		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
#		$$address_16bit = ($i+$base_address)/8;
#		&write_FLASH($address_16bit,$write_8byte);
#	}
#	
#	$part = 261;
#	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){ #0xa880
#		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
#		$$address_16bit = ($i+$base_address)/8;
#		&write_FLASH($address_16bit,$write_8byte);
#	}
#
#	$part = 324;
#	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){ #0xa880
#		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
#		$$address_16bit = ($i+$base_address)/8;
#		&write_FLASH($address_16bit,$write_8byte);
#	}
#	
#	$part = 325;
#	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){ #0xa880
#		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
#		$$address_16bit = ($i+$base_address)/8;
#		&write_FLASH($address_16bit,$write_8byte);
#	}
	
}

sub tranfer_bin_to_avc_OTP(){
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	my $part = 256;
	my $base_address = 0x0000;
	
	$signals{5}{"data"}="0";
	$signals{6}{"data"}="1";
	
	for($i=0; $i<$op_byte; $i = $i+4){
		$write_4byte = $array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_4byte = ($i+$base_address)/4;
		&write_OTP($address_4byte,$write_4byte);
	}
}

sub read_FLASH_bin(){
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	my $part = 256;
	my $base_address = 0x0000;
	
	if($isFlash0) {
		$signals{5}{"data"}="0";
		$signals{6}{"data"}="0";
	} else {
		$signals{5}{"data"}="1";
		$signals{6}{"data"}="0";
	}
	
#	$is_initial = 1;
#	for($i=0; $i<$op_byte; $i = $i+8){
#		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
#		$address_16bit = $i/8;
#		$next_address = $address_16bit+1;
#		if($is_initial) {
#			&read_flash_initial($address_16bit,$write_8byte);
#			&read_flash_address($next_address,$write_8byte);
#			$is_initial = 0;
#		} else {
#			&read_flash_address($next_address,$write_8byte);
#		}
#	}
#	&SPI_stop();

	$is_initial = 1;
	my $part = 256;
	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = $i/8;
		$next_address = $address_16bit+1;
		if($is_initial) {
			&read_flash_initial($address_16bit,$write_8byte);
			&read_flash_address($next_address,$write_8byte);
			$is_initial = 0;
		} else {
			&read_flash_address($next_address,$write_8byte);
		}
	}
	
	my $part = 261;
	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = $i/8;
		$next_address = $address_16bit+1;
		if($is_initial) {
			&read_flash_initial($address_16bit,$write_8byte);
			&read_flash_address($next_address,$write_8byte);
			$is_initial = 0;
		} else {
			&read_flash_address($next_address,$write_8byte);
		}
	}
	
	my $part = 324;
	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = $i/8;
		$next_address = $address_16bit+1;
		if($is_initial) {
			&read_flash_initial($address_16bit,$write_8byte);
			&read_flash_address($next_address,$write_8byte);
			$is_initial = 0;
		} else {
			&read_flash_address($next_address,$write_8byte);
		}
	}
	
	my $part = 325;
	for($i=0x00000+$op_byte*$part; $i<0x00000+$op_byte*($part+1); $i = $i+8){
		$write_8byte = $array_hex[$i+7].$array_hex[$i+6].$array_hex[$i+5].$array_hex[$i+4].$array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_16bit = $i/8;
		$next_address = $address_16bit+1;
		if($is_initial) {
			&read_flash_initial($address_16bit,$write_8byte);
			&read_flash_address($next_address,$write_8byte);
			$is_initial = 0;
		} else {
			&read_flash_address($next_address,$write_8byte);
		}
	}
	&SPI_stop();
}

sub sector_erase_flash(){
	my $start_sector=0;
	my $end_sector=11;
	my $i=0;

	$signals{5}{"data"}="0";
	$signals{6}{"data"}="1";
	
	for($i=$start_sector; $i<$end_sector; $i++){
		$sector_address = $i*0x80;
		&flash_erase_one_sector($sector_address);
	}
}

sub read_OTP_bin(){
	my @array;
	my $i=0;
	my $j=0;
	my $data=0;
	my $base_address = 0x0000;
	
	$signals{5}{"data"}="0";
	$signals{6}{"data"}="1";
	
	$is_initial=1;
	for($i=0; $i<$op_byte; $i = $i+4){
		$write_4byte = $array_hex[$i+3].$array_hex[$i+2].$array_hex[$i+1].$array_hex[$i];
		$address_12bit = $i/4;
		if($is_initial) {
			&read_OTP_initial($address_12bit,$write_4byte);
			$is_initial=0;
		} else {
			&read_OTP_continues($address_12bit,$write_4byte);
		}
	}
	&SPI_stop();
}

sub sector_erase_OTP(){
	my $start_sector=0;
	my $end_sector=5;
	my $i=0;

	$signals{5}{"data"}="0";
	$signals{6}{"data"}="1";
	
	for($i=$start_sector; $i<$end_sector; $i++){
		$sector_address = $i*0x80;
		&OTP_erase_one_sector($sector_address);
	}
}
